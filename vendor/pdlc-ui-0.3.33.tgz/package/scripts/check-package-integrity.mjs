import { existsSync, readFileSync, statSync } from 'node:fs'
import { dirname, relative, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

export function checkPackageIntegrity(root) {
  const pkg = JSON.parse(readFileSync(resolve(root, 'package.json'), 'utf8'))
  const targets = new Set([pkg.main, ...Object.values(pkg.exports), ...Object.values(pkg.bin ?? {})])
  const errors = []
  for (const target of targets) {
    if (typeof target !== 'string' || !target.startsWith('./') && !target.startsWith('src/')) {
      errors.push(`Unsupported package target: ${String(target)}`)
      continue
    }
    const path = resolve(root, target)
    if (relative(root, path).startsWith('..') || !existsSync(path) || !statSync(path).isFile())
      errors.push(`Missing or unsafe package target: ${target}`)
  }
  return errors
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const errors = checkPackageIntegrity(resolve(dirname(fileURLToPath(import.meta.url)), '..'))
  if (errors.length) {
    console.error(errors.join('\n'))
    process.exitCode = 1
  } else console.log('All declared shared package entry points exist.')
}
