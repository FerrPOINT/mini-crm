import type { connectPlatformProduct, platformNavigate, platformReload, transportNamespaceLocation } from '../src/platform/bridge.js'
import type { createDraftTracker } from '../src/lib/draft-state.js'
export const unsavedChangesConfirmation: Readonly<{ title: string; message: string; confirmLabel: string }>
export interface ServerProductOptions {
  serviceKey: string; portalOrigin?: string; logoutUrl?: string; error?: string | null
  /** Original server display window; initial time is navigation start, not script receipt. */
  admission?: {
    initial: { schema_version: 1; enforced: boolean; remaining_millis: number | null; scope_revision: string | null }
    load: (signal: AbortSignal) => Promise<unknown>
  }
  hasUnsavedChanges?: () => boolean
  confirmLeave?: () => boolean | Promise<boolean>
  cancelLeave?: () => void
  onDiscard?: () => void
  onCommitted?: () => void
}
/** Lifecycle for a persistent SSR shell; this never extends admission validity. */
export interface ServerProductController {
  canLeave(): boolean | Promise<boolean>
  trackForms(root?: ParentNode): void
  isCurrent(): boolean
  retire(): void
}
export function installServerProduct(runtime: {
  connectPlatformProduct: typeof connectPlatformProduct
  platformNavigate: typeof platformNavigate
  platformReload: typeof platformReload
  transportNamespaceLocation: typeof transportNamespaceLocation
  createDraftTracker?: typeof createDraftTracker
}, options: ServerProductOptions): ServerProductController
