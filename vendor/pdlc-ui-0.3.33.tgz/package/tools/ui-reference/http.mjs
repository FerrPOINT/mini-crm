/** HTTP is explicit: an unavailable or mismatched server never changes the selected revision. */
export function referenceClient(server, fingerprint, request = fetch) {
  const base = new URL(server.endsWith("/") ? server : `${server}/`);
  if (
    base.username ||
    base.password ||
    base.search ||
    base.hash ||
    !(
      base.protocol === "https:" ||
      (base.protocol === "http:" &&
        ["127.0.0.1", "localhost", "[::1]"].includes(base.hostname))
    )
  )
    throw new Error(
      "Use HTTPS or loopback HTTP without credentials/query/fragment.",
    );
  if (!/^[a-f0-9]{64}$/.test(fingerprint))
    throw new Error(
      "Expected a reference fingerprint (64 lowercase hex characters).",
    );
  return async function read(resource = "", query = {}) {
    const url = new URL(
      `api/v1/reference${resource ? `/${resource}` : ""}`,
      base,
    );
    for (const [key, value] of Object.entries(query))
      if (value !== undefined) url.searchParams.set(key, String(value));
    url.searchParams.set("fingerprint", fingerprint);
    const response = await request(url, {
      headers: { Accept: "application/json" },
      redirect: "error",
      signal: AbortSignal.timeout(10_000),
    });
    let body;
    try {
      body = await response.json();
    } catch {
      throw new Error(
        `Dictionary returned invalid JSON (HTTP ${response.status}).`,
      );
    }
    if (body === null || typeof body !== "object" || Array.isArray(body))
      throw new Error("Dictionary returned an invalid response envelope.");
    if (!response.ok) {
      const error = new Error(
        typeof body.message === "string"
          ? body.message
          : `Dictionary HTTP ${response.status}`,
      );
      error.status = response.status;
      error.code = body.code;
      throw error;
    }
    if (body.sourceFingerprint !== fingerprint || !("data" in body))
      throw new Error("Dictionary returned an unexpected reference revision.");
    return body.data;
  };
}
