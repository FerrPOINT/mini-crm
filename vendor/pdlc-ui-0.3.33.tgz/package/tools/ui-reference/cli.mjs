#!/usr/bin/env node
import { parseArgs } from "node:util";
import { index, card, manifest, example, recipe, check } from "./reader.mjs";
import { search } from "./search.mjs";
import { formatCard, formatSearch, section } from "./format.mjs";
import { referenceClient } from "./http.mjs";

const help = `Base UI reference
pdlc-ui search <query> [--limit 3] [--kind component|mechanism|hook|function|class|type|constant|api] [--topic <id>] [--group <id>] [--json]
pdlc-ui show <ExportName> [--section props|setup|usage|all] [--json]
pdlc-ui example <ExportName> [--case basic] [--json]
pdlc-ui example recipes [--case form|list|detail|resource-picker|dirty-guard|shell] [--json]
pdlc-ui check [--json]

All commands: [--local | --server https://host/] [--fingerprint <sha256>]
Default: local files, no network. --server uses the API and pins the local package fingerprint
unless --fingerprint explicitly selects another revision. No silent fallback.
Start with search, then show and one example. Storybook is optional for lookup.
Names are case-sensitive. No generation during lookup.`;

try {
  const { values, positionals } = parseArgs({
    allowPositionals: true,
    options: {
      json: { type: "boolean" },
      help: { type: "boolean", short: "h" },
      limit: { type: "string" },
      kind: { type: "string" },
      topic: { type: "string" },
      group: { type: "string" },
      section: { type: "string" },
      case: { type: "string" },
      local: { type: "boolean" },
      server: { type: "string" },
      fingerprint: { type: "string" },
    },
  });
  const [command, ...args] = positionals;
  const allowed =
    command === "search"
      ? ["limit", "kind", "topic", "group"]
      : command === "show"
        ? ["section"]
        : command === "example"
          ? ["case"]
          : [];
  for (const flag of ["limit", "section", "case", "kind", "topic", "group"])
    if (values[flag] !== undefined && !allowed.includes(flag))
      throw new Error(`--${flag} is not supported by ${command}.`);
  let result;
  let text;
  if (values.help || !command) {
    console.log(help);
    process.exit(0);
  }
  if (values.local && values.server !== undefined)
    throw new Error("Choose --local or --server.");
  if (values.fingerprint !== undefined && values.server === undefined)
    throw new Error("--fingerprint requires --server.");
  const remote =
    values.server !== undefined
      ? referenceClient(
          values.server,
          values.fingerprint ?? manifest().sourceFingerprint,
        )
      : null;
  if (command === "search") {
    if (!args.length) throw new Error("Provide a search query.");
    const limit = values.limit === undefined ? 3 : Number(values.limit);
    if (!Number.isInteger(limit) || limit < 1 || limit > 20)
      throw new Error("--limit must be an integer between 1 and 20.");
    const filters = {
      kind: values.kind,
      topic: values.topic,
      group: values.group,
    };
    if (
      values.kind &&
      ![
        "component",
        "mechanism",
        "hook",
        "function",
        "class",
        "type",
        "constant",
        "api",
      ].includes(values.kind)
    )
      throw new Error("Unknown export kind.");
    result = remote
      ? await remote("search", { q: args.join(" "), limit, ...filters })
      : search(index(), args.join(" "), limit, filters);
    text = formatSearch(result);
  } else if (command === "show") {
    if (args.length !== 1)
      throw new Error("Provide one public component name.");
    const info = remote
      ? await remote("card", { name: args[0] })
      : card(args[0]);
    result = section(info, values.section);
    text = formatCard(info, values.section);
  } else if (command === "example") {
    if (args.length !== 1)
      throw new Error("Provide one component name or recipes.");
    if (args[0] === "recipes" && !values.case) {
      result = (remote ? await remote() : manifest()).recipes.map(
        ({ id }) => id,
      );
      text = result.join("\n");
    } else {
      result = remote
        ? await remote("example", { name: args[0], case: values.case })
        : args[0] === "recipes"
          ? recipe(values.case)
          : example(args[0], values.case);
      if (remote && args[0] === "recipes")
        result = { recipe: result.id, setup: result.setup, code: result.code };
      text = `// Setup: ${result.setup.join(", ")}\n${result.code}`;
    }
  } else if (command === "check") {
    if (args.length)
      throw new Error("check does not accept positional arguments.");
    result = remote ? await remote("check") : check();
    text = `UI reference verified: ${result.componentCount} components; ${result.checkedFiles} files; ${result.sourceFingerprint}.`;
  } else throw new Error(`Unknown command: ${command}. Use --help.`);
  console.log(values.json ? JSON.stringify(result) : text);
} catch (error) {
  const message = error instanceof Error ? error.message : String(error);
  if (process.argv.includes("--json"))
    console.error(JSON.stringify({ error: message }));
  else console.error(message);
  process.exitCode = 1;
}
