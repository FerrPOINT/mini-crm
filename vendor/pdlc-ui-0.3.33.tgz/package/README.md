# Base UI

`@pdlc/ui` содержит канонические компоненты, стили, общие механизмы и offline-справочник.
Продукты используют публичные imports и собственную интеграцию API/маршрутов/прав.

## Кандидат 0.3.33

В ServiceSwitcher галочка текущего сервиса располагается перед индикатором
состояния. Во всех строках для галочки зарезервировано одинаковое место,
поэтому кружки сохраняют общую правую колонку без сдвига выбранной строки.
Скрытые native-поля Select/MultiSelect имеют явную позицию и не увеличивают
высоту документа при использовании внутри прокручиваемой области. Их native
required, FormData и reset сохраняются; ширина видимых полей не меняется.

Шапка сохраняет область навигации и название продукта при нескольких действиях
на мобильном экране. Компактное оформление ServiceSwitcher принадлежит Base;
действия без видимой подписи используют Button size="icon". Высота шапки,
namespace-строки и отступ sidebar следуют плотности и настоящему размеру текста.
При Button asChild responsive-классы передаются самому Button, чтобы общий
merge классов не оставлял одновременно конфликтующие display-значения ребёнка.
Новый самостоятельный пример dense-actions показывает эту композицию.

Общий branding runtime обновляет привязки `data-base-brand-title` при внутренних
переходах SSR-страницы. Имя опубликованного бренда сохраняется без нового запроса,
перерисовки формы или изменения её черновиков. Подпись страницы задаёт продукт;
общий формат заголовка принадлежит Base. После dispose обновление прекращается.
Публичный API и зависимости сохранены; принятие требует обновления UI pin продукта.

## Предыдущий кандидат 0.3.32

Textarea autoSize пересчитывает высоту при изменении настоящего размера текста
браузера без ввода или изменения ширины поля. Один общий observer rem-метрики
документа удаляется после последнего поля; значение, focus, selection и события
формы не меняются. React и SSR используют один runtime без polling.
Публичный API и зависимости сохранены. Статус квалификации и её границы:
[актуальная матрица](../../docs/reports/branding-coverage-matrix-20261030.md).

## Предыдущий кандидат 0.3.31

Общая типографика использует `rem`: исходные размеры при корне 16 px сохранены,
а настоящая настройка размера текста браузера до 200% увеличивает текст,
подписи и заголовки. Связанные поля названия переносятся по доступной ширине.
ProjectPicker использует тот же текстовый token. Размер знака шапки и минимумы
областей нажатия сохраняют свои контракты. Публичные API и зависимости прежние.

## Предыдущий кандидат 0.3.24

Нативная загрузка изображения редактора использует общий Button: плотность,
радиус и keyboard focus больше не задаются отдельным skin. React/JS/SSR/favicon
переиспользуют один расчёт знака, включая резервный символ при ошибке изображения.
Справочник уточняет назначения и примеры отдельных экспортов семейства брендинга;
компактный пример выбирается адресно через существующий CLI/API.

Публичные UI-контракты, reference schema 2 и HTTP API v1 сохраняются. SDK/skills
независимы. Изменение версии пакета не обновляет UI pins продуктов автоматически;
при принятии нужны штатные lockfiles и SSR/Auth exports.

Server/browser consumers могут использовать чистый контракт
`@pdlc/ui/application-access` без загрузки React: проверку owner proof и
`loadApplicationAccess`. Это тот же механизм, который использует React provider.
`@pdlc/ui/theme-preference` публикует канонический browser script для применения
темы до первого отображения body; сервер может разрешить путь через package
exports и отдать исходный asset. Сам script не применяет тему автоматически:
bootstrap продукта вызывает `PdlcThemePreference.read()` и выставляет `data-theme`.
Аккаунты, cookies авторизации и продуктовые права этим не предоставляются.

## Справочник

Перед разработкой приложения читать [маршрут агента и разработчика](reference/guides/agent.md):
сверить UI pin → проверить справочник → найти контракт → взять один пример →
интегрировать через публичный API → проверить поведение в продукте.
Из каталога frontend-приложения с установленным пакетом:

```powershell
pnpm exec pdlc-ui check
pnpm exec pdlc-ui search "выбор ресурса"
pnpm exec pdlc-ui show SearchableSelect
pnpm exec pdlc-ui show SearchableSelect --section props
pnpm exec pdlc-ui example SearchableSelect
pnpm exec pdlc-ui example recipes --case form
```

Из корня продукта с `frontend/` используйте `pnpm --dir frontend exec pdlc-ui ...`.
Из корня Base — `node base-modules/ui/tools/ui-reference/cli.mjs ...`.
CLI работает на Node 22 без сети, node_modules и Storybook.
Для SSR и неподготовленного frontend руководство содержит подготовку отдельного
checkout точного UI SHA. Чтение нового Base не обновляет принятую версию продукта.
Команды и ограничения: [руководство агента](reference/guides/agent.md),
[подключение](reference/guides/setup.md), [SSR](reference/guides/ssr.md).

## Структура и разработка

- `src/`, `ssr/` — реализация UI и SSR.
- `tools/ui-reference/` — CLI на стандартных модулях Node.
- `reference/` — воспроизводимый справочник; входит в пакет, вручную не редактируется.
- `../../components-dictionary/` — отдельное приложение `@pdlc/components-dictionary` с собственными зависимостями.
- `qa/` — отдельные регрессионные fixtures.

Каталог запускается локально по [инструкции](../../components-dictionary/README.md).
Его зависимости и артефакты сборки не входят в поставку UI.
Обновление UI pin у продуктов выполняется отдельно от разработки каталога.

`file:` dependencies pnpm могут иметь hardlinks на source-файлы Base. После
изменения библиотеки прежний установленный каталог не является неизменной
копией UI pin: существующие файлы могут обновиться раньше новых. Перед consumer
tests следует обновить зависимость штатным frozen install и проверить snapshot;
для квалификации использовать точный producer checkout либо настоящий архив.
Успешный прежний check не подтверждает пакет после изменения его source inputs.

`ServiceSwitcher` разрешает межпродуктовые переходы только по runtime-каталогу
Admin или конфигурации встроенного host. При загрузке, отказе, пустом или
повреждённом каталоге встроенные подписи остаются видимыми, но неподтверждённые
адреса не становятся ссылками. Health не определяет доверие к адресу: известный
адрес остаётся доступным при `unknown`/`unreachable`. После восстановления
каталога ссылки обновляются на штатном интервале. Без `catalogUrl` standalone
меню остаётся информационным; host с настроенными сервисами сохраняет навигацию.
`usePlatformServices().services` при fallback возвращает пустой список: продуктовые
ссылки и запросы не должны использовать compiled origins. `defaultServices`
сохраняется для подписей и порядка отображения, а не для запросов с credentials.

Для Vite/Vitest подключайте `resolve: { dedupe: createUiProviderDedupe() }`,
импортируя функцию из `@pdlc/ui/build`. Это сохраняет общий экземпляр React,
Router, i18n и остальных context providers между приложением и UI-пакетом.
Dev-кеш подключайте через `createUiDevCachePlugin()` того же подмодуля: production inputs установленного UI определяют namespace prebundle. Одинаковые inputs переиспользуют кеш, docs-only не запускает повторную оптимизацию. Пример — в [руководстве подключения](reference/guides/setup.md).

SSR `page_header` принимает plain-text `title` или готовый `heading`. Если
заголовка, контекста и действий нет, macro ничего не выводит. Контекст/действия
могут использоваться отдельно от заголовка; отсутствующий title не отображается.

`createProductRouter` применяет `basename` как в standalone, так и в embedded
режиме. Служебные auth-маршруты внутри префикса не публикуются в host как экраны.

## UI 0.2: фирменные поля выбора

Select теперь принимает options/value/defaultValue/onValueChange; прежние
children/option/onChange/multiple/size заменены согласованной миграцией.
Несколько значений — MultiSelect. [Подключение, формы и SSR](reference/guides/choices.md).

## UI 0.3 и управляемый брендинг

`@pdlc/ui/branding` экспортирует общий компилятор оформления, пресеты и
BrandingScope. PlatformProvider применяет опубликованный документ; draft preview
использует изолированный scope. Типы, обязательные параметры и рабочие примеры
читайте адресно через CLI. Полный контракт: [дизайн-система](../../docs/platform/DESIGN_SYSTEM.md).

Checkbox, RadioGroup/Radio, Switch, Disclosure и Toaster/toast принадлежат UI.
Прямой Sonner и локальная палитра продукта не требуются. API 0.2 сохраняются;
новый design-блок необязателен. Установка и включение writers — отдельный этап.

Для Vite: добавьте `createUiFontAssetsPlugin()` из `@pdlc/ui/build` в plugins.
Он включает notices встроенных шрифтов в dist; файлы самих шрифтов обрабатывает
обычный CSS pipeline. Реализация копирования у продуктов не дублируется.

SSR exporter упорядочивает font assets лексикографически независимо от порядка
обхода файловой системы. Для воспроизводимого экспорта использовать Git SHA
с LF-исходниками и штатный `scripts/export-ssr.mjs --out DIRECTORY --check`.

`resourceErrorState` и `QueryState` используют локализованное сообщение об ошибке
чтения. Текст транспортной ошибки не становится пользовательским сообщением
по умолчанию; продукт может явно передать `message`/`errorMessage`. Для ошибки
обновления при наличии данных сохраняются подтверждённые строки и отдельное
предупреждение. Правила 401/403/404, отмены и доступности повтора не меняются.

### Актуальность доступа

AccessFreshnessBoundary получает номер поколения прав authorityKey, стабильные
load(signal), onRetire и флаг enabled. Loader возвращает строгие метаданные
AdmissionWindowV1: schema_version1, enforced, remaining_millis, scope_revision.
Они описывают срок отображения и не предоставляют права на ресурс.

Компонент отсчитывает остаток от начала запроса и обновляет подтверждение внутри
текущего срока. При неизменных правах черновик сохраняется. Изменение прав,
истечение исходного срока или восстановление BFCache вызывают onRetire:
продукт очищает приватные кеши, увеличивает поколение и перемонтирует формы.
Старые запросы должны отклонять ответы прежнего поколения. До подтверждения
компонент блокирует готовность общей оболочки.

Совместимый режим без политики проверяется повторно, чтобы включение политики
также очищало старые кеши. Продукт получает метаданные от своего серверного
владельца допуска; локальная роль и произвольный TTL не заменяют подтверждение.

SSR installServerProduct принимает необязательное поле admission. При изменении
прав или исходном истечении срока удаляется приватный DOM и останавливается
autosave владельца. Только этот принудительный отзыв обходит диалог ухода
с несохранённым вводом. Начальный срок отсчитывается от начала навигации,
повторный — от начала запроса. Неудача обновления не продлевает прежний срок.
Снимок BFCache скрывается до нового серверного рендера. Продукт отвечает за
авторизованный endpoint и CSS скрытия до первого отображения.

### Роль и доступные приложения

`@pdlc/ui/auth` предоставляет ApplicationAccessProvider, RequireApplicationAccess,
RequireAdministrator и useApplicationAccess. RequireAuth принимает необязательный
`application={{ issuer, key }}`. Общий loader получает текущий допуск у Auth,
сохраняет исходный срок и не доверяет JWT role или сохранённому profile flag.
После смены прав очищается зарегистрированный query cache и перемонтируются
приватные формы. ServiceSwitcher фильтруется тем же подтверждением.

Личные страницы аккаунта размещаются вне app gate. HTTP 403 bootstrap-профиля
передаётся как ApplicationAccessError, чтобы показывать «Нет доступа» без
повторного SSO. Подключение не заменяет guards серверных операций и commit.
[Контракт и правила потребителей](../../docs/platform/HUMAN_APPLICATION_ACCESS.md).

После восстановления страницы из BFCache ApplicationAccessProvider удаляет
прежнее подтверждение, отменяет старые запросы и закрывает приватные результаты
до свежего ответа Auth. Срок не возобновляется таймером замороженной страницы.
Это проверка клиентского lifecycle; IAB приёмка фактически поставленного artifact
остаётся отдельным этапом.

## UI 0.3.1: подписи и варианты выбора

Checkbox/Radio принимают `appearance="card"` и содержимое подписи в children.
Оформление, focus и нативная форма принадлежат Base; прежний default-вариант
сохраняется. Пример: `pdlc-ui example Checkbox --case cards`.
SSR checkbox_control/radio_control поддерживают такое же оформление.

Фон, цвет текста и типографика body также приходят из tokens.css; продуктовые
копии body theme resets больше не нужны. Геометрия страницы остаётся у приложения.

## Рабочая область

`Workbench` и семь публичных частей используют общие tokens для высоты страницы,
прокрутки и адаптивного контекста. Владелец передаёт содержимое, Tabs, Dialog,
refs и обработчики; состояние и запросы в каркас не переносятся.
`WorkbenchScroll padded={false}` убирает вертикальный отступ области, когда
вложенный список уже задаёт отступы строк. По умолчанию отступ сохраняется. Начните с
`pdlc-ui show Workbench` и `pdlc-ui example Workbench`. Полный контракт —
[дизайн-система](../../docs/platform/DESIGN_SYSTEM.md#рабочая-область-workbench).

## Актуальность подготовленного справочника

После изменения публичных исходников, зависимостей UI или входов приложения
справочника выполнить из корня Base `pnpm reference:generate`, затем
`pnpm reference:check`. Проверка включает воспроизводимость генерации и
`pdlc-ui check`; она обязательна и для dependency-only PR. Unit-тесты и
успешный typecheck не заменяют проверку fingerprints подготовленного пакета.
Генерируемые reference-файлы изменяет только штатный generator.

## Рисованные аватары

UserAvatar использует локальный DiceBear core 10.7.0 и только Micah definition
из styles 10.6.0. Публичные props и передаваемые продуктом ID сохраняются;
внешних запросов и хранилища картинок нет. Рисунок может отличаться от v9.
В рамках выбранной версии одинаковый seed даёт одинаковый SVG; смена имени
при сохранённом userId не меняет рисунок. SVG сохраняет атрибуцию Micah Lanier.

## TypeScript: проверка типов и Compiler API

В четырёх пакетах Base команды typecheck, check:runtime и test:examples
запускают точный native checker 7.0.2 через alias @typescript/native и явный
путь его CLI, с --singleThreaded. Не подменять их неоднозначным pnpm exec tsc.
Классический typescript остаётся отдельным: UI 6.0.3, приложения 5.9.3.
Он нужен генераторам reference, JS/деклараций допуска, ESLint, Storybook docgen
и OpenAPI. Импорты Compiler API и --tooling-from разрешаются в своём пакете;
версию checker не превращать в требование к SDK-потребителям. После изменения
зависимостей сверять фактически разрешённые версии и reference:check.

## Среда авторинга Base

Корневой workspace и его CI используют Node 22.22.2 и pnpm 10.28.1.
Это минимальная согласованная версия для jsdom30 и React Router8.
CI и квалификация используют strict peer и engine checks; успешный запуск на более старом
Node не доказывает поддерживаемую совместимость. Authoring pin не обновляет
автоматически Node images продуктов, общие runners или SDK/UI pins.

## Проверка Vite toolchain

Authoring использует Vite 8 и React plugin 6 в UI, host и приложении справочника.
Storybook/Vitest/Tailwind сохраняют собственные совместимые pins. Это devDependencies,
а не новое требование к Vite в продукте, использующем публичный UI-пакет.
Host, frontend справочника и Storybook явно сохраняют browser targets Vite 6:
es2020, Chrome87, Edge88, Firefox78, Safari14. Обновление bundler не меняет эту политику.

`pnpm --filter @pdlc/ui test:vite` — отдельный ручной gate: настоящий Vite build,
лицензии шрифтов, tree shaking и server render аватара. Он не включён в обычный
unit-набор. При общей интегрированной квалификации проверять также frontend/host
build и настоящий Storybook preview с тем же Vite. В ограниченном QA использовать
`RAYON_NUM_THREADS=2`; кеши сохранять.

Причины перехода и изменения defaults:
[Vite 7 migration](https://v7.vite.dev/guide/migration),
[Vite 8 migration](https://vite.dev/guide/migration).

### Жизненный цикл SSR-страниц

`installServerProduct` возвращает `ServerProductController` для оболочки,
которая остаётся открытой при замене рабочего блока. `canLeave()` проверяет
черновики и запрашивает подтверждение, сохраняя действующую страницу до успеха
перехода. Продукт завершает её обработчики и `onDiscard` при фактической замене.
После инициализации новых форм вызвать `trackForms(root)`; удалённые формы
освобождаются. `retire()` завершает защищённый документ при смене доступа; `isCurrent()` проверяет исходное окно допуска. Эти операции
не подтверждают новые права и не продлевают срок имеющегося допуска.

### Compact tag editing

`BadgeInput` / SSR `badge_input` matches Badge geometry:26px, or24px inline inside a Badge. Ordinary forms retain Input. The caller owns click-to-edit, Enter/blur commit, Escape cancel, validation and acknowledgement. Pair with sibling BadgeButton label/remove actions; never nest native buttons.

### Label typography

Label and SSR label_control use --base-font-label (12px standard,14px large); field values use --base-font-body (14/16px). Both follow the published branding type_scale. Products reuse this class rather than copying a smaller local font size. Label geometry does not reduce the associated control target.

### Inline field alignment

Input/Textarea with appearance="inline" remove horizontal padding and border width so editable text aligns with adjacent static content. Their focus indication, autosize and existing height rules remain. Default form fields and reserved search/action adornment padding keep their standard geometry.

## Изменения 0.3.20

- ResourceListHeader оформляет подписи колонок с теми же insets, что строки
  коллекции. Сетка, responsive visibility и native semantics остаются у продукта.
- Skin уведомлений Sonner/SSR использует общие tokens. Поздняя загрузка React
  adapter CSS не меняет плотность, шрифт и радиусы.

Публичные контракты 0.3.19 сохраняются. Новая часть коллекции пока не имеет SSR macro.

Используйте plugin, а не только cacheDir: Vite включает его имя с production hash в browser dependency hash. Это предотвращает смешивание разных React/provider graphs после тёплого запуска. createUiDevCacheDir остаётся низкоуровневым Node helper пути; он сам по себе не управляет browser cache.
