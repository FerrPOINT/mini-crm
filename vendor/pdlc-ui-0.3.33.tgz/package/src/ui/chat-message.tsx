import { forwardRef, type HTMLAttributes, type ReactNode } from "react";
import { cn } from "../lib/utils";

export interface ChatMessageProps extends HTMLAttributes<HTMLElement> {
  /** Product-supplied author, time, delivery status and actions. */
  header: ReactNode;
  /** An optional avatar or icon; its accessible name remains caller-owned. */
  avatar?: ReactNode;
}

/** Message layout only; content, history, streaming and delivery belong to the product. */
export const ChatMessage = forwardRef<HTMLElement, ChatMessageProps>(
  function ChatMessage({ avatar, header, children, className, ...props }, ref) {
    const hasAvatar = Boolean(avatar) || avatar === 0;
    return (
      <article
        {...props}
        ref={ref}
        className={cn("base-chat-message", className)}
        data-avatar={hasAvatar ? "true" : undefined}
      >
        {hasAvatar && <div className="base-chat-message-avatar">{avatar}</div>}
        <header className="base-chat-message-header">{header}</header>
        <div className="base-chat-message-content">{children}</div>
      </article>
    );
  },
);
