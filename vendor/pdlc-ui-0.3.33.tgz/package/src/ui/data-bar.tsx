import * as React from "react";
import { cn } from "../lib/utils";
import { barPercent } from "./bar-value";

export interface DataBarSegment {
  id: string;
  /** A drawing magnitude, not an accounting amount or a loading state. */
  value: number;
  tone?: "accent" | "success" | "danger" | "warning" | "muted" | "info";
}

export interface DataBarProps extends Omit<
  React.HTMLAttributes<HTMLDivElement>,
  "children" | "role" | "aria-label" | "aria-hidden"
> {
  segments: readonly DataBarSegment[];
  max?: number;
  /** Omit when equivalent facts already name this decorative picture nearby. */
  label?: string;
}

/** Static proportion/distribution graphic. Grouping, scale, labels and exact units stay owner-supplied. */
export const DataBar = React.forwardRef<HTMLDivElement, DataBarProps>(
  function DataBar({ segments, max = 100, label, className, ...props }, ref) {
    const known =
      Number.isFinite(max) &&
      max > 0 &&
      segments.every((item) => Number.isFinite(item.value));
    return (
      <div
        {...props}
        ref={ref}
        className={cn("base-data-bar", className)}
        role={label ? "img" : undefined}
        aria-label={label || undefined}
        aria-hidden={label ? undefined : true}
        data-unknown={!known || undefined}
      >
        {segments.map((segment) => (
          <span
            key={segment.id}
            className="base-data-bar-segment"
            data-tone={segment.tone ?? "accent"}
            style={{ width: `${barPercent(segment.value, max)}%` }}
          />
        ))}
      </div>
    );
  },
);
