import type { ComponentProps, ReactNode } from "react";
import { cn } from "../lib/utils";
import { useUiLabels } from "./labels";

export type CodeBlockProps = ComponentProps<"pre"> & { wrap?: boolean };

/** Presentation only: products provide already-authorized, redacted text. */
export function CodeBlock({
  wrap = true,
  className,
  children,
  ...props
}: CodeBlockProps) {
  const labels = useUiLabels();
  return (
    <pre
      role="region"
      tabIndex={0}
      aria-label={props["aria-labelledby"] ? undefined : labels.code}
      {...props}
      data-wrap={wrap ? "true" : "false"}
      className={cn("base-code-block", className)}
    >
      {children}
    </pre>
  );
}

export type JsonBlockProps = Omit<CodeBlockProps, "children"> & {
  value: unknown;
};

export function JsonBlock({ value, ...props }: JsonBlockProps) {
  return (
    <CodeBlock
      aria-label={props["aria-labelledby"] ? undefined : "JSON"}
      {...props}
    >
      {JSON.stringify(value, null, 2)}
    </CodeBlock>
  );
}

export type DiffBlockProps = Omit<CodeBlockProps, "children"> & {
  patch: string;
  notice?: ReactNode;
};

/** A unified diff remains plain selectable text; signs also convey additions/deletions. */
export function DiffBlock({
  patch,
  notice,
  className,
  wrap = false,
  ...props
}: DiffBlockProps) {
  const labels = useUiLabels();
  const lines = patch.split("\n");
  return (
    <div className="min-w-0 space-y-2">
      {notice && (
        <p role="status" className="text-sm text-text-muted">
          {notice}
        </p>
      )}
      <CodeBlock
        aria-label={props["aria-labelledby"] ? undefined : labels.diff}
        {...props}
        wrap={wrap}
        className={cn("max-h-[48rem] leading-relaxed", className)}
      >
        {lines.map((line, index) => {
          // File headers precede +/- content rules, including in an otherwise empty diff.
          const tone =
            /^(\+\+\+|---)[ \t]/.test(line) || line.startsWith("@@")
              ? "text-accent"
              : line.startsWith("+")
                ? "bg-success/10 text-success"
                : line.startsWith("-")
                  ? "bg-danger/10 text-danger"
                  : line.startsWith("diff --git") || line.startsWith("index ")
                    ? "text-text-muted"
                    : "text-text-secondary";
          return (
            <span key={index} className={tone}>
              {line}
              {index < lines.length - 1 ? "\n" : null}
            </span>
          );
        })}
      </CodeBlock>
    </div>
  );
}
