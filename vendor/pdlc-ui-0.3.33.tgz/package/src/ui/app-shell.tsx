import { SidebarList } from "./sidebar-list";
import { AccountMenu } from "./account-menu";
import {
  useCallback,
  useId,
  useRef,
  useState,
  type ComponentProps,
  type ElementType,
  type ReactNode,
} from "react";
import {
  NamespaceLink as Link,
  NamespaceNavLink as NavLink,
} from "./namespace-link";
import { PanelLeftClose, PanelLeftOpen } from "lucide-react";
import { Button } from "./button";
import { useMediaQuery } from "../lib/use-media-query";

import { SidebarItem, SidebarItemLabel } from "./sidebar-item";
import { NavigationDrawer } from "./navigation-drawer";

import { PageFrame, type PageLayoutMode } from "./page-frame";
import { PlatformHeader } from "./platform-header";
import { PlatformMark } from "./platform-mark";

import { useUiLabels } from "./labels";
import { useLocation } from "react-router";
import {
  SidebarNavigationGroup,
  useSidebarDisclosure,
} from "./sidebar-navigation-group";

const compactSidebarQuery = "(min-width: 768px) and (max-width: 1279px)";

export interface ShellNavItem {
  to: string;
  label: string;
  icon: ElementType;
  end?: boolean;
  active?: boolean;
}

export interface AppShellProps {
  currentServiceKey: string;
  title: string;
  description?: string;
  navigation?: readonly ShellNavItem[];
  /** Product navigation data and permissions stay with the caller; Base owns both placements. */
  renderNavigation?: (context: {
    compact: boolean;
    mobile: boolean;
    onNavigate: () => void;
  }) => ReactNode;
  /** Insert the shared mobile trigger into a product-specific PlatformHeader composition. */
  renderHeader?: (navigationTrigger: ReactNode) => ReactNode;
  /** Optional existing per-application preference key. Storage failures never disable navigation. */
  sidebarStorageKey?: string;
  secondaryNavigation?: readonly ShellNavItem[];
  secondaryNavigationLabel?: string;
  /** Toggle the wide desktop preference; 768-1279 stays compact and mobile uses its drawer. */
  collapsibleSidebar?: boolean;
  layout?: PageLayoutMode;
  context?: ReactNode;
  actions?: ReactNode;
  account?: ComponentProps<typeof AccountMenu>["account"];
  children: ReactNode;
}

export function AppShell({
  currentServiceKey,
  title,
  description,
  navigation = [],
  renderNavigation,
  renderHeader,
  sidebarStorageKey,
  secondaryNavigation = [],
  secondaryNavigationLabel = "Служебное",
  layout = "wide",
  collapsibleSidebar = false,
  context,
  actions,
  account,
  children,
}: AppShellProps) {
  const labels = useUiLabels();
  const explicitSidebar = collapsibleSidebar || Boolean(renderNavigation);
  const { pathname } = useLocation();
  const secondaryActive = secondaryNavigation.some(
    (item) =>
      item.active ??
      (pathname === item.to.split("?")[0] ||
        pathname.startsWith(item.to.split("?")[0] + "/")),
  );
  const secondaryDisclosure = useSidebarDisclosure(
    secondaryActive ? pathname : null,
  );
  const [open, setOpen] = useState(false);
  const mainRef = useRef<HTMLElement>(null);
  const sidebarToggleRef = useRef<HTMLButtonElement>(null);
  const focusCompactSidebar = useCallback((compact: boolean) => {
    if (compact && document.activeElement === sidebarToggleRef.current)
      mainRef.current?.focus();
  }, []);
  const compactViewport = useMediaQuery(
    compactSidebarQuery,
    focusCompactSidebar,
  );
  function readPreference(key?: string) {
    try {
      return Boolean(
        key &&
        typeof window !== "undefined" &&
        window.localStorage.getItem(key) === "true",
      );
    } catch {
      return false;
    }
  }
  const [sidebar, setSidebar] = useState(() => ({
    key: sidebarStorageKey,
    collapsed: readPreference(sidebarStorageKey),
  }));
  // A new preference key selects its own value without writing the previous application's state.
  const preferenceCollapsed =
    sidebar.key === sidebarStorageKey
      ? sidebar.collapsed
      : readPreference(sidebarStorageKey);
  const collapsed = compactViewport || preferenceCollapsed;
  function toggleSidebar() {
    if (compactViewport) return;
    const next = !preferenceCollapsed;
    setSidebar({ key: sidebarStorageKey, collapsed: next });
    try {
      if (sidebarStorageKey)
        window.localStorage.setItem(sidebarStorageKey, String(next));
    } catch {
      /* The current view remains usable when browser storage is unavailable. */
    }
  }
  const sidebarId = useId();
  function links(
    items: readonly ShellNavItem[],
    drawer: boolean,
    label = labels.navigation,
  ) {
    return (
      <SidebarList asChild className="base-shell-navigation">
        <nav aria-label={label}>
          {items.map(({ to, label, icon: Icon, end, active }) => {
            const Target = active === undefined ? NavLink : Link;
            return (
              <SidebarItem key={to} asChild active={active} className="base-shell-link min-h-11">
                <Target
                  to={to}
                  {...(active === undefined ? { end: end ?? to === "/" } : {})}
                  aria-label={label}
                  aria-current={active === undefined ? undefined : active ? "page" : false}
                  title={label}
                  onClick={() => setOpen(false)}
                >
                  <Icon className="h-5 w-5 shrink-0" aria-hidden />
                  <SidebarItemLabel className={drawer ? "" : "base-shell-nav-label"}>{label}</SidebarItemLabel>
                </Target>
              </SidebarItem>
            );
          })}
        </nav>
      </SidebarList>
    );
  }
  function nav(drawer = false) {
    if (renderNavigation)
      return renderNavigation({
        compact: !drawer && collapsed,
        mobile: drawer,
        onNavigate: () => setOpen(false),
      });
    return (
      <>
        {links(navigation, drawer)}
        {secondaryNavigation.length > 0 && (
          <SidebarNavigationGroup
            label={secondaryNavigationLabel}
            active={secondaryActive}
            compact={
              drawer ? false : explicitSidebar ? collapsed : "responsive"
            }
            {...secondaryDisclosure}
          >
            {links(secondaryNavigation, drawer, secondaryNavigationLabel)}
          </SidebarNavigationGroup>
        )}
      </>
    );
  }
  const navigationTrigger = (
    <NavigationDrawer
      title={title}
      open={open}
      onOpenChange={setOpen}
      desktopFocusRef={mainRef}
    >
      {nav(true)}
    </NavigationDrawer>
  );
  return (
    <div
      className="base-app-shell"
      data-base-shell
      data-sidebar-mode={
        explicitSidebar ? (collapsed ? "compact" : "expanded") : undefined
      }
    >
      {renderHeader ? (
        renderHeader(navigationTrigger)
      ) : (
        <PlatformHeader
          currentServiceKey={currentServiceKey}
          leading={
            <>
              {navigationTrigger}
              <Button asChild variant="ghost" size="icon">
                <Link to="/" aria-label={title} title={description ?? title}>
                  <PlatformMark size="shell" withName={false} />
                </Link>
              </Button>
            </>
          }
          context={context}
          actions={
            <>
              {actions}
              <AccountMenu account={account} />
            </>
          }
        />
      )}
      <aside
        id={sidebarId}
        className="base-shell-sidebar"
        aria-label={labels.navigation}
      >
        {explicitSidebar && !compactViewport && (
          <div className="base-shell-sidebar-toolbar">
            <span className="base-shell-nav-label base-shell-sidebar-label">
              {labels.navigation}
            </span>
            <Button
              ref={sidebarToggleRef}
              variant="ghost"
              size="icon"
              aria-label={
                collapsed ? labels.expandSidebar : labels.collapseSidebar
              }
              title={collapsed ? labels.expandSidebar : labels.collapseSidebar}
              aria-expanded={!collapsed}
              aria-controls={sidebarId}
              onClick={toggleSidebar}
            >
              {collapsed ? (
                <PanelLeftOpen className="h-4 w-4" aria-hidden />
              ) : (
                <PanelLeftClose className="h-4 w-4" aria-hidden />
              )}
            </Button>
          </div>
        )}
        <div className="base-shell-navigation-scroll">{nav()}</div>
      </aside>
      <div className="base-shell-work">
        <main
          ref={mainRef}
          tabIndex={-1}
          className="shell-main base-shell-main"
        >
          <PageFrame mode={layout}>{children}</PageFrame>
        </main>
      </div>
    </div>
  );
}
