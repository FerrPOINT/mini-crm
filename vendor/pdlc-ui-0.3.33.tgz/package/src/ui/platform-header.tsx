import type { ReactNode } from "react";
import { ServiceSwitcher } from "./service-switcher";

export interface PlatformHeaderProps {
  currentServiceKey: string;
  leading: ReactNode;
  context?: ReactNode;
  actions?: ReactNode;
  /** Synthetic compositions can omit navigation without substituting a copied header. */
  serviceSwitcher?: boolean;
}

export function PlatformHeader({
  currentServiceKey,
  leading,
  context,
  actions,
  serviceSwitcher = true,
}: PlatformHeaderProps) {
  return (
    <header className="platform-header" data-platform-header>
      <div
        className="platform-header-leading"
        data-platform-header-slot="leading"
      >
        {leading}
      </div>
      {serviceSwitcher && (
        <div
          className="platform-header-services"
          data-platform-header-slot="services"
        >
          <ServiceSwitcher currentKey={currentServiceKey} showCurrentLabel />
        </div>
      )}
      {context && (
        <div
          className="platform-header-context"
          data-platform-header-slot="context"
        >
          {context}
        </div>
      )}
      {actions && (
        <div
          className="platform-header-actions"
          data-platform-header-slot="actions"
        >
          {actions}
        </div>
      )}
    </header>
  );
}
