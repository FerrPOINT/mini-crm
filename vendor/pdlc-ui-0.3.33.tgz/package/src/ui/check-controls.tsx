import {
  forwardRef,
  useEffect,
  useId,
  useLayoutEffect,
  useRef,
  useState,
  type InputHTMLAttributes,
  type HTMLAttributes,
  type ReactNode,
} from "react";
import { useComposedRefs } from "@radix-ui/react-compose-refs";
import { cn } from "../lib/utils";

type CheckState = boolean | "indeterminate";
export interface CheckboxProps extends Omit<
  InputHTMLAttributes<HTMLInputElement>,
  "type" | "checked" | "defaultChecked" | "onChange"
> {
  checked?: CheckState;
  defaultChecked?: CheckState;
  onCheckedChange?: (checked: CheckState) => void;
  label?: string;
  children?: ReactNode;
  /** Card framing for rich option content; selection remains the native input state. */
  appearance?: "default" | "card";
  /** Label emphasis only; checked, invalid and disabled keep their native meaning. */
  labelTone?: "default" | "secondary" | "danger";
  onChange?: InputHTMLAttributes<HTMLInputElement>["onChange"];
}
/** Native validity, fieldset disabling, submission and keyboard behavior remain authoritative. */
export const Checkbox = forwardRef<HTMLInputElement, CheckboxProps>(
  function Checkbox(
    {
      checked,
      defaultChecked = false,
      onCheckedChange,
      onChange,
      label,
      children,
      appearance = "default",
      labelTone = "default",
      className,
      id,
      role,
      ...props
    },
    forwardedRef,
  ) {
    const generated = useId();
    const inputId = id ?? generated;
    const input = useRef<HTMLInputElement>(null);
    const ref = useComposedRefs(forwardedRef, input);
    const [local, setLocal] = useState(defaultChecked);
    const state = checked ?? local;
    useLayoutEffect(() => {
      if (input.current)
        input.current.indeterminate = state === "indeterminate";
    }, [state]);
    useEffect(() => {
      const form = input.current?.form;
      const reset = (event: Event) => {
        queueMicrotask(() => {
          if (!event.defaultPrevented && checked === undefined)
            setLocal(defaultChecked);
        });
      };
      form?.addEventListener("reset", reset);
      return () => form?.removeEventListener("reset", reset);
    }, [checked, defaultChecked, props.form]);
    const labelContent = label ?? children;
    const hasLabel = labelContent !== undefined && labelContent !== null;
    const Wrapper = hasLabel ? "label" : "span";
    return (
      <Wrapper
        {...(hasLabel ? { htmlFor: inputId } : {})}
        className={cn(
          "base-check-field",
          hasLabel && "base-control min-h-10",
          className,
        )}
        data-disabled={props.disabled || undefined}
        data-appearance={appearance}
        data-label-tone={
          labelTone === "secondary" || labelTone === "danger"
            ? labelTone
            : undefined
        }
      >
        <input
          {...props}
          role={role}
          id={inputId}
          ref={ref}
          type="checkbox"
          checked={state === true}
          aria-checked={state === "indeterminate" ? "mixed" : state}
          className="base-check-input"
          onChange={(event) => {
            onChange?.(event);
            if (event.defaultPrevented) return;
            const next = event.currentTarget.checked;
            if (checked === undefined) setLocal(next);
            onCheckedChange?.(next);
          }}
        />
        <span
          aria-hidden
          className={
            role === "switch" ? "base-switch-indicator" : "base-check-indicator"
          }
          data-state={String(state)}
        />
        {hasLabel && <span className="base-check-label">{labelContent}</span>}
      </Wrapper>
    );
  },
);
export interface SwitchProps extends Omit<
  CheckboxProps,
  "checked" | "defaultChecked" | "onCheckedChange" | "role"
> {
  checked?: boolean;
  defaultChecked?: boolean;
  onCheckedChange?: (checked: boolean) => void;
}
export const Switch = forwardRef<HTMLInputElement, SwitchProps>(function Switch(
  { onCheckedChange, ...props },
  ref,
) {
  return (
    <Checkbox
      {...props}
      ref={ref}
      role="switch"
      onCheckedChange={(value) => onCheckedChange?.(value === true)}
    />
  );
});

export interface RadioGroupProps extends Omit<
  HTMLAttributes<HTMLDivElement>,
  "onChange" | "defaultValue"
> {
  options: readonly { value: string; label: string; disabled?: boolean }[];
  value?: string;
  defaultValue?: string;
  onValueChange?: (value: string) => void;
  name?: string;
  form?: string;
  required?: boolean;
  disabled?: boolean;
  label?: string;
  /** Same native single-choice contract, with an attached mode selector appearance. */
  appearance?: "default" | "segmented";
}
export const RadioGroup = forwardRef<HTMLDivElement, RadioGroupProps>(
  function RadioGroup(
    {
      options,
      value,
      defaultValue = "",
      onValueChange,
      name,
      form,
      required,
      disabled,
      label,
      appearance = "default",
      className,
      ...props
    },
    ref,
  ) {
    const id = useId();
    const [local, setLocal] = useState(defaultValue);
    const first = useRef<HTMLInputElement>(null);
    useEffect(() => {
      const owner = first.current?.form;
      const reset = (event: Event) => {
        queueMicrotask(() => {
          if (!event.defaultPrevented && value === undefined)
            setLocal(defaultValue);
        });
      };
      owner?.addEventListener("reset", reset);
      return () => owner?.removeEventListener("reset", reset);
    }, [value, defaultValue, form, options.length]);
    return (
      <div
        {...props}
        ref={ref}
        role="radiogroup"
        aria-label={label ?? props["aria-label"]}
        aria-required={required}
        aria-disabled={disabled}
        data-appearance={appearance}
        className={cn("base-radio-group", className)}
      >
        {options.map((option, index) => (
          <label
            key={option.value}
            className="base-check-field"
            data-disabled={disabled || option.disabled || undefined}
          >
            <input
              ref={index === 0 ? first : undefined}
              className="base-check-input"
              type="radio"
              name={name ?? id}
              form={form}
              value={option.value}
              checked={(value ?? local) === option.value}
              disabled={disabled || option.disabled}
              required={required}
              onChange={(event) => {
                if (!event.currentTarget.checked) return;
                if (value === undefined) setLocal(option.value);
                onValueChange?.(option.value);
              }}
            />
            <span aria-hidden className="base-radio-indicator" />
            <span>{option.label}</span>
          </label>
        ))}
      </div>
    );
  },
);
