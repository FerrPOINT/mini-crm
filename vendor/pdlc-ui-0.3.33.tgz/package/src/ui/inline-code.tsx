import { forwardRef, type HTMLAttributes } from "react";
import { cn } from "../lib/utils";

/** Native inline code; content, redaction and copy actions stay with the caller. */
export const InlineCode = forwardRef<HTMLElement, HTMLAttributes<HTMLElement>>(
  function InlineCode({ className, ...props }, ref) {
    return (
      <code
        {...props}
        ref={ref}
        className={cn("base-inline-code", className)}
      />
    );
  },
);
