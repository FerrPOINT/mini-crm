import * as React from "react";
import { cn } from "../lib/utils";

export interface FieldsetProps extends React.FieldsetHTMLAttributes<HTMLFieldSetElement> {
  /** Native group name; omission is useful for an inherited disabled boundary. */
  legend?: React.ReactNode;
  /** Preserve the accessible group name without repeating a visible heading. */
  legendVisuallyHidden?: boolean;
  /** Separate this group from preceding content using the current density tokens. */
  separated?: boolean;
}

/** Native disabled/form semantics, with shared presentation and no synthetic events. */
export const Fieldset = React.forwardRef<HTMLFieldSetElement, FieldsetProps>(
  (
    {
      legend,
      legendVisuallyHidden = false,
      separated = false,
      className,
      children,
      ...props
    },
    ref,
  ) => (
    <fieldset
      {...props}
      ref={ref}
      className={cn("base-fieldset", className)}
      data-separated={separated || undefined}
    >
      {legend !== undefined && legend !== null && legend !== false && (
        <legend
          className="base-fieldset-legend"
          data-visually-hidden={legendVisuallyHidden || undefined}
        >
          {legend}
        </legend>
      )}
      {children}
    </fieldset>
  ),
);
Fieldset.displayName = "Fieldset";
