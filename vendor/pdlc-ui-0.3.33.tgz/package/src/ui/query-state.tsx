import type { ReactNode } from "react";
import { Inbox } from "lucide-react";
import { useTranslation } from "react-i18next";
import { EmptyState, LoadingState } from "./async-states";
import { ResourceStateView, resourceErrorState } from "./page-patterns";

export interface QueryStateProps<T> {
  data: T | undefined;
  isLoading: boolean;
  error: unknown;
  errorMessage?: string;
  isEmpty?: (data: T) => boolean;
  empty?: { title?: string; description?: string; action?: ReactNode };
  onRetry?: () => void;
  children: ReactNode | ((data: T) => ReactNode);
  scope?: "page" | "local";
}

/** The product owns queries and DTOs; Base owns their mutually exclusive UI states. */
export function QueryState<T>({
  data,
  isLoading,
  error,
  errorMessage,
  isEmpty,
  empty,
  onRetry,
  children,
  scope = "page",
}: QueryStateProps<T>) {
  const { t } = useTranslation();
  if (isLoading) return <LoadingState scope={scope} />;
  if (error) {
    const state = resourceErrorState(error, onRetry, { message: errorMessage });
    return <ResourceStateView state={state} scope={scope} />;
  }
  // A disabled/unstarted query has not confirmed an empty result.
  if (data === undefined) return <LoadingState scope={scope} />;
  if (data === null || isEmpty?.(data)) {
    return (
      <EmptyState
        message={empty?.title ?? t("common.empty")}
        description={empty?.description}
        action={empty?.action}
        icon={<Inbox className="h-8 w-8" aria-hidden="true" />}
      />
    );
  }
  return <>{typeof children === "function" ? children(data) : children}</>;
}
