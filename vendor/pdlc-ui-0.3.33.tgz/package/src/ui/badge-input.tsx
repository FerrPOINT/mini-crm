import * as React from "react";
import { cn } from "../lib/utils";
import type { Badge } from "./badge";
interface BadgeInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  tone?: React.ComponentProps<typeof Badge>["tone"];
  appearance?: "badge" | "inline";
}
/** Native text field matching compact tags; the caller owns editing and persistence. */
export const BadgeInput = React.forwardRef<HTMLInputElement, BadgeInputProps>(
  (
    {
      tone = "neutral",
      appearance = "badge",
      type = "text",
      className,
      ...props
    },
    ref,
  ) => (
    <input
      {...props}
      ref={ref}
      type={type}
      className={cn("base-badge base-badge-input", className)}
      data-tone={tone}
      data-appearance={appearance}
    />
  ),
);
BadgeInput.displayName = "BadgeInput";
