import { Select } from "./select";
import { ProjectPicker } from "./project-picker";
/** Controlled shell primitive. Catalog, authorization and URL resolution belong to the consumer. */
export interface NamespacePickerOption {
  value: string;
  label: string;
  projectKey?: string;
}
export interface NamespacePickerProps {
  value: string;
  options: NamespacePickerOption[];
  loading?: boolean;
  unavailable?: boolean;
  onChange: (value: string) => void;
  /** @deprecated Overview navigation belongs to the product, not this picker. */
  manageUrl?: string;
  projectIcons?: boolean;
}
export function NamespacePicker({
  value,
  options,
  loading,
  unavailable,
  onChange,
  projectIcons = false,
}: NamespacePickerProps) {
  const missing =
    value !== "" && !options.some((option) => option.value === value);
  return (
    <div className="flex min-w-0 items-center gap-2" data-namespace-picker>
      <label className="sr-only" htmlFor="platform-namespace">
        Namespace
      </label>
      {projectIcons || options.some((option) => option.projectKey) ? (
        <ProjectPicker
          id="platform-namespace"
          aria-label="Namespace"
          value={value}
          options={
            missing
              ? [...options, { value, label: "Связь недоступна" }]
              : options
          }
          placeholder={loading ? "Загрузка…" : "Все проекты"}
          disabled={loading || unavailable}
          aria-describedby={unavailable ? "namespace-unavailable" : undefined}
          onChange={onChange}
          className="max-w-52"
        />
      ) : (
        <Select
          id="platform-namespace"
          value={value}
          onValueChange={onChange}
          disabled={loading || unavailable}
          aria-describedby={unavailable ? "namespace-unavailable" : undefined}
          className="max-w-52"
          options={[
            { value: "", label: loading ? "Загрузка…" : "Все проекты" },
            ...(missing ? [{ value, label: "Связь недоступна" }] : []),
            ...options,
          ]}
        />
      )}
      {unavailable && (
        <span id="namespace-unavailable" className="text-xs text-warning">
          Недоступно
        </span>
      )}
    </div>
  );
}
