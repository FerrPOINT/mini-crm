import {
  Link,
  NavLink,
  useLocation,
  useNavigate,
  type LinkProps,
  type NavLinkProps,
  type To,
  type NavigateFunction,
  type NavigateOptions,
} from "react-router";
import { useCallback } from "react";

export function contextualTarget(to: To, search: string): To {
  const source = new URLSearchParams(search);
  const parts =
    typeof to === "string" ? to.match(/^([^?#]*)(\?[^#]*)?(#.*)?$/) : null;
  if (
    typeof to === "string" &&
    (!parts || /^(?:[a-z][a-z0-9+.-]*:|\/\/)/i.test(to))
  )
    return to;
  const target = new URLSearchParams(
    typeof to === "string" ? parts?.[2] : to.search,
  );
  if (!target.has("namespace_id") && !target.has("registry_instance_id")) {
    for (const key of ["registry_instance_id", "namespace_id"]) {
      for (const value of source.getAll(key)) target.append(key, value);
    }
  }
  if (!target.has('project_scope') && source.get('project_scope') === 'all') target.set('project_scope', 'all')
  const query = target.size ? `?${target}` : "";
  return typeof to === "string"
    ? `${parts?.[1] ?? ""}${query}${parts?.[3] ?? ""}`
    : { ...to, search: query };
}

export function useNamespaceNavigate(): NavigateFunction {
  const navigate = useNavigate();
  const { search } = useLocation();
  return useCallback(
    (to: To | number, options?: NavigateOptions) =>
      typeof to === "number"
        ? navigate(to)
        : navigate(contextualTarget(to, search), options),
    [navigate, search],
  ) as NavigateFunction;
}

/** Transport URL context only. Each product resolves and verifies its own binding. */
export function NamespaceLink({ to, ...props }: LinkProps) {
  const location = useLocation();
  return <Link to={contextualTarget(to, location.search)} {...props} />;
}

export function NamespaceNavLink({ to, ...props }: NavLinkProps) {
  const { search } = useLocation();
  return <NavLink to={contextualTarget(to, search)} {...props} />;
}
