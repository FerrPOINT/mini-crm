import {
  forwardRef,
  useId,
  type InputHTMLAttributes,
  type ReactNode,
} from "react";
import { cn } from "../lib/utils";
import type { CheckboxProps } from "./check-controls";
/** Single native group part for rich product option compositions; prefer RadioGroup for plain options. */
export const Radio = forwardRef<
  HTMLInputElement,
  Omit<InputHTMLAttributes<HTMLInputElement>, "type" | "onChange"> & {
    onCheckedChange?: (checked: boolean) => void;
    label?: string;
    children?: ReactNode;
    /** Rich option framing without a second click handler or selection state. */
    appearance?: "default" | "card";
    /** Label emphasis is independent from selection and native validity. */
    labelTone?: CheckboxProps["labelTone"];
  }
>(function Radio(
  {
    onCheckedChange,
    className,
    label,
    children,
    appearance = "default",
    labelTone = "default",
    id,
    ...props
  },
  ref,
) {
  const generated = useId();
  const inputId = id ?? generated;
  const labelContent = label ?? children;
  const hasLabel = labelContent !== undefined && labelContent !== null;
  const Wrapper = hasLabel ? "label" : "span";
  return (
    <Wrapper
      {...(hasLabel ? { htmlFor: inputId } : {})}
      className={cn(
        "base-check-field",
        hasLabel && "base-control min-h-10",
        className,
      )}
      data-appearance={appearance}
      data-label-tone={
        labelTone === "secondary" || labelTone === "danger"
          ? labelTone
          : undefined
      }
      data-disabled={props.disabled || undefined}
    >
      <input
        {...props}
        ref={ref}
        type="radio"
        id={inputId}
        className="base-check-input"
        onChange={(event) => {
          if (event.currentTarget.checked) onCheckedChange?.(true);
        }}
      />
      <span aria-hidden className="base-radio-indicator" />
      {hasLabel && <span className="base-check-label">{labelContent}</span>}
    </Wrapper>
  );
});
