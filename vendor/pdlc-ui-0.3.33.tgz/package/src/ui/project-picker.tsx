import { useState, type ComponentProps } from "react";
import { useChoiceTheme } from "./choice-field";
import { ChevronDown } from "lucide-react";
import { cn } from "../lib/utils";
import { ProjectAvatar } from "./project-avatar";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
} from "./dropdown-menu";

export interface ProjectPickerOption {
  value: string;
  label: string;
  projectKey?: string;
}
export interface ProjectPickerProps extends Omit<
  ComponentProps<"button">,
  "onChange"
> {
  value: string;
  options: ProjectPickerOption[];
  placeholder: string;
  allowEmpty?: boolean;
  onChange: (value: string) => void;
}
/** Keyboard, typeahead, selection and focus restoration are owned by the shared Radix menu. */
export function ProjectPicker({
  value,
  options,
  placeholder,
  allowEmpty = true,
  onChange,
  className,
  ...props
}: ProjectPickerProps) {
  const [trigger, setTrigger] = useState<HTMLButtonElement | null>(null);
  const [open, setOpen] = useState(false);
  const theme = useChoiceTheme(trigger, open);
  const selected = options.find((option) => option.value === value);
  return (
    <DropdownMenu modal={false} open={open} onOpenChange={setOpen}>
      <DropdownMenuTrigger asChild>
        <button
          {...props}
          ref={setTrigger}
          title={props.title ?? selected?.label ?? placeholder}
          type="button"
          value={value}
          className={cn(
            "base-project-picker base-control base-choice-trigger",
            className,
          )}
        >
          {selected?.projectKey && (
            <ProjectAvatar projectKey={selected.projectKey} size="xs" />
          )}
          <span className="min-w-0 flex-1 truncate">
            {selected?.label ?? placeholder}
          </span>
          <ChevronDown aria-hidden="true" className="h-4 w-4 shrink-0" />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent
        style={theme}
        align="end"
        className="base-project-picker-menu base-choice-panel base-choice-multiple"
      >
        <DropdownMenuRadioGroup value={value} onValueChange={onChange}>
          {allowEmpty && (
            <DropdownMenuRadioItem
              className="base-choice-option"
              value=""
              textValue={placeholder}
            >
              {placeholder}
            </DropdownMenuRadioItem>
          )}
          {options.map((option) => (
            <DropdownMenuRadioItem
              key={option.value}
              value={option.value}
              textValue={option.label}
              className="base-choice-option gap-2"
            >
              {option.projectKey && (
                <ProjectAvatar projectKey={option.projectKey} size="xs" />
              )}
              <span className="min-w-0 break-words">{option.label}</span>
            </DropdownMenuRadioItem>
          ))}
        </DropdownMenuRadioGroup>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
