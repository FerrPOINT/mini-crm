import { BrandingEditor as ExpandedBrandingEditor } from "../branding/editor";
import {
  createBrandDocument,
  type BrandDesignDocument,
  type MarkVariant,
} from "../branding/model";
import { BrandingMark } from "../branding/mark";
import {
  useMemo,
  useId,
  useState,
  useSyncExternalStore,
  type ReactNode,
} from "react";
import type { PlatformBranding } from "../lib/platform-branding";
import { Input } from "./input";
import { FormField, PageHeader } from "./page-patterns";
import { Fieldset } from "./fieldset";
import { defaultBranding } from "../lib/platform-branding";
import { BrandingScope } from "../lib/branding-scope";
import { normalizeBranding } from "../branding/normalize";
import { BrandingPresentationProvider } from "../branding/context";
import type { Theme } from "../lib/theme-types";
import { Button } from "./button";
import { ActionGroup } from "./action-group";
import { Badge } from "./badge";
import { Disclosure } from "./disclosure";
import {
  ResourceList,
  ResourceListHeader,
  ResourceListRow,
} from "./resource-list";
import { Card, CardContent, CardHeader, CardTitle } from "./card";
import { Textarea } from "./textarea";
import { Select } from "./select";
import { SectionHeader } from "./section-header";
import { Checkbox, RadioGroup, Switch } from "./check-controls";
import {
  Table,
  TableHeader,
  TableBody,
  TableRow,
  TableHead,
  TableCell,
} from "./table";
import {
  Dialog,
  DialogTrigger,
  DialogContent,
  DialogTitle,
  DialogDescription,
} from "./dialog";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
} from "./dropdown-menu";
import { PlatformHeader } from "./platform-header";
import { SidebarItem } from "./sidebar-item";
import { AccountMenu } from "./account-menu";
import { Toaster, toast } from "./notifications";

export interface BrandingEditorProps {
  /** Controlled presentation document. Persistence and authorization belong to the caller. */
  value: PlatformBranding;
  onChange: (value: PlatformBranding) => void;
  /** Locks every field while saving, viewing without permission, or retrying a saved revision. */
  disabled?: boolean;
}

function subscribeTheme(notify: () => void) {
  const observer = new MutationObserver(notify);
  observer.observe(document.documentElement, {
    attributes: true,
    attributeFilter: ["data-theme"],
  });
  return () => observer.disconnect();
}
function currentTheme(): Theme {
  const value = document.documentElement.dataset.theme;
  return value === "light" || value === "gray" ? value : "dark";
}

/** Actual Base controls inside a local presentation scope; no runtime publication or preference writes. */
export function BrandingPreview({
  value,
  theme: selectedTheme,
  assetUrls,
}: {
  value: PlatformBranding;
  theme?: Theme;
  assetUrls?: ReadonlyMap<string, string>;
}) {
  const id = useId();
  const storedTheme = useSyncExternalStore(
    subscribeTheme,
    currentTheme,
    () => "dark" as Theme,
  );
  const theme = selectedTheme ?? storedTheme;
  const candidate = useMemo(() => normalizeBranding(value), [value]);
  const [lastConfirmed, setConfirmed] = useState(
    () => candidate ?? normalizeBranding(defaultBranding)!,
  );
  const confirmed = candidate ?? lastConfirmed;
  if (candidate && candidate !== lastConfirmed) setConfirmed(candidate);
  const [checked, setChecked] = useState(true);
  const [enabled, setEnabled] = useState(false);
  const [selection, setSelection] = useState("one");
  const valid = candidate !== null;
  return (
    <section
      aria-label="Предпросмотр брендинга"
      className="base-branding-preview"
    >
      <SectionHeader title="Предпросмотр на компонентах Base" />
      {!valid && (
        <p role="status">
          Показана последняя корректная настройка. Завершите ввод полей.
        </p>
      )}
      <BrandingScope value={confirmed} theme={theme}>
        <BrandingPresentationProvider document={confirmed} theme={theme}>
          <PlatformHeader
            currentServiceKey="branding-preview"
            serviceSwitcher={false}
            leading={
              <span className="base-branding-identity">
                <BrandingMark
                  document={confirmed}
                  theme={theme}
                  size="shell"
                  assetUrls={assetUrls}
                />
                <span>{confirmed.product_short_name}</span>
              </span>
            }
            actions={
              confirmed.support_url || confirmed.design?.documentation_url ? (
                <AccountMenu showTheme={false} />
              ) : undefined
            }
          />
          <div className="base-branding-navigation">
            <SidebarItem active>Обзор</SidebarItem>
            <SidebarItem>Настройки</SidebarItem>
          </div>
          <Card>
            <CardHeader>
              <CardTitle>{confirmed.product_name}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="base-branding-samples">
                <ActionGroup align="start">
                  <Button
                    type="button"
                    onClick={() =>
                      toast.success("Локальное уведомление", { toasterId: id })
                    }
                  >
                    Действие
                  </Button>
                  <Button type="button" variant="outline">
                    Вторичное
                  </Button>
                  <Button type="button" disabled>
                    Недоступно
                  </Button>
                  <Button type="button" variant="link">
                    Ссылка
                  </Button>
                  <Button type="button" variant="destructive">
                    Опасное действие
                  </Button>
                </ActionGroup>
                <Fieldset legend="Поля формы">
                  <div className="base-branding-fields">
                    <FormField id={id + "name"} label="Название">
                      {(attrs) => (
                        <Input {...attrs} defaultValue="Пример приложения" />
                      )}
                    </FormField>
                    <FormField
                      id={id + "error"}
                      label="Проверка поля"
                      hint={
                        <span className="text-danger">
                          Пример сообщения об ошибке
                        </span>
                      }
                    >
                      {(attrs) => (
                        <Input
                          {...attrs}
                          aria-invalid
                          defaultValue="Неверное значение"
                        />
                      )}
                    </FormField>
                  </div>
                </Fieldset>
                <Textarea
                  aria-label="Описание примера"
                  defaultValue="Настоящие компоненты с общими tokens"
                />
                <div className="base-branding-options">
                  <Checkbox
                    label="Выбранный пункт"
                    checked={checked}
                    onCheckedChange={(value) => setChecked(value === true)}
                  />
                  <Switch
                    label="Включить режим"
                    checked={enabled}
                    onCheckedChange={setEnabled}
                  />
                </div>
                <div className="base-branding-fields">
                  <RadioGroup
                    label="Вид просмотра"
                    value={selection}
                    onValueChange={setSelection}
                    options={[
                      { value: "one", label: "Первый" },
                      { value: "two", label: "Второй" },
                    ]}
                  />
                  <Select
                    aria-label="Категория примера"
                    options={[
                      { value: "one", label: "Первый вариант" },
                      { value: "two", label: "Второй вариант" },
                    ]}
                    value={selection}
                    onValueChange={setSelection}
                  />
                </div>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Объект</TableHead>
                      <TableHead>Состояние</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell>Компонент Base</TableCell>
                      <TableCell>Готов</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
                <ActionGroup align="start" aria-label="Смысловые состояния">
                  <Badge tone="success">Готово</Badge>
                  <Badge tone="warning">Внимание</Badge>
                  <Badge tone="danger">Ошибка</Badge>
                </ActionGroup>
                <ResourceList variant="bordered" aria-label="Список примера" className="grid grid-cols-[minmax(0,1fr)_auto]">
                  <ResourceListHeader className="col-span-full grid grid-cols-subgrid gap-3">
                    <span>Ресурс</span>
                    <span>Состояние</span>
                  </ResourceListHeader>
                  <ResourceListRow className="col-span-full grid grid-cols-subgrid gap-3">
                    <span>Строка с общей плотностью</span>
                    <span>Готов</span>
                  </ResourceListRow>
                </ResourceList>
                <Disclosure summary="Дополнительные сведения">
                  Текст, отступы и поверхности используют тот же брендинг.
                </Disclosure>
                <ActionGroup align="start">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button type="button" variant="outline">
                        Меню примера
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent>
                      <DropdownMenuItem>Локальное действие</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button type="button" variant="outline">
                        Диалог примера
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogTitle>Диалог Base</DialogTitle>
                      <DialogDescription>
                        Тема, шрифт и геометрия наследуются от предпросмотра.
                      </DialogDescription>
                      <Input aria-label="Поле диалога" />
                    </DialogContent>
                  </Dialog>
                </ActionGroup>
              </div>
            </CardContent>
          </Card>
          <Toaster id={id} theme={theme === "light" ? "light" : "dark"} />
        </BrandingPresentationProvider>
      </BrandingScope>
      <p className="text-text-muted">
        Черновик не публикуется и не меняет оформление страницы редактора.
      </p>
    </section>
  );
}

/** Shared Admin/dictionary form. The caller owns the document and any save/publish workflow. */
export function BrandingEditor({
  value,
  onChange,
  disabled = false,
}: BrandingEditorProps) {
  const [variant, setVariant] = useState<MarkVariant>("common");
  const theme = useSyncExternalStore(
    subscribeTheme,
    currentTheme,
    () => "dark" as Theme,
  );
  const defaults = createBrandDocument();
  const document =
    normalizeBranding(value) ??
    ({
      ...defaults,
      ...value,
      design: { ...defaults.design, ...value.design },
    } as BrandDesignDocument);
  return (
    <div className="base-brand-editor-layout">
      <ExpandedBrandingEditor
        value={document}
        onChange={(next) => {
          if (disabled) return;
          if (next.design === document.design) {
            const flat: PlatformBranding = { ...next };
            delete flat.design;
            onChange(
              value.design === undefined
                ? flat
                : { ...flat, design: value.design },
            );
          } else onChange(next);
        }}
        disabled={disabled}
        variant={variant}
        onVariantChange={setVariant}
        colorTheme={theme}
        onUpload={() => undefined}
        uploadError=""
        uploadDisabledReason="Загрузка изображений доступна в Admin Panel."
      />
      <BrandingPreview value={value} theme={theme} />
    </div>
  );
}

export interface BrandingSettingsProps extends BrandingEditorProps {
  /** Application-specific actions; authorization and publication stay with the caller. */
  actions?: ReactNode;
  /** Override only for another workflow, such as a local dictionary demonstration. */
  description?: string;
  /** Loading, errors and revision notices supplied by the document owner. */
  children?: ReactNode;
}

/** Complete shared section, including heading, actions, status placement and editor geometry. */
export function BrandingSettings({
  actions,
  description = "Название, логотип, цвета, встроенный шрифт и геометрия платформы. Произвольный CSS не допускается.",
  children,
  ...editor
}: BrandingSettingsProps) {
  return (
    <div className="space-y-6" data-base-branding-settings>
      <PageHeader
        title="Брендинг платформы"
        context={description}
        actions={actions}
      />
      {children}
      <BrandingEditor {...editor} />
    </div>
  );
}
