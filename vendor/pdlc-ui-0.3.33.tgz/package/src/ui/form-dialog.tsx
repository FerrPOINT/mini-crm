import {
  useLayoutEffect,
  useRef,
  useState,
  type ReactNode,
  type RefObject,
  type FormEvent,
} from "react";
import { useTranslation } from "react-i18next";
import { Button } from "./button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogBody,
  DialogFooter,
} from "./dialog";
import { ConfirmDialog } from "./async-states";
import type { PendingFormProps } from "./page-patterns";
import { Fieldset } from "./fieldset";
import { useUiLabels } from "./labels";

export interface FormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: ReactNode;
  description?: ReactNode;
  children: ReactNode;
  actions?: ReactNode;
  /** Replaces the default cancel/actions row; undefined keeps the standard actions. */
  footer?: ReactNode;
  /** Recovery/status content outside the independently disabled draft fields. */
  bodyAfter?: ReactNode;
  /** Additional draft lock; pending always disables the entire form. */
  fieldsetDisabled?: boolean;
  dirty?: boolean;
  pending?: boolean;
  error?: string | null;
  onSubmit: NonNullable<PendingFormProps["onSubmit"]>;
  contentRef?: RefObject<HTMLDivElement | null>;
  returnFocusRef?: RefObject<HTMLElement | null>;
  fallbackFocusRef?: RefObject<HTMLElement | null>;
}

export function FormDialog({
  open,
  onOpenChange,
  title,
  description,
  children,
  actions,
  footer,
  bodyAfter,
  fieldsetDisabled = false,
  dirty = false,
  pending = false,
  error,
  onSubmit,
  contentRef,
  returnFocusRef,
  fallbackFocusRef,
}: FormDialogProps) {
  const labels = useUiLabels();
  const { t } = useTranslation();
  const [discardOpen, setDiscardOpen] = useState(false);
  const [wasOpen, setWasOpen] = useState(open);
  const [submitting, setSubmitting] = useState(false);
  const locked = useRef(false);
  const initiator = useRef<HTMLElement | null>(null);
  const busy = pending || submitting;

  if (wasOpen !== open) {
    setWasOpen(open);
    setDiscardOpen(false);
  }

  useLayoutEffect(() => {
    if (!open) return;
    if (
      document.activeElement instanceof HTMLElement &&
      document.activeElement !== document.body
    )
      initiator.current = document.activeElement;
  }, [open]);

  function requestClose(next: boolean) {
    if (next) {
      onOpenChange(true);
      return;
    }
    if (pending || locked.current) return;
    if (dirty) setDiscardOpen(true);
    else onOpenChange(false);
  }

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (pending || locked.current) return;
    locked.current = true;
    const release = () => {
      locked.current = false;
      setSubmitting(false);
    };
    try {
      const result = onSubmit(event);
      if (result) {
        setSubmitting(true);
        // The caller owns errors/readback; settling releases the form without replay.
        void Promise.resolve(result).then(release, release);
      } else queueMicrotask(release);
    } catch (error) {
      release();
      throw error;
    }
  }

  return (
    <>
      <Dialog open={open} onOpenChange={requestClose}>
        <DialogContent
          ref={contentRef}
          className="base-form-dialog"
          closeDisabled={busy}
          {...(description == null || description === false
            ? { "aria-describedby": undefined }
            : {})}
          onKeyDown={(event) => {
            // Radix's tabbable scan does not account for the disabled parent fieldset.
            if (
              busy &&
              event.key === "Tab" &&
              event.target === event.currentTarget
            )
              event.preventDefault();
          }}
          onCloseAutoFocus={(event) => {
            const target = [
              returnFocusRef?.current,
              initiator.current,
              fallbackFocusRef?.current,
            ].find(
              (element) =>
                element?.isConnected &&
                !element.matches(":disabled,[hidden],[inert]") &&
                !element.closest("[hidden],[inert]"),
            );
            if (target) {
              event.preventDefault();
              target.focus();
            }
          }}
        >
          <DialogHeader>
            <DialogTitle className="break-words">{title}</DialogTitle>
            {description != null && description !== false && (
              <DialogDescription className="break-words">
                {description}
              </DialogDescription>
            )}
          </DialogHeader>
          <form
            onSubmit={submit}
            aria-busy={busy || undefined}
            className="base-form-dialog-form"
          >
            <Fieldset disabled={busy} className="base-form-dialog-fields">
              <DialogBody
                onFocusCapture={(event) => {
                  const target = event.target;
                  const body = event.currentTarget;
                  // Dialog autofocus deliberately prevents page scrolling. Reveal
                  // off-screen controls within the form's own scroll region instead.
                  if (
                    !(target instanceof HTMLElement) ||
                    !body.contains(target)
                  )
                    return;
                  const region = body.getBoundingClientRect();
                  const control = target.getBoundingClientRect();
                  const style = getComputedStyle(body);
                  const start = parseFloat(style.scrollPaddingBlockStart) || 0;
                  const end = parseFloat(style.scrollPaddingBlockEnd) || 0;
                  if (
                    control.top < region.top + start ||
                    control.bottom > region.bottom - end
                  )
                    target.scrollIntoView({
                      block: "nearest",
                      inline: "nearest",
                    });
                }}
              >
                <Fieldset
                  disabled={busy || fieldsetDisabled}
                  className="base-page-stack"
                >
                  {error && (
                    <p role="alert" className="break-words text-sm text-danger">
                      {error}
                    </p>
                  )}
                  {children}
                </Fieldset>
                {bodyAfter}
              </DialogBody>
              {footer !== null && (
                <DialogFooter>
                  {footer === undefined ? (
                    <>
                      <Button
                        type="button"
                        variant="secondary"
                        onClick={() => requestClose(false)}
                      >
                        {t("common.cancel")}
                      </Button>
                      {actions}
                    </>
                  ) : (
                    footer
                  )}
                </DialogFooter>
              )}
            </Fieldset>
          </form>
        </DialogContent>
      </Dialog>
      <ConfirmDialog
        open={open && discardOpen}
        onOpenChange={setDiscardOpen}
        title={labels.leaveTitle}
        description={labels.leaveMessage}
        isPending={busy}
        closeOnConfirm
        onConfirm={() => {
          setDiscardOpen(false);
          onOpenChange(false);
        }}
      />
    </>
  );
}
