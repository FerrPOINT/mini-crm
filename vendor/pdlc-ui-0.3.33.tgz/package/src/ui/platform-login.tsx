import { Button } from "./button";
import { DelayedFallback } from "./delayed-fallback";
import { useUiLabels } from "./labels";

export function PlatformLogin({
  pending,
  error,
  onSignIn,
}: {
  pending: boolean;
  error: string | null;
  onSignIn: () => void;
}) {
  const labels = useUiLabels();
  return (
    <main className="base-auth-screen">
      <section
        className="base-auth-panel"
        aria-labelledby="platform-login-title"
      >
        <h1 id="platform-login-title" className="base-auth-title">
          {labels.loginTitle}
        </h1>
        {pending && (
          <p role="status" className="base-auth-message">
            {labels.loginPending}
          </p>
        )}
        {error && (
          <p role="alert" className="base-auth-message" data-tone="danger">
            {error}
          </p>
        )}
        <Button
          className="base-auth-action"
          disabled={pending}
          aria-busy={pending || undefined}
          onClick={onSignIn}
        >
          {labels.loginSignIn}
        </Button>
      </section>
    </main>
  );
}

/** Callback work stays invisible on success; failures expose only a safe platform message. */
export function SsoCallbackView({
  failed,
  onRetry,
  deferPending = false,
}: {
  failed: boolean;
  onRetry: () => void;
  deferPending?: boolean;
}) {
  const labels = useUiLabels();
  return (
    <main className="base-auth-screen">
      {failed ? (
        <div className="base-auth-panel">
          <p role="alert" className="base-auth-message" data-tone="danger">
            {labels.ssoCallbackError}
          </p>
          <Button onClick={onRetry}>{labels.ssoRetry}</Button>
        </div>
      ) : deferPending ? (
        <DelayedFallback>
          <p role="status" className="base-auth-message">
            {labels.ssoCompleting}
          </p>
        </DelayedFallback>
      ) : (
        <p role="status" className="base-auth-message">
          {labels.ssoCompleting}
        </p>
      )}
    </main>
  );
}
