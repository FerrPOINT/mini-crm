import { SidebarList } from "./sidebar-list";
import { useId, type ReactNode } from 'react'
import { ChevronRight } from 'lucide-react'
import { SidebarItem, SidebarItemLabel } from './sidebar-item'
import { ProjectAvatar } from './project-avatar'

/** Controlled disclosure: the product owns URL scope and persistent ResourceRef keys. */
export function ProjectNavigationGroup({
  name,
  projectKey,
  open,
  active,
  compact = false,
  onToggle,
  status,
  actions,
  children,
}: {
  name: string
  projectKey: string
  open: boolean
  active?: boolean
  onToggle: () => void
  children: ReactNode
  compact?: boolean
  status?: ReactNode
  actions?: ReactNode
}) {
  const id = useId()
  return (
    <SidebarList asChild>
      <section aria-label={`${name} · ${projectKey}`}>
        <div
          className="base-sidebar-group-header"
          data-compact={compact}
          data-has-actions={Boolean(actions)}
        >
          <SidebarItem
            kind="group"
            active={active}
            compact={compact}
            aria-label={`${name} · ${projectKey}`}
            aria-expanded={open}
            aria-controls={id}
            aria-describedby={status ? `${id}-status` : undefined}
            onClick={onToggle}
            title={`${name} · ${projectKey}`}
          >
            <ProjectAvatar projectKey={projectKey} size="xs" />
            {!compact && (
              <>
                <SidebarItemLabel>
                  {name} · {projectKey}
                </SidebarItemLabel>
                <ChevronRight
                  aria-hidden
                  className={
                    open
                      ? "base-sidebar-group-chevron ml-auto shrink-0 rotate-90"
                      : "base-sidebar-group-chevron ml-auto shrink-0"
                  }
                />
              </>
            )}
          </SidebarItem>
          {actions && <div className="base-sidebar-group-actions">{actions}</div>}
        </div>
        {status && (
          <div id={`${id}-status`} className={compact ? "sr-only" : "px-3 text-xs text-text-muted"}>
            {status}
          </div>
        )}
        <SidebarList asChild>
          <div id={id} hidden={!open} data-nested={!compact}>
            {children}
          </div>
        </SidebarList>
      </section>
    </SidebarList>
  );
}
