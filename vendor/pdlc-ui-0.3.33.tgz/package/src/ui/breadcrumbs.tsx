import { forwardRef, type ComponentProps, type ReactNode } from "react";
import { Button } from "./button";
import { cn } from "../lib/utils";

/** Hierarchy presentation only: the owner supplies order, destinations and current item. */
export function Breadcrumbs({
  children,
  className,
  ...props
}: ComponentProps<"nav"> & { "aria-label": string; children: ReactNode }) {
  return (
    <nav {...props} className={cn("base-breadcrumbs", className)}>
      <ol className="base-breadcrumb-list">{children}</ol>
    </nav>
  );
}

/** Default action never submits a form; asChild preserves a native/router link or static text. */
export const BreadcrumbItem = forwardRef<
  HTMLButtonElement,
  Omit<
    ComponentProps<typeof Button>,
    "variant" | "size" | "type" | "subjectColor"
  > & {
    current?: boolean;
  }
>(
  (
    {
      current = false,
      asChild = false,
      className,
      "aria-current": ariaCurrent,
      ...props
    },
    ref,
  ) => (
    <li className="base-breadcrumb-item">
      <span className="base-breadcrumb-separator" aria-hidden="true">
        /
      </span>
      <Button
        {...props}
        ref={ref}
        asChild={asChild}
        type={asChild ? undefined : "button"}
        variant="ghost"
        aria-current={ariaCurrent ?? (current ? "page" : undefined)}
        className={cn("base-breadcrumb-control", className)}
      />
    </li>
  ),
);
BreadcrumbItem.displayName = "BreadcrumbItem";
