import * as React from "react";
import { cn } from "../lib/utils";
import { barPercent } from "./bar-value";

interface ProgressProps extends React.HTMLAttributes<HTMLDivElement> {
  value: number;
  max?: number;
  variant?: "default" | "danger" | "success";
}

const Progress = React.forwardRef<HTMLDivElement, ProgressProps>(
  ({ className, value, max = 100, variant = "default", ...props }, ref) => {
    const known = Number.isFinite(value) && Number.isFinite(max) && max > 0;
    const current = known ? Math.min(max, Math.max(0, value)) : undefined;
    const percent = current === undefined ? 0 : barPercent(current, max);
    return (
      <div
        ref={ref}
        className={cn("base-progress", className)}
        role="progressbar"
        aria-valuemin={0}
        aria-valuemax={known ? max : undefined}
        aria-valuenow={current}
        data-variant={variant}
        data-unknown={!known || undefined}
        {...props}
      >
        <div className="base-progress-fill" style={{ width: `${percent}%` }} />
      </div>
    );
  },
);
Progress.displayName = "Progress";

export { Progress };
