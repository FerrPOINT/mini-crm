import { Component, type ErrorInfo, type ReactNode } from "react";

type RenderBoundaryProps = {
  children: ReactNode;
  /** The owner decides what is safe to show and whether recovery is possible. */
  fallback: ReactNode;
  /** Receives the original thrown value; it is not necessarily an Error. */
  onError?: (error: unknown, info: ErrorInfo) => void;
};

/** Descendant render recovery only. Remount with an owner key to reset deliberately. */
export class RenderBoundary extends Component<
  RenderBoundaryProps,
  { failed: boolean }
> {
  state = { failed: false };

  static getDerivedStateFromError() {
    return { failed: true };
  }

  componentDidCatch(error: unknown, info: ErrorInfo) {
    this.props.onError?.(error, info);
  }

  render() {
    return this.state.failed ? this.props.fallback : this.props.children;
  }
}
