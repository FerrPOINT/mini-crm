/** Drawing only; missing/invalid data never acquires a known numeric state here. */
export function barPercent(value: number, max: number) {
  return Number.isFinite(value) && Number.isFinite(max) && max > 0
    ? Math.min(100, Math.max(0, (value / max) * 100))
    : 0;
}
