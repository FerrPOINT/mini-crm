import {
  forwardRef,
  useEffect,
  useId,
  useRef,
  useState,
  type ComponentPropsWithoutRef,
} from "react";
import { createPortal } from "react-dom";
import { useComposedRefs } from "@radix-ui/react-compose-refs";
import { DismissableLayer } from "@radix-ui/react-dismissable-layer";
import * as Popper from "@radix-ui/react-popper";
import { Check } from "lucide-react";
import { Input } from "./input";
import type { ChoiceOption } from "./choice-types";
import {
  useChoiceDisabled,
  useChoiceState,
  useChoiceTheme,
} from "./choice-field";
import { useUiLabels } from "./labels";

export interface AutocompleteInputProps extends Omit<
  ComponentPropsWithoutRef<typeof Input>,
  | "onChange"
  | "value"
  | "defaultValue"
  | "list"
  | "type"
  | "role"
  | "aria-expanded"
  | "aria-controls"
  | "aria-activedescendant"
  | "aria-autocomplete"
> {
  /** Suggestions do not restrict the allowed input value or perform a request. */
  options: readonly ChoiceOption[];
  value?: string;
  defaultValue?: string;
  onValueChange?: (value: string) => void;
  type?: "text" | "search" | "url" | "email" | "tel";
}

/** Editable combobox: DOM focus and form semantics belong to its one native input. */
export const AutocompleteInput = forwardRef<
  HTMLInputElement,
  AutocompleteInputProps
>(
  (
    {
      options,
      value,
      defaultValue = "",
      onValueChange,
      disabled,
      readOnly,
      onFocus,
      onClick,
      onKeyDown,
      form,
      ...props
    },
    ref,
  ) => {
    const [input, setInput] = useState<HTMLInputElement | null>(null);
    const inputRef = useComposedRefs(ref, setInput);
    const state = useChoiceState(value, defaultValue);
    const [requestedOpen, setOpen] = useState(false);
    const [active, setActive] = useState<{
      option: ChoiceOption;
      query: string;
    } | null>(null);
    const blocked = useChoiceDisabled(input, disabled);
    const open = requestedOpen && !blocked && !readOnly && options.length > 0;
    const theme = useChoiceTheme(input, open);
    const ui = useUiLabels();
    const listId = useId();
    const list = useRef<HTMLDivElement>(null);
    const restoringFocus = useRef(false);
    const query = state.value.toLowerCase();
    const filtered = options.filter(
      (option) =>
        option.value.toLowerCase().includes(query) ||
        option.label.toLowerCase().includes(query),
    );
    const activeIndex =
      active?.query === state.value
        ? filtered.findIndex(
            (option) =>
              !option.disabled &&
              option.value === active.option.value &&
              option.label === active.option.label,
          )
        : -1;
    const activeId =
      open && activeIndex >= 0 ? `${listId}-${activeIndex}` : undefined;
    const { reset } = state;

    useEffect(() => {
      if (blocked || readOnly) {
        setOpen(false);
        setActive(null);
      }
    }, [blocked, readOnly]);
    useEffect(() => {
      const owner = input?.form;
      const onReset = (event: Event) =>
        queueMicrotask(() => {
          if (event.defaultPrevented) return;
          reset();
          setOpen(false);
          setActive(null);
        });
      owner?.addEventListener("reset", onReset);
      return () => owner?.removeEventListener("reset", onReset);
    }, [input, form, reset]);
    useEffect(() => {
      if (activeId)
        list.current?.ownerDocument
          .getElementById(activeId)
          ?.scrollIntoView({ block: "nearest" });
    }, [activeId]);

    function choose(option: ChoiceOption) {
      if (blocked || readOnly || option.disabled) return;
      if (option.value !== state.value) {
        state.change(option.value);
        onValueChange?.(option.value);
      }
      setOpen(false);
      setActive(null);
      restoringFocus.current = true;
      try {
        input?.focus();
      } finally {
        restoringFocus.current = false;
      }
    }
    function move(direction: number) {
      const enabled = filtered
        .map((option, index) => ({ option, index }))
        .filter((item) => !item.option.disabled);
      if (!enabled.length) return;
      const current = enabled.findIndex((item) => item.index === activeIndex);
      const next =
        current < 0
          ? direction > 0
            ? 0
            : enabled.length - 1
          : (current + direction + enabled.length) % enabled.length;
      const item = enabled[next];
      if (item) setActive({ option: item.option, query: state.value });
    }
    return (
      <Popper.Root>
        <Popper.Anchor asChild>
          <Input
            {...props}
            form={form}
            ref={inputRef}
            disabled={disabled}
            readOnly={readOnly}
            role="combobox"
            aria-autocomplete="list"
            aria-expanded={open}
            aria-controls={open ? listId : undefined}
            aria-activedescendant={activeId}
            autoComplete={props.autoComplete ?? "off"}
            value={state.value}
            onChange={(event) => {
              if (blocked || readOnly) return;
              state.change(event.target.value);
              setActive(null);
              setOpen(true);
              onValueChange?.(event.target.value);
            }}
            onFocus={(event) => {
              onFocus?.(event);
              if (
                !event.defaultPrevented &&
                !blocked &&
                !readOnly &&
                !restoringFocus.current
              )
                setOpen(true);
            }}
            onClick={(event) => {
              onClick?.(event);
              if (!event.defaultPrevented && !blocked && !readOnly)
                setOpen(true);
            }}
            onKeyDown={(event) => {
              onKeyDown?.(event);
              if (
                event.defaultPrevented ||
                blocked ||
                readOnly ||
                event.nativeEvent.isComposing ||
                event.keyCode === 229
              )
                return;
              if (event.key === "ArrowDown" || event.key === "ArrowUp") {
                event.preventDefault();
                setOpen(true);
                if (!event.altKey) move(event.key === "ArrowDown" ? 1 : -1);
              } else if (event.key === "Enter" && open && activeIndex >= 0) {
                const option = filtered[activeIndex];
                if (option) {
                  event.preventDefault();
                  choose(option);
                }
              } else if (event.key === "Tab") {
                setOpen(false);
                setActive(null);
              }
            }}
          />
        </Popper.Anchor>
        {open &&
          input &&
          createPortal(
            <DismissableLayer
              asChild
              onEscapeKeyDown={(event) => {
                event.preventDefault();
                setOpen(false);
                setActive(null);
              }}
              onInteractOutside={(event) => {
                if (event.target === input) event.preventDefault();
              }}
              onDismiss={() => {
                setOpen(false);
                setActive(null);
              }}
            >
              <Popper.Content
                ref={list}
                id={listId}
                role="listbox"
                aria-label={ui.suggestions}
                style={theme}
                className="base-choice-panel base-autocomplete-panel"
                sideOffset={4}
                align="start"
                collisionPadding={8}
                hideWhenDetached
              >
                {filtered.length ? (
                  filtered.map((option, index) => (
                    <div
                      id={`${listId}-${index}`}
                      key={`${option.value}:${index}`}
                      role="option"
                      aria-selected={index === activeIndex}
                      aria-disabled={option.disabled || undefined}
                      data-disabled={option.disabled ? "" : undefined}
                      data-highlighted={index === activeIndex ? "" : undefined}
                      className="base-choice-option"
                      onPointerMove={() => {
                        if (!option.disabled)
                          setActive({ option, query: state.value });
                      }}
                      onMouseDown={(event) => event.preventDefault()}
                      onClick={() => choose(option)}
                    >
                      {option.value === state.value && (
                        <span className="base-choice-indicator">
                          <Check size={16} aria-hidden="true" />
                        </span>
                      )}
                      <span className="base-autocomplete-label">
                        {option.label}
                        {option.label !== option.value && (
                          <span className="base-autocomplete-value">
                            {option.value}
                          </span>
                        )}
                      </span>
                    </div>
                  ))
                ) : (
                  <div className="base-choice-empty">{ui.noResults}</div>
                )}
              </Popper.Content>
            </DismissableLayer>,
            input.ownerDocument.body,
          )}
      </Popper.Root>
    );
  },
);
AutocompleteInput.displayName = "AutocompleteInput";
