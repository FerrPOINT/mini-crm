import * as React from "react";
import { cn } from "../lib/utils";
import type { Badge } from "./badge";
interface BadgeButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  tone?: React.ComponentProps<typeof Badge>["tone"];
  appearance?: "badge" | "inline";
}
/** Compact native action for tag collections; regular form/navigation buttons retain their metrics. */
export const BadgeButton = React.forwardRef<
  HTMLButtonElement,
  BadgeButtonProps
>(
  (
    {
      tone = "neutral",
      appearance = "badge",
      type = "button",
      className,
      ...props
    },
    ref,
  ) => (
    <button
      {...props}
      ref={ref}
      type={type}
      className={cn("base-badge base-badge-button", className)}
      data-tone={tone}
      data-appearance={appearance}
    />
  ),
);
BadgeButton.displayName = "BadgeButton";
