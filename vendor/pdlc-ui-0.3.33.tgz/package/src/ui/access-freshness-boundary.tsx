import { useEffect, useState, type ReactNode } from "react";
import { usePlatformReadiness } from "../platform";
import { ErrorState, LoadingState } from "./async-states";

export interface AdmissionWindowV1 {
  schema_version: 1;
  enforced: boolean;
  remaining_millis: number | null;
  scope_revision: string | null;
}

export interface AccessFreshnessBoundaryProps {
  enabled: boolean;
  /** In-memory generation, never an access token. Supply stable load/retire callbacks. */
  authorityKey: string | number;
  load: (signal: AbortSignal) => Promise<unknown>;
  onRetire: () => void;
  children: ReactNode;
}
/** Fresh display authority never extends the deadline of an existing server operation. */
export function AccessFreshnessBoundary({
  enabled,
  authorityKey,
  load,
  onRetire,
  children,
}: AccessFreshnessBoundaryProps) {
  const [retry, setRetry] = useState(0);
  const [state, setState] = useState<{
    key: string | number;
    phase: "loading" | "ready" | "error";
  }>({ key: authorityKey, phase: "loading" });
  const phase = !enabled
    ? "ready"
    : state.key === authorityKey
      ? state.phase
      : "loading";
  usePlatformReadiness({
    pending: phase === "loading",
    error: phase === "error" ? "Не удалось подтвердить доступ" : null,
  });
  useEffect(() => {
    if (!enabled) return;
    const setPhase = (phase: "loading" | "ready" | "error") =>
      setState({ key: authorityKey, phase });
    let active = true;
    let accepted = false;
    let legacy = false;
    let revision: string | null = null;
    let expiry: ReturnType<typeof setTimeout> | undefined;
    let refresh: ReturnType<typeof setTimeout> | undefined;
    const controller = new AbortController();
    setPhase("loading");
    const current = () => active;
    const retire = () => {
      if (!active) return;
      active = false;
      clearTimeout(expiry);
      clearTimeout(refresh);
      controller.abort();
      setPhase("loading");
      onRetire();
    };
    const restored = (event: PageTransitionEvent) => {
      if (event.persisted) retire();
    };
    window.addEventListener("pageshow", restored);
    async function confirm() {
      const started = performance.now();
      try {
        const wire = await load(controller.signal);
        if (
          !wire ||
          typeof wire !== "object" ||
          Array.isArray(wire) ||
          Object.keys(wire).sort().join(",") !==
            "enforced,remaining_millis,schema_version,scope_revision"
        )
          throw new Error("Invalid admission");
        const value = wire as AdmissionWindowV1;
        if (!current()) return;
        if (value.schema_version !== 1 || typeof value.enforced !== "boolean")
          throw new Error("Invalid admission");
        if (!value.enforced) {
          if (
            value.remaining_millis !== null ||
            value.scope_revision !== null ||
            accepted
          )
            throw new Error("Invalid policy transition");
          legacy = true;
          setPhase("ready");
          refresh = setTimeout(() => void confirm(), 30_000);
          return;
        }
        if (
          !Number.isSafeInteger(value.remaining_millis) ||
          value.remaining_millis! <= 0 ||
          value.remaining_millis! > 60_000 ||
          typeof value.scope_revision !== "string" ||
          !/^[0-9a-f]{64}$/.test(value.scope_revision)
        )
          throw new Error("Invalid admission");
        if (legacy || (revision && revision !== value.scope_revision)) {
          retire();
          return;
        }
        const remaining = started + value.remaining_millis! - performance.now();
        if (remaining <= 0) throw new Error("Expired admission");
        revision = value.scope_revision;
        accepted = true;
        setPhase("ready");
        clearTimeout(expiry);
        expiry = setTimeout(() => {
          if (!current()) return;
          retire();
        }, remaining);
        refresh = setTimeout(
          () => void confirm(),
          Math.min(30_000, Math.max(1, remaining / 2)),
        );
      } catch {
        // A failed renewal can retain the original proof only until its fixed deadline.
        if (current() && legacy) retire();
        else if (current() && !accepted) setPhase("error");
      }
    }
    void confirm();
    return () => {
      active = false;
      controller.abort();
      clearTimeout(expiry);
      clearTimeout(refresh);
      window.removeEventListener("pageshow", restored);
    };
  }, [enabled, authorityKey, load, onRetire, retry]);
  if (!enabled) return children;
  if (state.key !== authorityKey || state.phase === "loading")
    return <LoadingState message="Проверка доступа…" />;
  if (state.phase === "error")
    return (
      <ErrorState
        message="Не удалось подтвердить доступ"
        onRetry={() => setRetry((value) => value + 1)}
      />
    );
  return children;
}
