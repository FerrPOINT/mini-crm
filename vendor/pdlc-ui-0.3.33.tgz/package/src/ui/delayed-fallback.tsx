import { useEffect, useState, type ReactNode } from "react";

export function DelayedFallback({
  children,
  delayMs = 600,
}: {
  children: ReactNode;
  delayMs?: number;
}) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const timer = window.setTimeout(() => setVisible(true), delayMs);
    return () => window.clearTimeout(timer);
  }, [delayMs]);

  return visible ? children : null;
}
