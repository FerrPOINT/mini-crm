import * as React from "react";
import { cn } from "../lib/utils";
import { Button } from "./button";
import { Input } from "./input";

interface InputWithActionProps extends React.ComponentPropsWithoutRef<
  typeof Input
> {
  /** Layout of the whole group; className still belongs to the native input. */
  containerClassName?: string;
  /** The owner supplies the action and its state. No change/submit events are synthesized. */
  action?: {
    label: string;
    icon: React.ReactNode;
    onAction: React.MouseEventHandler<HTMLButtonElement>;
    disabled?: boolean;
    pressed?: boolean;
    title?: string;
  };
}

/** One native input and an optional icon action, with stable input identity and a native input ref. */
export const InputWithAction = React.forwardRef<
  HTMLInputElement,
  InputWithActionProps
>(({ containerClassName, action, disabled, ...props }, ref) => (
  <span
    className={cn("base-input-with-action", containerClassName)}
    data-action={action ? "true" : undefined}
  >
    <Input {...props} ref={ref} disabled={disabled} />
    {action && (
      <Button
        type="button"
        variant="ghost"
        size="icon"
        className="base-input-action"
        aria-label={action.label}
        title={action.title ?? action.label}
        aria-controls={props.id}
        aria-pressed={action.pressed}
        disabled={disabled || action.disabled}
        onClick={action.onAction}
      >
        <span aria-hidden="true">{action.icon}</span>
      </Button>
    )}
  </span>
));
InputWithAction.displayName = "InputWithAction";
