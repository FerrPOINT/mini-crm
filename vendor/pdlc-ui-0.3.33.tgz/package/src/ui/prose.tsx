import { useCallback, useMemo, type ComponentProps } from "react";
import { Slot } from "@radix-ui/react-slot";
import { useComposedRefs } from "@radix-ui/react-compose-refs";
import { cn } from "../lib/utils";

export type ProseProps = ComponentProps<"div"> & {
  /** Style one existing flow root, such as a paragraph, without adding a wrapper. */
  asChild?: boolean;
  compact?: boolean;
  preserveLineBreaks?: boolean;
  /** Tab stops for raw pre/table in directly supplied, caller-sanitized HTML. */
  keyboardScroll?: boolean;
};

/** Prepared content presentation; parsing, sanitization and link policy stay with the caller. */
export function Prose({
  asChild = false,
  compact = false,
  preserveLineBreaks = false,
  keyboardScroll = false,
  dangerouslySetInnerHTML,
  ref,
  className,
  ...props
}: ProseProps) {
  const Component = asChild ? Slot : "div";
  const html = dangerouslySetInnerHTML?.__html;
  // Equal markup must not replace focused descendants on an owner re-render.
  const stableMarkup = useMemo(
    () => (html == null ? undefined : { __html: html }),
    [html],
  );
  // React 19 ref cleanup tracks root/content changes without observing or parsing HTML.
  const prepareScrollRegions = useCallback(
    (root: HTMLDivElement | null) => {
      if (!root || !keyboardScroll || html == null) return;
      const regions = root.querySelectorAll<HTMLElement>(
        "pre:not(.base-code-block):not([tabindex]), table:not(.base-table):not([tabindex])",
      );
      for (const region of regions) region.setAttribute("tabindex", "0");
      return () => {
        // Preserve an authored tab index, including a later explicit owner override.
        for (const region of regions)
          if (region.getAttribute("tabindex") === "0")
            region.removeAttribute("tabindex");
      };
    },
    [keyboardScroll, html],
  );
  const scrollRef = useComposedRefs(ref, prepareScrollRegions);
  return (
    <Component
      {...props}
      ref={keyboardScroll ? scrollRef : ref}
      dangerouslySetInnerHTML={
        keyboardScroll && html != null ? stableMarkup : dangerouslySetInnerHTML
      }
      className={cn("base-prose", className)}
      data-compact={compact || undefined}
      data-preserve-line-breaks={preserveLineBreaks || undefined}
    />
  );
}
