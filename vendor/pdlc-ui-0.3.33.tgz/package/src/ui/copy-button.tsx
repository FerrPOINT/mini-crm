import { forwardRef, type ComponentProps, type ReactNode } from "react";
import { useClipboard } from "../lib/use-clipboard";
import { Button } from "./button";
import { useUiLabels } from "./labels";

export interface CopyButtonProps extends Omit<
  ComponentProps<typeof Button>,
  "asChild" | "type" | "value"
> {
  value: string;
  writeText?: (value: string) => Promise<void>;
  copiedLabel?: ReactNode;
  onCopied?: () => void;
  onCopyError?: (error: unknown) => void;
}

/** Copies only on activation. Products own authorization, content and contextual feedback. */
export const CopyButton = forwardRef<HTMLButtonElement, CopyButtonProps>(
  function CopyButton(
    {
      value,
      writeText,
      copiedLabel,
      onCopied,
      onCopyError,
      onClick,
      children,
      disabled,
      variant = "outline",
      ...props
    },
    ref,
  ) {
    const labels = useUiLabels();
    const { copy, pending, status } = useClipboard(value, {
      writeText,
      onCopied,
      onCopyError,
    });

    return (
      <>
        <Button
          {...props}
          ref={ref}
          type="button"
          variant={variant}
          disabled={disabled || pending}
          aria-busy={pending || undefined}
          onClick={(event) => {
            onClick?.(event);
            if (!event.defaultPrevented) void copy();
          }}
        >
          {status === "copied"
            ? (copiedLabel ?? children ?? labels.copied)
            : (children ?? labels.copy)}
        </Button>
        {status === "copied" && !onCopied && (
          <span role="status" className="sr-only">
            {labels.copied}
          </span>
        )}
        {status === "error" && !onCopyError && (
          <span role="alert" className="text-sm text-danger">
            {labels.copyFailed}
          </span>
        )}
      </>
    );
  },
);
