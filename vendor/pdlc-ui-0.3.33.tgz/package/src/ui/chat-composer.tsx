import { forwardRef, type HTMLAttributes, type ReactNode } from "react";
import { Slot } from "@radix-ui/react-slot";
import { cn } from "../lib/utils";
import { ResourceListDescription } from "./resource-list";
import { ActionGroup } from "./action-group";

export interface ChatComposerProps extends HTMLAttributes<HTMLDivElement> {
  /** Preserve a caller-owned form, its submission handler and native attributes. */
  asChild?: boolean;
}

/** Presentation only; draft, submission, recovery and admission remain caller-owned. */
export const ChatComposer = forwardRef<HTMLDivElement, ChatComposerProps>(
  function ChatComposer({ asChild = false, className, ...props }, ref) {
    const Component = asChild ? Slot : "div";
    return (
      <Component
        {...props}
        ref={ref}
        className={cn("base-chat-composer", className)}
      />
    );
  },
);

export interface ChatComposerActionsProps extends HTMLAttributes<HTMLDivElement> {
  /** Phrasing content, such as an icon and a caller-supplied access explanation. */
  hint?: ReactNode;
}

/** Wrapping action row; no implicit button, disabled state or form event handling. */
export const ChatComposerActions = forwardRef<
  HTMLDivElement,
  ChatComposerActionsProps
>(function ChatComposerActions({ hint, children, className, ...props }, ref) {
  const hasHint = Boolean(hint) || hint === 0;
  return (
    <ActionGroup
      {...props}
      ref={ref}
      align="start"
      className={cn("base-chat-composer-actions", className)}
      data-hint={hasHint || undefined}
    >
      {hasHint && (
        <ActionGroup asChild align="start">
          <ResourceListDescription className="base-chat-composer-hint">
            {hint}
          </ResourceListDescription>
        </ActionGroup>
      )}
      <ActionGroup align="start" className="base-chat-composer-buttons">
        {children}
      </ActionGroup>
    </ActionGroup>
  );
});
