import { cn } from '../lib/utils'

const palette = [
  'bg-violet-700',
  'bg-blue-700',
  'bg-emerald-700',
  'bg-amber-700',
  'bg-rose-700',
  'bg-cyan-700',
  'bg-indigo-700',
  'bg-teal-700',
  'bg-orange-700',
  'bg-pink-700',
  'bg-lime-800',
  'bg-sky-700',
]
const sizes = {
  xs: 'h-6 w-6 text-[10px]',
  sm: 'h-7 w-7 text-xs',
  md: 'h-8 w-8 text-xs',
  lg: 'h-10 w-10 text-sm',
  xl: 'h-12 w-12 text-base',
}

function hashName(name: string) {
  let hash = 0
  for (let i = 0; i < name.length; i++) hash = (hash * 31 + name.charCodeAt(i)) >>> 0
  return hash
}

function initialsOf(name: string) {
  const parts = name
    .trim()
    .split(/[\s._-]+/)
    .filter(Boolean)
  const first = parts[0]
  if (!first) return '?'
  if (parts.length === 1) return first.slice(0, 2).toUpperCase()
  const last = parts[parts.length - 1] ?? first
  return (first.charAt(0) + last.charAt(0)).toUpperCase()
}

export interface InitialsAvatarProps {
  name: string | null | undefined
  size?: keyof typeof sizes
  withName?: boolean
  className?: string
}

/** Stable initials/color identity for products without illustrated user avatars. */
export function InitialsAvatar({
  name,
  size = 'md',
  withName = false,
  className,
}: InitialsAvatarProps) {
  const label = name?.trim() || 'unknown'
  return (
    <span className={cn('inline-flex items-center gap-2', className)}>
      <span
        role="img"
        aria-label={label}
        className={cn(
          'inline-flex select-none items-center justify-center rounded-full font-semibold text-white',
          sizes[size],
          palette[hashName(label) % palette.length],
        )}
      >
        {initialsOf(label)}
      </span>
      {withName && <span className="text-sm font-medium text-text-primary">{label}</span>}
    </span>
  )
}
