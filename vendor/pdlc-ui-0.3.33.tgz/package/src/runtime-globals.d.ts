import './lib/theme-preference.js'
import type { DraftTracker } from './lib/draft-types'
export interface ConfirmationOptions { eyebrow?: string; title?: string; message?: string; confirmLabel?: string }
export interface ServerNotificationOptions {
  type?: 'normal' | 'success' | 'error' | 'warning';
  duration?: number;
  hostId?: string;
}
export interface ServerNavigation {
  embedded: boolean; active: boolean;
  saved(form?: HTMLFormElement): void;
  refreshDrafts?(): void;
  createDraftTracker?(onChange?: () => void): DraftTracker;
  navigate(url: string, options?: { replace?: boolean }): void;
  reload(): void;
  syncRoute?(url: string, replace?: boolean, state?: unknown): void;
}
declare global {
  interface Window {
    PdlcBaseUI: { requestConfirmation(options: ConfirmationOptions): Promise<boolean>; closeNavigation?: () => void; initMenus(root?: ParentNode): void; destroyMenus(root?: ParentNode): void; notify(message: string, options?: ServerNotificationOptions): () => void };
    SdlcBaseUI: Window['PdlcBaseUI'];
    PdlcPlatformNavigation: ServerNavigation;
    SdlcPlatformNavigation: ServerNavigation;
  }
}
