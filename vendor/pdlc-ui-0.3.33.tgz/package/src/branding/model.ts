import {
  effectiveMark as resolveMark,
  validMonogram,
} from "../lib/branding-marks.js";
export { graphemes, validMonogram } from "../lib/branding-marks.js";
import { foreground, isHex } from "../lib/branding-colors.js";
export { contrast, isHex } from "../lib/branding-colors.js";
import {
  defaultBranding,
  defaultDesign,
  type BrandingDesign,
} from "../lib/branding-runtime.js";
import { validBrandUrl as validLink } from "./brand-url";

export type BrandTheme = "dark" | "gray" | "light";
export type MarkVariant = "common" | "light" | "dark";
export type RadiusKey = "control" | "menu" | "dialog" | "card" | "mark";
export interface BrandAsset {
  id: string;
  url: string;
  name: string;
}
export interface BrandMark {
  kind: "letters" | "icon" | "image";
  count: 1 | 2 | 4;
  letters: string;
  lettersByCount?: Partial<Record<1 | 2 | 4, string>>;
  icon: string;
  foreground: string;
  background: string;
  shape: "square" | "rounded" | "circle";
  fit: "contain" | "cover";
  image: BrandAsset | null;
}
// Normalized presentation; wire documents may omit design for legacy consumers.
export interface BrandDesignDocument {
  product_name: string;
  product_short_name: string;
  logo_url: string | null;
  favicon_url: string | null;
  support_url: string | null;
  primary_color: string;
  accent_color: string;
  surface_color: string | null;
  design: BrandingDesign & {
    version: 1;
    marks: {
      common: BrandMark;
      light: BrandMark | null;
      dark: BrandMark | null;
    };
    favicon: { mode: "auto" | "logo" | "image"; image: BrandAsset | null };
    colors: Record<BrandTheme, { primary: string; accent: string }>;
    radii: Record<RadiusKey, number>;
    documentation_url: string;
    initial_theme: BrandTheme;
  };
}
export const themes: BrandTheme[] = ["dark", "gray", "light"];
export const themeNames = { dark: "Тёмная", gray: "Серая", light: "Светлая" };
export const variantNames = {
  common: "Общий",
  light: "Светлая тема",
  dark: "Тёмная и серая",
};
export const radiusLimits: Record<RadiusKey, number> = {
  control: 12,
  menu: 16,
  dialog: 24,
  card: 24,
  mark: 16,
};
export const radiusNames = {
  control: "Контролы",
  menu: "Меню",
  dialog: "Окна",
  card: "Карточки",
  mark: "Знак",
};
export const radiusPresets = {
  Строго: { control: 0, menu: 0, dialog: 0, card: 0, mark: 0 },
  Base: { control: 6, menu: 6, dialog: 8, card: 8, mark: 2 },
  Мягко: { control: 8, menu: 12, dialog: 20, card: 8, mark: 12 },
};
export const palettes = {
  Синий: {
    dark: { primary: "#60a5fa", accent: "#5eead4" },
    gray: { primary: "#93c5fd", accent: "#5eead4" },
    light: { primary: "#2563eb", accent: "#0f766e" },
  },
  Зелёный: {
    dark: { primary: "#4ade80", accent: "#93c5fd" },
    gray: { primary: "#86efac", accent: "#93c5fd" },
    light: { primary: "#15803d", accent: "#1d4ed8" },
  },
  Розовый: {
    dark: { primary: "#f9a8d4", accent: "#a5f3fc" },
    gray: { primary: "#f9a8d4", accent: "#a5f3fc" },
    light: { primary: "#be185d", accent: "#0e7490" },
  },
};
export const defaultMark: BrandMark = {
  kind: "letters",
  count: 4,
  letters: "PDLC",
  icon: "layers",
  foreground: "#ffffff",
  background: "#2563eb",
  shape: "rounded",
  fit: "contain",
  image: null,
};
export function createBrandDocument(): BrandDesignDocument {
  return {
    product_name: defaultBranding.product_name,
    product_short_name: defaultBranding.product_short_name,
    logo_url: null,
    favicon_url: null,
    support_url: null,
    primary_color: "#2563eb",
    accent_color: "#0f766e",
    surface_color: null,
    design: {
      ...defaultDesign,
      version: 1,
      marks: { common: { ...defaultMark }, light: null, dark: null },
      favicon: { mode: "auto", image: null },
      colors: structuredClone(palettes["Синий"]),
      radii: { ...radiusPresets.Base },
      documentation_url: "",
      initial_theme: "dark",
    },
  };
}
export function effectiveMark(
  document: BrandDesignDocument,
  theme: BrandTheme,
): BrandMark {
  return resolveMark(document, theme);
}
export function readableText(background: string) {
  return foreground(background);
}
/** Internal field map shared by the editor and the public document validator. */
export function brandValidationErrors(
  document: BrandDesignDocument,
): Record<string, string> {
  const errors: Record<string, string> = {};
  for (const [field, name, value, limit] of [
    ["product_name", "Полное название", document.product_name, 80],
    [
      "product_short_name",
      "Короткое название",
      document.product_short_name,
      24,
    ],
  ] as const) {
    if (!value.trim() || new TextEncoder().encode(value).length > limit)
      errors[field] =
        `${name}: обязательное значение, не более ${limit} байт UTF-8.`;
  }
  for (const theme of themes) {
    for (const [key, label] of [
      ["primary", "Цвет действий"],
      ["accent", "Акцент"],
    ] as const) {
      if (!isHex(document.design.colors[theme][key]))
        errors[`colors.${theme}.${key}`] =
          `${themeNames[theme]} тема: ${label.toLowerCase()} — введите HEX в формате #RRGGBB.`;
    }
  }
  if (document.surface_color != null && !isHex(document.surface_color))
    errors.surface_color = "Введите HEX в формате #RRGGBB.";

  for (const variant of ["common", "light", "dark"] as const) {
    const mark = document.design.marks[variant];
    if (!mark) continue;
    const prefix = `marks.${variant}`;
    if (new TextEncoder().encode(mark.letters).length > 128)
      errors[`${prefix}.letters`] =
        `${variantNames[variant]} знак: не более 128 байт UTF-8.`;
    else if (mark.kind === "letters" && !validMonogram(mark))
      errors[`${prefix}.letters`] =
        `${variantNames[variant]} знак: введите ${mark.count} видимых символа без пробелов.`;
    for (const key of ["foreground", "background"] as const)
      if (!isHex(mark[key]))
        errors[`${prefix}.${key}`] = "Введите HEX в формате #RRGGBB.";
    // Logo colors are identity artwork, not interface text. Preserve the author's pair.
    if (mark.kind === "image" && !mark.image)
      errors[`${prefix}.image`] =
        `${variantNames[variant]} знак: выберите изображение.`;
  }
  for (const key of Object.keys(radiusLimits) as RadiusKey[]) {
    const value = document.design.radii[key];
    if (!Number.isInteger(value) || value < 0 || value > radiusLimits[key])
      errors[`radii.${key}`] =
        `${radiusNames[key]}: от 0 до ${radiusLimits[key]} px, шаг 1.`;
  }
  if (
    document.design.favicon.mode === "image" &&
    !document.design.favicon.image
  )
    errors["favicon.image"] = "Иконка вкладки: выберите изображение.";
  for (const [field, label, value] of [
    ["support_url", "Поддержка", document.support_url ?? ""],
    ["documentation_url", "Документация", document.design.documentation_url],
  ] as const)
    if (!validLink(value))
      errors[field] =
        `${label}: нужен HTTPS URL без логина и пароля (HTTP только localhost).`;
  return errors;
}
export function validateBrand(document: BrandDesignDocument): string[] {
  return Object.values(brandValidationErrors(document));
}
export function referencedAssets(document: BrandDesignDocument) {
  return [
    ...Object.values(document.design.marks).flatMap((mark) =>
      mark?.image ? [mark.image] : [],
    ),
    ...(document.design.favicon.image ? [document.design.favicon.image] : []),
  ];
}
export function flattenDocument(
  value: unknown,
  prefix = "",
): Record<string, string> {
  if (value === null || typeof value !== "object")
    return { [prefix]: value === null ? "—" : String(value) };
  return Object.fromEntries(
    Object.entries(value).flatMap(([key, nested]) =>
      Object.entries(
        flattenDocument(nested, prefix ? `${prefix}.${key}` : key),
      ),
    ),
  );
}
