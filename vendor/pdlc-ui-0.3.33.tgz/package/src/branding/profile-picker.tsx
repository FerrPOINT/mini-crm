import { useRef, useState } from "react";
import { LayoutTemplate } from "lucide-react";
import { Checkbox } from "../ui/check-controls";
import {
  Table,
  TableHeader,
  TableBody,
  TableRow,
  TableHead,
  TableCell,
} from "../ui/table";
import { Button } from "../ui/button";
import { Select } from "../ui/select";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "../ui/dialog";
import {
  applyBrandProfile,
  brandProfiles,
  matchingBrandProfile,
  profileDifferences,
  profileGroupNames,
  profileGroups,
  type ProfileGroup,
  type ProfileId,
} from "./profiles";
import type { BrandDesignDocument } from "./model";

export function BrandingProfilePicker({
  value,
  onChange,
  disabled,
}: {
  value: BrandDesignDocument;
  onChange: (value: BrandDesignDocument) => void;
  disabled: boolean;
}) {
  const [selected, setSelected] = useState<ProfileId | null>(null);
  const [groups, setGroups] = useState<ProfileGroup[]>([...profileGroups]);
  const trigger = useRef<HTMLButtonElement | null>(null);
  const candidate = selected
    ? applyBrandProfile(value, selected, groups)
    : value;
  const differences = profileDifferences(value, candidate);
  return (
    <section className="base-brand-block">
      <div className="base-brand-profile-heading">
        <h2>
          <LayoutTemplate size={18} />
          Шаблон оформления
        </h2>
        <div className="base-brand-scope">
          <Select
            ref={trigger}
            aria-label="Шаблон оформления"
            value={
              brandProfiles.find(
                (profile) => profile.name === matchingBrandProfile(value),
              )?.id ?? ""
            }
            placeholder="Пользовательский"
            disabled={disabled}
            options={brandProfiles.map((profile) => ({
              value: profile.id,
              label: profile.name,
            }))}
            onValueChange={(id) => {
              setGroups([...profileGroups]);
              setSelected(id as ProfileId);
            }}
          />
        </div>
      </div>
      <Dialog
        open={selected !== null}
        onOpenChange={(open) => {
          if (!open) setSelected(null);
        }}
      >
        <DialogContent
          aria-describedby="brand-profile-description"
          className="!max-w-[760px]"
          onCloseAutoFocus={(event) => {
            event.preventDefault();
            trigger.current?.focus();
          }}
        >
          <DialogHeader>
            <DialogTitle>
              Применить шаблон{" "}
              {brandProfiles.find((p) => p.id === selected)?.name}?
            </DialogTitle>
          </DialogHeader>
          <div className="min-h-0 overflow-y-auto">
            <p id="brand-profile-description">
              Название, символы и изображения сохраняются.
            </p>
            <div
              className="flex flex-wrap gap-4"
              role="group"
              aria-label="Группы настроек"
            >
              {profileGroups.map((group) => (
                <Checkbox
                  key={group}
                  label={profileGroupNames[group]}
                  checked={groups.includes(group)}
                  disabled={disabled}
                  onCheckedChange={(checked) =>
                    setGroups((current) =>
                      checked === true
                        ? [...current, group]
                        : current.filter((g) => g !== group),
                    )
                  }
                />
              ))}
            </div>
            {differences.length ? (
              <div className="base-brand-profile-diff">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Поле</TableHead>
                      <TableHead>Сейчас</TableHead>
                      <TableHead>Шаблон</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {differences.map((row) => (
                      <TableRow key={row.key}>
                        <TableCell>{row.key}</TableCell>
                        <TableCell>{row.before}</TableCell>
                        <TableCell>{row.after}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <p role="status">Настройки совпадают</p>
            )}
          </div>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => setSelected(null)}
            >
              Отмена
            </Button>
            <Button
              type="button"
              disabled={disabled || !differences.length || !groups.length}
              onClick={() => {
                if (
                  disabled ||
                  !selected ||
                  !groups.length ||
                  !differences.length
                )
                  return;
                onChange(candidate);
                setSelected(null);
              }}
            >
              Применить к форме
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </section>
  );
}
