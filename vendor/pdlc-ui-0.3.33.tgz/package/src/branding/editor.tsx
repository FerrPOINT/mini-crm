import {
  cloneElement,
  useId,
  useState,
  type ReactElement,
  type ReactNode,
} from "react";
import { Info, Link, Palette, Shapes, Type, Upload, X } from "lucide-react";
import {
  Button,
  Input,
  Select,
  Checkbox,
  FormField,
  Disclosure,
  SearchInput,
  Notice,
  Fieldset,
  Label,
} from "../ui";
import { brandingPresets } from "../lib/branding-runtime.js";
import { brandIcons, BrandingMark } from "./mark";
import { BrandingProfilePicker } from "./profile-picker";
import {
  isHex,
  brandValidationErrors,
  palettes,
  radiusLimits,
  radiusNames,
  radiusPresets,
  themeNames,
  themes,
  variantNames,
  type BrandDesignDocument,
  type BrandMark,
  type BrandTheme,
  type MarkVariant,
  type RadiusKey,
} from "./model";

function Field({
  label,
  children,
  error,
}: {
  label: string;
  children: ReactElement<{
    id?: string;
    required?: boolean;
    "aria-invalid"?: boolean;
    "aria-describedby"?: string;
  }>;
  error?: string;
}) {
  const generated = useId();
  const id = children.props.id ?? generated;
  return (
    <div className="base-brand-field">
      <FormField id={id} label={label} error={error}>
        {(attrs) =>
          cloneElement(children, {
            ...attrs,
            required: children.props.required,
          })
        }
      </FormField>
    </div>
  );
}
function ColorField({
  label,
  value,
  disabled,
  onChange,
  error: suppliedError,
}: {
  label: string;
  value: string;
  disabled: boolean;
  onChange: (value: string) => void;
  error?: string;
}) {
  const id = useId();
  const error =
    suppliedError ??
    (!isHex(value) ? "Введите HEX в формате #RRGGBB." : undefined);
  return (
    <div className="base-brand-field">
      <FormField id={id} label={label} error={error}>
        {(attrs) => (
          <div className="base-brand-color">
            <Input
              type="color"
              aria-label={`${label}: выбрать цвет`}
              disabled={disabled}
              value={isHex(value) ? value : "#ffffff"}
              onChange={(e) => onChange(e.target.value)}
            />
            <Input
              {...attrs}
              aria-label={`${label}: HEX`}
              value={value}
              disabled={disabled}
              spellCheck={false}
              onChange={(e) => onChange(e.target.value)}
            />
          </div>
        )}
      </FormField>
    </div>
  );
}
function Block({
  title,
  icon,
  children,
  collapsible = false,
}: {
  title: string;
  icon: ReactNode;
  children: ReactNode;
  collapsible?: boolean;
}) {
  if (collapsible)
    return (
      <Disclosure
        className="base-brand-section"
        summary={
          <span className="base-brand-section-heading">
            {icon}
            {title}
          </span>
        }
      >
        <div className="base-brand-section-fields">{children}</div>
      </Disclosure>
    );
  return (
    <section className="base-brand-block">
      <div className="base-brand-block-heading">
        <h2>
          {icon}
          {title}
        </h2>
      </div>
      {children}
    </section>
  );
}
export function BrandingEditor({
  value,
  onChange: requestChange,
  disabled = false,
  variant,
  onVariantChange,
  colorTheme,
  onUpload,
  uploadError,
  uploading = false,
  uploadDisabledReason,
  assetUrls,
  imageActions,
}: {
  value: BrandDesignDocument;
  onChange: (value: BrandDesignDocument) => void;
  disabled?: boolean;
  variant: MarkVariant;
  onVariantChange: (value: MarkVariant) => void;
  colorTheme: BrandTheme;
  /** @deprecated Pass the application header's theme in colorTheme; the editor has no theme control. */
  onColorThemeChange?: (value: BrandTheme) => void;
  onUpload: (target: MarkVariant | "favicon", file: File) => void;
  uploadError: string;
  uploading?: boolean;
  uploadDisabledReason?: string;
  assetUrls?: ReadonlyMap<string, string>;
  /** Owner-supplied asset-library actions, shown only beside an editable image picker. */
  imageActions?: ReactNode;
}) {
  const onChange = (next: BrandDesignDocument) => {
    if (!disabled) requestChange(next);
  };
  const [query, setQuery] = useState("");
  const id = useId();
  const design = value.design;
  const errors = brandValidationErrors(value);
  const ownMark = design.marks[variant];
  const mark = ownMark ?? design.marks.common;
  const markDisabled = disabled || !ownMark;
  const updateDesign = (patch: Partial<typeof design>) =>
    onChange({ ...value, design: { ...design, ...patch } });
  const updateMark = (patch: Partial<BrandMark>) =>
    updateDesign({
      marks: { ...design.marks, [variant]: { ...mark, ...patch } },
    });
  const uploadField = (
    target: MarkVariant | "favicon",
    currentName: string | undefined,
    blocked: boolean,
  ) => (
    <div className="base-brand-upload">
      <Button
        asChild
        variant="outline"
        className="base-brand-file"
        aria-disabled={blocked || uploading || !!uploadDisabledReason}
      >
        <label>
          <Upload size={16} />
          <span>
            {currentName ? "Заменить изображение" : "Загрузить изображение"}
          </span>
          <input
            type="file"
            aria-label={
              target === "favicon"
                ? "Изображение favicon"
                : "Изображение логотипа"
            }
            disabled={blocked || uploading || !!uploadDisabledReason}
            accept="image/png,image/jpeg,image/webp"
            onChange={(e) => {
              const file = e.currentTarget.files?.[0];
              e.currentTarget.value = "";
              if (file) onUpload(target, file);
            }}
          />
        </label>
      </Button>
      {currentName && (
        <span className="base-brand-filename" title={currentName}>
          {currentName}
        </span>
      )}
      {currentName && (
        <Button
          type="button"
          size="icon"
          variant="ghost"
          disabled={blocked || uploading}
          title="Удалить изображение из формы"
          aria-label={
            target === "favicon" ? "Удалить favicon" : "Удалить изображение"
          }
          onClick={() =>
            target === "favicon"
              ? updateDesign({
                  favicon: { ...design.favicon, mode: "auto", image: null },
                })
              : updateMark({ kind: "letters", image: null })
          }
        >
          <X size={16} />
        </Button>
      )}
    </div>
  );
  return (
    <section className="base-brand-fields" aria-label="Параметры брендинга">
      <BrandingProfilePicker
        value={value}
        onChange={onChange}
        disabled={disabled}
      />
      <Block title="Название" icon={<Type size={18} />}>
        <div className="base-brand-names">
          <Field label="Название платформы" error={errors.product_name}>
            <Input
              value={value.product_name}
              disabled={disabled}
              required
              onChange={(e) =>
                onChange({ ...value, product_name: e.target.value })
              }
            />
          </Field>
          <Field label="Короткое название" error={errors.product_short_name}>
            <Input
              value={value.product_short_name}
              disabled={disabled}
              required
              onChange={(e) =>
                onChange({ ...value, product_short_name: e.target.value })
              }
            />
          </Field>
        </div>
      </Block>
      <Block title="Логотип" icon={<Shapes size={18} />}>
        <Fieldset
          legend="Вариант логотипа"
          legendVisuallyHidden
          className="base-brand-section-fields"
        >
          <div className="base-brand-logo-identity">
            <figure className="base-brand-logo-preview">
              <figcaption>Образец</figcaption>
              <span className="base-brand-logo-sample">
                <BrandingMark
                  document={value}
                  assetUrls={assetUrls}
                  theme={colorTheme}
                  mark={mark}
                  size="shell"
                />
              </span>
            </figure>
            <div className="base-brand-logo-identity-fields">
              <Field label="Для какой темы">
                <Select
                  aria-label="Логотип для"
                  value={variant}
                  onValueChange={(next) => onVariantChange(next as MarkVariant)}
                  options={Object.entries(variantNames).map(
                    ([value, label]) => ({
                      value,
                      label: value === "common" ? "Общий" : label,
                    }),
                  )}
                />
              </Field>
              <Field label="Тип логотипа">
                <Select
                  disabled={markDisabled}
                  value={mark.kind}
                  onValueChange={(kind) =>
                    updateMark({ kind: kind as BrandMark["kind"] })
                  }
                  options={[
                    { value: "letters", label: "Буквы" },
                    { value: "icon", label: "Иконка" },
                    { value: "image", label: "Изображение" },
                  ]}
                />
              </Field>
            </div>
          </div>

          {variant === "common" &&
            (design.marks.light || design.marks.dark) && (
              <p className="base-brand-hint">
                Общий логотип используется в темах без отдельного логотипа.
              </p>
            )}
          {variant !== "common" && (
            <Checkbox
              label="Отдельный знак для этой темы"
              disabled={disabled}
              checked={!!ownMark}
              onCheckedChange={(checked) =>
                updateDesign({
                  marks: {
                    ...design.marks,
                    [variant]: checked === true ? structuredClone(mark) : null,
                  },
                })
              }
            />
          )}
          {!ownMark && (
            <p className="base-brand-hint">
              <Info size={14} />
              Наследуется общий знак
            </p>
          )}
        </Fieldset>
        <Fieldset legend="Оформление логотипа" legendVisuallyHidden separated>
          <div className="base-brand-logo-settings">
            <div className="base-brand-options">
              <Field label="Форма знака">
                <Select
                  disabled={markDisabled}
                  value={String(mark.shape)}
                  onValueChange={(nextValue) =>
                    updateMark({ shape: nextValue as BrandMark["shape"] })
                  }
                  options={[
                    ...[{ value: String("square"), label: String("Квадрат") }],
                    ...[
                      {
                        value: String("rounded"),
                        label: String("Скруглённый"),
                      },
                    ],
                    ...[{ value: String("circle"), label: String("Круг") }],
                  ]}
                />
              </Field>
              {mark.kind === "letters" && (
                <div className="base-brand-letter-fields">
                  <Field label="Символов">
                    <Select
                      aria-label="Количество символов"
                      value={String(mark.count)}
                      disabled={markDisabled}
                      onValueChange={(nextValue) => {
                        const count = Number(nextValue) as 1 | 2 | 4;
                        const lettersByCount = {
                          ...mark.lettersByCount,
                          [mark.count]: mark.letters,
                        };
                        updateMark({
                          count,
                          lettersByCount,
                          letters:
                            lettersByCount[count] ??
                            { 1: "P", 2: "PD", 4: "PDLC" }[count],
                        });
                      }}
                      options={[
                        ...([1, 2, 4].map((c) => ({
                          value: String(c),
                          label: String(c),
                        })) ?? []),
                      ]}
                    />
                  </Field>
                  <Field
                    label="Символы"
                    error={errors[`marks.${variant}.letters`]}
                  >
                    <Input
                      aria-label="Символы знака"
                      value={mark.letters}
                      disabled={markDisabled}
                      spellCheck={false}
                      onChange={(e) => updateMark({ letters: e.target.value })}
                    />
                  </Field>
                </div>
              )}
            </div>
            {mark.kind === "icon" && (
              <>
                <SearchInput
                  aria-label="Поиск иконки"
                  value={query}
                  disabled={markDisabled}
                  onChange={(e) => setQuery(e.target.value)}
                  clear={
                    query
                      ? {
                          label: "Очистить поиск иконки",
                          onClear: () => setQuery(""),
                        }
                      : undefined
                  }
                  placeholder="Найти иконку"
                />
                <div
                  className="base-brand-icons"
                  role="group"
                  aria-label="Иконки платформы"
                >
                  {brandIcons
                    .filter((i) =>
                      `${i.name} ${i.id}`
                        .toLocaleLowerCase()
                        .includes(query.toLocaleLowerCase()),
                    )
                    .map(({ id, name, Icon }) => (
                      <Button
                        key={id}
                        type="button"
                        variant={mark.icon === id ? "secondary" : "ghost"}
                        size="icon"
                        aria-pressed={mark.icon === id}
                        title={name}
                        aria-label={name}
                        disabled={markDisabled}
                        onClick={() => updateMark({ icon: id })}
                      >
                        <Icon size={21} />
                      </Button>
                    ))}
                </div>
                {!brandIcons.some((i) =>
                  `${i.name} ${i.id}`
                    .toLocaleLowerCase()
                    .includes(query.toLocaleLowerCase()),
                ) && <p className="base-brand-hint">Иконки не найдены</p>}
              </>
            )}
            {mark.kind === "image" && (
              <>
                {!markDisabled && imageActions}
                {uploadDisabledReason && (
                  <p className="base-brand-hint">{uploadDisabledReason}</p>
                )}
                {uploadField(variant, mark.image?.name, markDisabled)}
                <div className="base-brand-options">
                  <Field label="Размещение изображения">
                    <Select
                      value={String(mark.fit)}
                      disabled={markDisabled}
                      onValueChange={(nextValue) =>
                        updateMark({ fit: nextValue as BrandMark["fit"] })
                      }
                      options={[
                        ...[
                          {
                            value: String("contain"),
                            label: String("Вписать целиком"),
                          },
                        ],
                        ...[
                          {
                            value: String("cover"),
                            label: String("Заполнить квадрат"),
                          },
                        ],
                      ]}
                    />
                  </Field>
                </div>
                <p className="base-brand-hint">
                  PNG, JPEG или WebP · до 5 MiB · до 4096 px
                </p>
              </>
            )}
            <div className="base-brand-color-fields">
              {mark.kind !== "image" && (
                <ColorField
                  label="Цвет знака"
                  error={errors[`marks.${variant}.foreground`]}
                  value={mark.foreground}
                  disabled={markDisabled}
                  onChange={(foreground) => updateMark({ foreground })}
                />
              )}
              <ColorField
                label="Фон знака"
                error={errors[`marks.${variant}.background`]}
                value={mark.background}
                disabled={markDisabled}
                onChange={(background) => updateMark({ background })}
              />
            </div>
          </div>
        </Fieldset>
        <Disclosure summary="Иконка вкладки браузера">
          <p className="base-brand-hint">По умолчанию создаётся из логотипа.</p>
          <div className="base-brand-favicon">
            <BrandingMark
              document={value}
              theme={colorTheme}
              size={24}
              compact
              assetUrls={assetUrls}
            />
            <Field label="Вид иконки вкладки">
              <Select
                disabled={disabled}
                value={String(design.favicon.mode)}
                onValueChange={(nextValue) =>
                  updateDesign({
                    favicon: {
                      ...design.favicon,
                      mode: nextValue as BrandDesignDocument["design"]["favicon"]["mode"],
                    },
                  })
                }
                options={[
                  ...[{ value: String("logo"), label: String("Как логотип") }],
                  ...[{ value: String("auto"), label: String("Компактный") }],
                  ...[
                    {
                      value: String("image"),
                      label: String("Отдельное изображение"),
                    },
                  ],
                ]}
              />
            </Field>
          </div>
          {design.favicon.mode === "image" &&
            uploadField("favicon", design.favicon.image?.name, disabled)}
        </Disclosure>
        {uploading && (
          <p role="status" className="base-brand-hint">
            Проверка изображения…
          </p>
        )}
        {uploadError && (
          <p role="alert" className="base-brand-error">
            {uploadError}
          </p>
        )}
      </Block>
      <Block title="Цвета" icon={<Palette size={18} />}>
        <div className="base-brand-options">
          <Field label="Готовая палитра">
            <Select
              disabled={disabled}
              title="Применить палитру ко всем трём темам"
              value={
                Object.entries(palettes).find(
                  ([, colors]) =>
                    JSON.stringify(colors) === JSON.stringify(design.colors),
                )?.[0] ?? ""
              }
              placeholder="Своя палитра"
              onValueChange={(name) =>
                updateDesign({
                  colors: structuredClone(
                    palettes[name as keyof typeof palettes],
                  ),
                })
              }
              options={Object.keys(palettes).map((name) => ({
                value: name,
                label: name,
              }))}
            />
          </Field>
        </div>
        <div className="base-brand-color-fields">
          {(["primary", "accent"] as const).map((key) => (
            <ColorField
              key={key}
              label={
                key === "primary" ? "Цвет действий" : "Дополнительный акцент"
              }
              error={errors[`colors.${colorTheme}.${key}`]}
              value={design.colors[colorTheme][key]}
              disabled={disabled}
              onChange={(color) =>
                updateDesign({
                  colors: {
                    ...design.colors,
                    [colorTheme]: {
                      ...design.colors[colorTheme],
                      [key]: color,
                    },
                  },
                })
              }
            />
          ))}
        </div>
        <div className="base-brand-color-fields">
          <Checkbox
            label="Оттенок поверхностей"
            checked={value.surface_color !== null}
            disabled={disabled}
            onCheckedChange={(checked) =>
              onChange({
                ...value,
                surface_color: checked
                  ? design.colors[colorTheme].primary
                  : null,
              })
            }
          />
          {value.surface_color !== null && (
            <ColorField
              label="Цвет поверхностей"
              value={value.surface_color}
              disabled={disabled}
              error={errors.surface_color}
              onChange={(surface_color) =>
                onChange({ ...value, surface_color })
              }
            />
          )}
        </div>
      </Block>
      <Block title="Шрифт и плотность" icon={<Type size={18} />} collapsible>
        <div className="base-brand-options">
          {(
            [
              ["font_preset", "Шрифт"],
              ["type_scale", "Размер текста"],
              ["density", "Плотность"],
            ] as const
          ).map(([key, label]) => (
            <FormField key={key} id={`${id}-${key}`} label={label}>
              {(attrs) => (
                <Select
                  {...attrs}
                  disabled={disabled}
                  value={design[key]}
                  onValueChange={(next) =>
                    updateDesign({ [key]: next } as Partial<typeof design>)
                  }
                  options={brandingPresets[key].map((value) => ({
                    value,
                    label:
                      (
                        {
                          system: "Системный",
                          inter: "Inter",
                          "noto-sans": "Noto Sans",
                          standard: "Стандартный",
                          large: "Крупный",
                          compact: "Компактная",
                          comfortable: "Свободная",
                        } as Record<string, string>
                      )[value] ?? value,
                  }))}
                />
              )}
            </FormField>
          ))}
          <Field label="Начальная тема">
            <Select
              value={String(design.initial_theme)}
              disabled={disabled}
              onValueChange={(nextValue) =>
                updateDesign({ initial_theme: nextValue as BrandTheme })
              }
              options={[
                ...(themes.map((t) => ({
                  value: String(t),
                  label: String(themeNames[t]),
                })) ?? []),
              ]}
            />
          </Field>
        </div>
      </Block>
      <Block title="Скругления" icon={<Shapes size={18} />} collapsible>
        <div className="base-brand-options">
          <Field label="Пресет скруглений">
            <Select
              disabled={disabled}
              value={
                Object.entries(radiusPresets).find(
                  ([, radii]) =>
                    JSON.stringify(radii) === JSON.stringify(design.radii),
                )?.[0] ?? ""
              }
              placeholder="Свои значения"
              onValueChange={(name) =>
                updateDesign({
                  radii: {
                    ...radiusPresets[name as keyof typeof radiusPresets],
                  },
                })
              }
              options={Object.keys(radiusPresets).map((name) => ({
                value: name,
                label: name,
              }))}
            />
          </Field>
        </div>
        {(Object.keys(radiusLimits) as RadiusKey[]).map((key) => (
          <div className="base-brand-radius" key={key}>
            <Label htmlFor={`${id}-${key}`}>{radiusNames[key]}</Label>
            <input
              type="range"
              aria-label={`${radiusNames[key]}: шкала`}
              min={0}
              max={radiusLimits[key]}
              step={1}
              value={Number.isFinite(design.radii[key]) ? design.radii[key] : 0}
              disabled={disabled}
              onChange={(e) =>
                updateDesign({
                  radii: { ...design.radii, [key]: Number(e.target.value) },
                })
              }
            />
            <Input
              id={`${id}-${key}`}
              aria-invalid={!!errors[`radii.${key}`]}
              aria-describedby={
                errors[`radii.${key}`] ? `${id}-${key}-error` : undefined
              }
              type="number"
              min={0}
              max={radiusLimits[key]}
              step={1}
              value={
                Number.isFinite(design.radii[key]) ? design.radii[key] : ""
              }
              disabled={disabled}
              onChange={(e) =>
                updateDesign({
                  radii: {
                    ...design.radii,
                    [key]: e.target.value === "" ? NaN : Number(e.target.value),
                  },
                })
              }
            />
            <span>px</span>
            {errors[`radii.${key}`] && (
              <Notice
                id={`${id}-${key}-error`}
                role="alert"
                tone="danger"
                appearance="inline"
              >
                {errors[`radii.${key}`]}
              </Notice>
            )}
          </div>
        ))}
      </Block>
      <Block title="Ссылки" icon={<Link size={18} />} collapsible>
        <Field label="URL поддержки" error={errors.support_url}>
          <Input
            type="url"
            value={value.support_url ?? ""}
            disabled={disabled}
            placeholder="https://"
            onChange={(e) =>
              onChange({ ...value, support_url: e.target.value || null })
            }
          />
        </Field>
        <Field label="Документация" error={errors.documentation_url}>
          <Input
            type="url"
            value={design.documentation_url}
            disabled={disabled}
            placeholder="https://"
            onChange={(e) =>
              updateDesign({ documentation_url: e.target.value })
            }
          />
        </Field>
      </Block>
    </section>
  );
}
