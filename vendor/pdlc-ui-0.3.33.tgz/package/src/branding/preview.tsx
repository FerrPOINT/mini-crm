import { BrandingPreview as ControlsPreview } from "../ui/branding-editor";
import type { BrandDesignDocument, BrandTheme } from "./model";
export function BrandingPreview({
  document,
  theme,
  assetUrls,
}: {
  document: BrandDesignDocument;
  theme: BrandTheme;
  assetUrls?: ReadonlyMap<string, string>;
}) {
  return (
    <ControlsPreview value={document} theme={theme} assetUrls={assetUrls} />
  );
}
