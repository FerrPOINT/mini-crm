import { createContext, useContext, useMemo, type ReactNode } from "react";
import type { BrandDesignDocument, BrandTheme } from "./model";

const Context = createContext<{
  document: BrandDesignDocument;
  theme: BrandTheme;
} | null>(null);
// Controlled presentation only. Fetching, document head and persistence are separate.
export function BrandingPresentationProvider({
  document,
  theme,
  children,
}: {
  document: BrandDesignDocument;
  theme: BrandTheme;
  children: ReactNode;
}) {
  const value = useMemo(() => ({ document, theme }), [document, theme]);
  return <Context.Provider value={value}>{children}</Context.Provider>;
}
export function useBrandingPresentation() {
  return useContext(Context);
}
