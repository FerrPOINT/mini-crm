// Generated from application-access-client.ts by export-application-access.mjs.
export interface ApplicationAccessV1 {
    readonly schema_version: 1;
    readonly issuer: string;
    readonly subject: string;
    readonly role: "user" | "admin";
    readonly applications: readonly string[];
    readonly revision: number;
    readonly enforced: boolean;
    readonly observed_at: string;
    readonly expires_at: string;
}
export interface ConfirmedApplicationAccess {
    readonly decision: ApplicationAccessV1;
    readonly deadline: number;
    /** Independent JWT lifetime on the same transport/monotonic clock as the proof. */
    readonly tokenDeadline: number;
}
export interface AccessClock {
    readonly issuer: string;
    readonly subject: string;
    readonly startedAt: number;
    readonly receivedAt: number;
    readonly wallAtReceipt: number;
    readonly tokenExpiresAt: number;
}
export declare class ApplicationAccessError extends Error {
    readonly status: number;
    constructor(status: number, message: string);
}
/** UI admission is derived from the owner response; JWT role hints are never read. */
export declare function confirmApplicationAccess(raw: unknown, clock: AccessClock): ConfirmedApplicationAccess;
export declare function permitsApplication(access: ConfirmedApplicationAccess | null, required: readonly string[], administrative?: boolean, now?: number): boolean;
export declare function applicationAccessBoundary(access: ConfirmedApplicationAccess): string;
/** Subject/expiry are correlation bounds only; the owner still verifies the bearer. */
export declare function browserTokenIdentity(token: string): {
    subject: string;
    expiresAt: number;
} | null;
export declare function loadApplicationAccess(issuer: string, token: string, subject: string, tokenExpiresAt: number, signal?: AbortSignal): Promise<ConfirmedApplicationAccess>;
