import { createRemoteJWKSet, jwtVerify } from 'jose'
import { getPlatformProduct } from '../platform/bridge.js'

export interface SsoConfig {
  issuer: string
  clientId: string
  /** Writer cutover is opt-in; both transaction formats are always readable. */
  namespace?: 'sdlc' | 'pdlc'
  /** Same-origin callback path for products installed below a platform prefix. */
  callbackPath?: string
}

interface Transaction {
  state: string
  nonce: string
  verifier: string
  returnTo: string
  createdAt: number
}

export interface SsoSession {
  accessToken: string
  expiresAt: number
  subject: string
  email: string
  name: string
  returnTo: string
}

function randomValue(): string {
  const bytes = new Uint8Array(32)
  crypto.getRandomValues(bytes)
  return btoa(String.fromCharCode(...bytes)).replaceAll('+', '-').replaceAll('/', '_').replaceAll('=', '')
}

function safeReturnTo(value: string): string {
  if (!value.startsWith('/') || value.startsWith('//') || value.includes('\\')) return '/'
  for (const character of value) {
    const code = character.charCodeAt(0)
    if (code < 0x20 || code === 0x7f) return '/'
  }
  return value
}

function callbackPath(path = '/sso/callback'): string {
  const parsed = new URL(path, window.location.origin)
  if (!path.startsWith('/') || path.startsWith('//') || path.includes('\\')
      || parsed.origin !== window.location.origin || parsed.pathname !== path
      || parsed.search || parsed.hash) throw new Error('Некорректный путь SSO callback.')
  return path
}

function callbackUrl(config: SsoConfig): string {
  return `${window.location.origin}${callbackPath(config.callbackPath)}`
}

function canonicalizeLoopback(config: SsoConfig, returnTo: string): boolean {
  const issuerHostname = new URL(config.issuer).hostname
  const loopbackHosts = new Set(['127.0.0.1', 'localhost'])
  if (!loopbackHosts.has(window.location.hostname) || !loopbackHosts.has(issuerHostname)
      || window.location.hostname === issuerHostname) return false
  const canonical = new URL(safeReturnTo(returnTo), window.location.origin)
  canonical.hostname = issuerHostname
  window.location.replace(canonical.toString())
  return true
}

function key(config: SsoConfig): string {
  return `${config.namespace ?? 'sdlc'}.oidc.${config.clientId}`
}

function clearTransactions(config: SsoConfig): void {
  for (const namespace of ['sdlc', 'pdlc']) sessionStorage.removeItem(`${namespace}.oidc.${config.clientId}`)
}

function saveTransaction(config: SsoConfig, transaction: Transaction): void {
  clearTransactions(config)
  sessionStorage.setItem(key(config), JSON.stringify(transaction))
}

async function prepareAuthorization(config: SsoConfig, returnTo: string) {
  const issuer = config.issuer.replace(/\/$/, '')
  const verifier = randomValue()
  const digest = new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(verifier)))
  const challenge = btoa(String.fromCharCode(...digest)).replaceAll('+', '-').replaceAll('/', '_').replaceAll('=', '')
  const transaction: Transaction = {
    state: randomValue(), nonce: randomValue(), verifier,
    returnTo: safeReturnTo(returnTo), createdAt: Date.now(),
  }
  const url = new URL(`${issuer}/oidc/authorize`)
  url.search = new URLSearchParams({
    response_type: 'code', client_id: config.clientId, redirect_uri: callbackUrl(config),
    scope: 'openid email profile', state: transaction.state, nonce: transaction.nonce,
    code_challenge: challenge, code_challenge_method: 'S256',
  }).toString()
  return { url: url.toString(), transaction }
}

export async function authorizationUrl(config: SsoConfig, returnTo = '/'): Promise<string> {
  const { url, transaction } = await prepareAuthorization(config, returnTo)
  saveTransaction(config, transaction)
  return url
}

const loginInFlight = new Map<string, Promise<void>>()
// Full-page logout must win over auth guards starting another PKCE login.
let endingSso = false
let ssoGeneration = 0

export interface BeginSsoOptions {
  /** Explicit login action, not an automatic authentication guard. */
  interactive?: boolean
}

export class SsoLogoutPendingError extends Error {
  constructor() {
    super('Завершается выход из PDLC.')
    this.name = 'SsoLogoutPendingError'
  }
}

export function isSsoNavigationInterruption(error: unknown): boolean {
  return error instanceof SsoLogoutPendingError || (error instanceof Error && error.name === 'SsoLogoutPendingError') || (error instanceof DOMException && error.name === 'AbortError')
}

function navigateToLogin(url: string): Promise<void> {
  const navigation = (window as Window & { navigation?: EventTarget }).navigation
  return new Promise((resolve, reject) => {
    let observed = false
    const cleanup = () => {
      navigation?.removeEventListener('navigate', observeNavigation)
      window.removeEventListener?.('pagehide', finish)
    }
    const finish = () => { cleanup(); resolve() }
    const cancelled = () => { cleanup(); reject(new DOMException('Вход отменён.', 'AbortError')) }
    const observeNavigation = (event: Event) => {
      const navigationEvent = event as Event & { destination: { url: string }; signal: AbortSignal }
      if (navigationEvent.destination.url !== url) return
      observed = true
      if (navigationEvent.signal.aborted) cancelled()
      else navigationEvent.signal.addEventListener('abort', cancelled, { once: true })
    }
    navigation?.addEventListener('navigate', observeNavigation, { once: true })
    window.addEventListener?.('pagehide', finish, { once: true })
    try {
      window.location.assign(url)
      if (!observed) finish()
    } catch (error) {
      cleanup()
      reject(error)
    }
  })
}

export async function beginSso(config: SsoConfig, returnTo = '/', options: BeginSsoOptions = {}): Promise<void> {
  if (endingSso && !options.interactive) throw new SsoLogoutPendingError()
  if (options.interactive) endingSso = false
  if (canonicalizeLoopback(config, returnTo)) return
  const pending = loginInFlight.get(config.clientId)
  if (pending) return pending
  const generation = ssoGeneration
  const attempt = prepareAuthorization(config, returnTo).then(({ url, transaction }) => {
    if (endingSso || generation !== ssoGeneration) return
    saveTransaction(config, transaction)
    return navigateToLogin(url)
  }).catch((error) => {
    if (generation === ssoGeneration) clearTransactions(config)
    throw error
  })
  loginInFlight.set(config.clientId, attempt)
  try { await attempt } finally {
    if (loginInFlight.get(config.clientId) === attempt) loginInFlight.delete(config.clientId)
  }
}

async function exchangeSso(config: SsoConfig, params: URLSearchParams, transaction: Transaction): Promise<SsoSession> {
  const code = params.get('code')
  const state = params.get('state')
  if (!state || transaction.state !== state || Date.now() - transaction.createdAt > 600_000 || transaction.createdAt > Date.now()) {
    throw new Error('Сессия входа истекла или не совпала.')
  }
  if (params.get('error') === 'login_required') throw new SsoLoginRequiredError()
  if (params.has('error') || !code) throw new Error('Central Auth не подтвердил вход.')
  const issuer = config.issuer.replace(/\/$/, '')
  const response = await fetch(`${issuer}/oidc/token`, {
    method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'authorization_code', client_id: config.clientId,
      redirect_uri: callbackUrl(config), code, code_verifier: transaction.verifier,
    }),
  })
  if (!response.ok) throw new Error('Central Auth отклонил вход. Повторите попытку.')
  const tokens = await response.json() as { access_token: string; id_token: string; expires_in: number }
  if (!tokens.access_token || !tokens.id_token) throw new Error('Central Auth вернул неполный ответ.')
  const jwks = createRemoteJWKSet(new URL(`${issuer}/oidc/jwks`))
  const { payload } = await jwtVerify(tokens.id_token, jwks, {
    issuer, audience: config.clientId, algorithms: ['ES256'],
  })
  if (payload.nonce !== transaction.nonce || typeof payload.sub !== 'string' || typeof payload.email !== 'string') {
    throw new Error('Подтверждение входа не прошло проверку.')
  }
  return {
    accessToken: tokens.access_token,
    expiresAt: Date.now() + tokens.expires_in * 1000,
    subject: payload.sub,
    email: payload.email,
    name: typeof payload.name === 'string' ? payload.name : payload.email,
    returnTo: safeReturnTo(transaction.returnTo),
  }
}

const sessionGenerations = new WeakMap<SsoSession, number>()
export function applySsoSession(session: SsoSession, apply: () => void): void {
  if (endingSso || (sessionGenerations.has(session) && sessionGenerations.get(session) !== ssoGeneration)) throw new SsoLogoutPendingError()
  apply()
}

export async function completeSso(config: SsoConfig): Promise<SsoSession> {
  const generation = ssoGeneration
  const params = new URLSearchParams(window.location.search)
  window.history.replaceState(window.history.state, '', window.location.pathname)
  const transactions = ['pdlc', 'sdlc'].map(namespace => sessionStorage.getItem(`${namespace}.oidc.${config.clientId}`)).filter((value): value is string => value !== null)
  const raw = transactions.find(value => {
    try { return value && JSON.parse(value).state === params.get('state') } catch { return false }
  }) ?? transactions[0]
  clearTransactions(config)
  if (!raw) throw new Error('Не удалось завершить вход. Повторите попытку.')
  let transaction: Transaction
  try { transaction = JSON.parse(raw) as Transaction } catch { throw new Error('Сессия входа повреждена.') }
  const session = await exchangeSso(config, params, transaction)
  if (endingSso || generation !== ssoGeneration) throw new SsoLogoutPendingError()
  sessionGenerations.set(session, generation)
  return session
}

export class SsoLoginRequiredError extends Error {
  constructor() { super('Требуется вход через SSO.'); this.name = 'SsoLoginRequiredError' }
}
export function isSsoLoginRequired(error: unknown): boolean {
  return error instanceof Error && error.name === 'SsoLoginRequiredError'
}

/** Callback iframe relays only the one-use code/state; it never receives a token. */
export function relaySsoCallback(namespace: 'sdlc' | 'pdlc' = 'sdlc', path = '/sso/callback'): boolean {
  if (window.parent === window || window.location.pathname !== callbackPath(path)) return false
  const params = new URLSearchParams(window.location.search)
  const state = params.get('state')
  if (!state) return false
  window.parent.postMessage({ type: `${namespace}.oidc.response`, state, code: params.get('code'), error: params.get('error') }, window.location.origin)
  window.history.replaceState(null, '', window.location.pathname)
  return true
}

const restoring = new Map<string, Promise<SsoSession>>()
const restorationAborters = new Set<() => void>()
export function restoreSso(config: SsoConfig, returnTo = window.location.pathname + window.location.search + window.location.hash, options: { timeoutMs?: number } = {}): Promise<SsoSession> {
  if (endingSso) return Promise.reject(new SsoLogoutPendingError())
  if (canonicalizeLoopback(config, returnTo)) return Promise.reject(new DOMException('Переход на настроенный SSO hostname.', 'AbortError'))
  const id = config.issuer + ':' + config.clientId + ':' + callbackPath(config.callbackPath)
  const pending = restoring.get(id)
  if (pending) return pending
  const generation = ssoGeneration
  const promise = prepareAuthorization(config, returnTo).then(({ url, transaction }) => new Promise<SsoSession>((resolve, reject) => {
    if (endingSso || generation !== ssoGeneration) { reject(new SsoLogoutPendingError()); return }
    const frame = document.createElement('iframe')
    frame.hidden = true; frame.title = 'Техническая проверка SSO'; frame.setAttribute('aria-hidden', 'true')
    const authorization = new URL(url); authorization.searchParams.set('prompt', 'none')
    frame.src = authorization.href
    let settled = false
    const timer = window.setTimeout(() => finish(new Error('Central Auth не ответил. Повторите попытку.')), options.timeoutMs ?? 10000)
    const abort = () => finish(new SsoLogoutPendingError())
    const cleanup = () => { clearTimeout(timer); frame.remove(); window.removeEventListener('message', receive); restorationAborters.delete(abort) }
    const finish = (error: Error | null, session?: SsoSession) => {
      if (settled) return
      settled = true; cleanup()
      if (error) reject(error); else resolve(session!)
    }
    const receive = (event: MessageEvent) => {
      const data = event.data
      if (settled || event.origin !== window.location.origin || event.source !== frame.contentWindow || !data || !['sdlc.oidc.response', 'pdlc.oidc.response'].includes(data.type) || data.state !== transaction.state) return
      if ((typeof data.code !== 'string' && typeof data.error !== 'string') || (data.code && data.error)) { finish(new Error('Некорректный ответ SSO.')); return }
      window.removeEventListener('message', receive)
      const params = new URLSearchParams({ state: data.state })
      if (data.code) params.set('code', data.code)
      if (data.error) params.set('error', data.error)
      void exchangeSso(config, params, transaction).then(session => {
        if (endingSso || generation !== ssoGeneration) { finish(new SsoLogoutPendingError()); return }
        sessionGenerations.set(session, generation); finish(null, session)
      }).catch(error => finish(error instanceof Error ? error : new Error('Не удалось проверить SSO.')))
    }
    restorationAborters.add(abort)
    window.addEventListener('message', receive)
    document.body.append(frame)
  }))
  restoring.set(id, promise)
  void promise.finally(() => { if (restoring.get(id) === promise) restoring.delete(id) }).catch(() => undefined)
  return promise
}

export function endSso(config: SsoConfig): void {
  const url = new URL(`${config.issuer.replace(/\/$/, '')}/oidc/logout`)
  url.searchParams.set('client_id', config.clientId)
  endingSso = true
  const generation = ++ssoGeneration
  loginInFlight.clear()
  for (const abort of restorationAborters) abort()
  restoring.clear()
  clearTransactions(config)
  const navigation = (window as Window & { navigation?: EventTarget }).navigation
  const clearLogout = () => {
    navigation?.removeEventListener('navigate', observeNavigation)
    window.removeEventListener?.('pagehide', clearLogout)
    if (generation === ssoGeneration) endingSso = false
  }
  const observeNavigation = (event: Event) => {
    const navigationEvent = event as Event & { destination: { url: string }; signal: AbortSignal }
    if (navigationEvent.destination.url !== url.toString()) return
    if (navigationEvent.signal.aborted) clearLogout()
    else navigationEvent.signal.addEventListener('abort', clearLogout, { once: true })
  }
  navigation?.addEventListener('navigate', observeNavigation, { once: true })
  window.addEventListener?.('pagehide', clearLogout, { once: true })
  try {
    const product = getPlatformProduct()
    if (product) product.endingSession(url.toString())
    else window.location.assign(url.toString())
  } catch (error) {
    clearLogout()
    throw error
  }
}

/** Explicit writer switch; readers accept both generations during migration. */
export function ssoNamespace(value?: string): 'sdlc' | 'pdlc' {
  if (value === undefined || value === 'sdlc') return 'sdlc'
  if (value === 'pdlc') return 'pdlc'
  throw new Error('VITE_AUTH_NAMESPACE must be sdlc or pdlc')
}
