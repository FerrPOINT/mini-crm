// Generated from checked JavaScript/JSDoc by runtime-declarations.mjs.
/** The only browser clipboard transport for React and SSR. No fallback, logging or retry. */
/** @param {string} value */
export function writeClipboardText(value: string): Promise<void>;
/**
 * Activate a macro-owned control. The source element and its exact text are read on activation.
 * Refresh after changing its resource; destroy before replacing a control that may still be pending.
 * @param {HTMLButtonElement} button
 * @param {Object} [options]
 * @param {(value:string)=>Promise<void>} [options.writeText] Synthetic test transport only.
 * @returns {CopyController | undefined}
 */
export function initCopyButton(button: HTMLButtonElement, options?: {
    writeText?: (value: string) => Promise<void>;
}): CopyController | undefined;
/** @param {HTMLButtonElement} button */
export function refreshCopyButton(button: HTMLButtonElement): void;
/** @param {HTMLButtonElement} button */
export function destroyCopyButton(button: HTMLButtonElement): void;
export type CopyController = {
    copy: () => Promise<boolean>;
    refresh: () => void;
    destroy: () => void;
};
