/** Transport and server failures cannot establish whether a write committed. */
export function isUnknownWriteOutcome(error: unknown): boolean {
  const status = error && typeof error === 'object' && 'status' in error ? error.status : undefined
  return typeof status !== 'number' || !Number.isFinite(status) || status < 400 || status === 408 || status >= 500
}
