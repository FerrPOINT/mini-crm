export interface QueryCodec<T> { parse(value: string | null): T; format(value: T): string | null }

export function textQuery(defaultValue = ''): QueryCodec<string> {
  return { parse: (value) => value ?? defaultValue, format: (value) => value === defaultValue ? null : value }
}
export function enumQuery<T extends string>(values: readonly T[], defaultValue: T): QueryCodec<T> {
  return { parse: (value) => values.includes(value as T) ? value as T : defaultValue, format: (value) => value === defaultValue ? null : value }
}
export function positiveIntegerQuery(defaultValue = 1): QueryCodec<number> {
  return {
    parse: (value) => { const parsed = value ? Number(value) : NaN; return Number.isSafeInteger(parsed) && parsed > 0 ? parsed : defaultValue },
    format: (value) => value === defaultValue ? null : String(value),
  }
}
export function updateQuery(search: URLSearchParams, patch: Record<string, string | null>, resetPage = false): URLSearchParams {
  const next = new URLSearchParams(search)
  if (resetPage) next.delete('page')
  for (const [key, value] of Object.entries(patch)) { if (value === null || value === '') next.delete(key); else next.set(key, value) }
  return next
}
