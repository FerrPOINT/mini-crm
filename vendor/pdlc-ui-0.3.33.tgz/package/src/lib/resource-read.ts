import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { resourceErrorState, type ResourceState } from '../ui/page-patterns'

interface Snapshot<T> { scope: string; data?: T; state: ResourceState; fresh: boolean }

/** Read-only lifecycle. Cached values never cross an identity boundary or survive access denial. */
export function useResourceRead<T>(read: () => Promise<T>, scope: string) {
  const reader = useMemo(() => ({ read, scope }), [read, scope])
  const activeReader = useRef<typeof reader | null>(reader)
  const sequence = useRef(0)
  const confirmed = useRef<{ scope: string; data: T } | null>(null)
  const [snapshot, setSnapshot] = useState<Snapshot<T>>({ scope, state: { kind: 'loading' }, fresh: false })
  const reload = useCallback(async () => {
    if (activeReader.current !== reader) return undefined
    const attempt = ++sequence.current
    if (confirmed.current?.scope !== scope) confirmed.current = null
    setSnapshot({ scope, data: confirmed.current?.data, state: { kind: 'loading' }, fresh: false })
    try {
      const data = await read()
      if (attempt !== sequence.current) return undefined
      confirmed.current = { scope, data }
      setSnapshot({ scope, data, state: { kind: 'ready' }, fresh: true })
      return data
    } catch (error) {
      if (attempt !== sequence.current) return undefined
      const status = error && typeof error === 'object' && 'status' in error ? error.status : undefined
      if (status === 401 || status === 403 || status === 404) confirmed.current = null
      const failure = resourceErrorState(error)
      const state: ResourceState = confirmed.current
        ? { kind: 'partial-error', message: 'Не удалось обновить данные. Показано последнее подтверждённое состояние.' }
        : failure
      setSnapshot({ scope, data: confirmed.current?.data, state, fresh: false })
      return undefined
    }
  }, [read, scope, reader])
  const invalidate = useCallback(() => { sequence.current++ }, [])
  useEffect(() => {
    activeReader.current = reader
    void reload()
    return () => { activeReader.current = null; invalidate() }
  }, [reload, invalidate, reader])
  /** The owner admits a confirmed mutation result without allowing an older read to undo it. */
  const updateConfirmed = useCallback((update: (data: T | undefined) => T | undefined) => {
    if (activeReader.current !== reader) return
    const data = update(confirmed.current?.scope === scope ? confirmed.current.data : undefined)
    if (data === undefined) return
    sequence.current++
    confirmed.current = { scope, data }
    setSnapshot(previous => ({ scope, data, fresh: previous.scope === scope && previous.fresh,
      state: previous.scope === scope && previous.state.kind === 'ready' ? previous.state
        : { kind: 'partial-error', message: 'Данные обновлены частично. Обновите состояние.' } }))
  }, [scope, reader])
  // Do not expose the previous identity's data during the render preceding effect cleanup.
  const current: Snapshot<T> = snapshot.scope === scope ? snapshot : { scope, state: { kind: 'loading' }, fresh: false }
  const state = current.state.kind === 'error' || current.state.kind === 'partial-error'
    ? { ...current.state, onRetry: () => { void reload() } } : current.state
  return { data: current.data, state, fresh: current.fresh, reload, updateConfirmed }
}
