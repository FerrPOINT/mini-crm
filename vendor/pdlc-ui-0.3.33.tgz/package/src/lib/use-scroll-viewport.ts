import { useLayoutEffect, useMemo, type RefObject } from "react";

type Snapshot = {
  height: number;
  anchor?: { element: Element; offset: number };
};
type Capture = {
  node: HTMLElement;
  snapshot: Snapshot;
  valid: boolean;
  scheduled: boolean;
  cancel?: () => void;
};
type Frame = { view: Window; id: number; settled: boolean };

function snapshot(node: HTMLElement): Snapshot {
  const top = node.getBoundingClientRect().top + node.clientTop;
  const bottom = top + node.clientHeight;
  for (const element of node.querySelectorAll("[data-scroll-anchor]")) {
    const bounds = element.getBoundingClientRect();
    if (bounds.bottom > top && bounds.top < bottom)
      return {
        height: node.scrollHeight,
        anchor: { element, offset: bounds.top - top },
      };
  }
  return { height: node.scrollHeight };
}

function controller<T extends HTMLElement>(
  ref: RefObject<T | null>,
  scope: string,
) {
  let activeScope: string | null = scope;
  let capture: Capture | null = null;
  let cancelRestore = () => {};
  const frames = new Set<Frame>();
  const owns = (node: HTMLElement | null): node is HTMLElement =>
    Boolean(
      activeScope === scope && node && ref.current === node && node.isConnected,
    );
  function invalidateCapture() {
    if (!capture) return;
    capture.valid = false;
    capture.cancel?.();
    capture = null;
  }
  function cancelFrames() {
    for (const frame of frames) {
      frame.settled = true;
      frame.view.cancelAnimationFrame(frame.id);
    }
    frames.clear();
  }
  function schedule(node: HTMLElement, work: () => void, skipped?: () => void) {
    const view = node.ownerDocument.defaultView;
    if (!view) return () => {};
    const frame: Frame = { view, id: 0, settled: false };
    frame.id = view.requestAnimationFrame(() => {
      if (frame.settled) return;
      frame.settled = true;
      frames.delete(frame);
      if (owns(node)) work();
      else skipped?.();
    });
    frames.add(frame);
    return () => {
      if (frame.settled) return;
      frame.settled = true;
      view.cancelAnimationFrame(frame.id);
      frames.delete(frame);
    };
  }
  const viewport = {
    /** Call from a visible viewport's scroll handler, retaining owner-specific tolerances. */
    observe(tolerance: number, inclusive = false) {
      const node = ref.current;
      if (!owns(node) || node.clientHeight <= 0) return null;
      if (capture?.valid && capture.node === node)
        capture.snapshot = snapshot(node);
      const distance = node.scrollHeight - node.scrollTop - node.clientHeight;
      return {
        top: node.scrollTop,
        atEnd: inclusive ? distance <= tolerance : distance < tolerance,
      };
    },
    /** Explicit user intent supersedes queued restoration and older history results. */
    scrollToEnd() {
      invalidateCapture();
      cancelFrames();
      const node = ref.current;
      if (!owns(node)) return false;
      node.scrollTop = node.scrollHeight;
      return true;
    },
    /** Deferred layout restoration; a getter reads the latest owner intent at execution time. */
    restore(
      position: number | "end" | (() => number | "end"),
      after?: (position: number | "end", top: number) => void,
    ) {
      cancelRestore();
      const node = ref.current;
      if (!owns(node)) return () => {};
      cancelRestore = schedule(node, () => {
        const target = typeof position === "function" ? position() : position;
        node.scrollTop = target === "end" ? node.scrollHeight : target;
        after?.(target, node.scrollTop);
      });
      return cancelRestore;
    },
    /** Capture before loading; apply after the owner commits its older rows. */
    preservePrepend(after?: (top: number) => void) {
      invalidateCapture();
      const node = ref.current;
      if (!owns(node)) {
        const unavailable: (options?: { defer?: boolean }) => boolean = () =>
          false;
        return Object.assign(unavailable, { cancel() {} });
      }
      const operation: Capture = {
        node,
        snapshot: snapshot(node),
        valid: true,
        scheduled: false,
      };
      capture = operation;
      function discard() {
        operation.valid = false;
        operation.cancel?.();
        if (capture === operation) capture = null;
      }
      function apply() {
        if (!operation.valid || !owns(node)) {
          discard();
          return false;
        }
        operation.valid = false;
        if (capture === operation) capture = null;
        const anchor = operation.snapshot.anchor;
        if (anchor && !node.contains(anchor.element)) return false;
        const delta = anchor
          ? anchor.element.getBoundingClientRect().top -
            node.getBoundingClientRect().top -
            node.clientTop -
            anchor.offset
          : node.scrollHeight - operation.snapshot.height;
        node.scrollTop += delta;
        after?.(node.scrollTop);
        return true;
      }
      const finish = (options: { defer?: boolean } = {}) => {
        if (!operation.valid || !owns(node)) {
          discard();
          return false;
        }
        if (operation.scheduled) return false;
        if (options.defer === false) return apply();
        operation.scheduled = true;
        operation.cancel = schedule(node, apply, discard);
        return true;
      };
      return Object.assign(finish, { cancel: discard });
    },
  };
  return {
    viewport,
    mount() {
      activeScope = scope;
      return () => {
        activeScope = null;
        invalidateCapture();
        cancelFrames();
      };
    },
  };
}

/** Shared viewport geometry only; data, follow/unread policy and panel visibility remain owner-controlled. */
export function useScrollViewport<T extends HTMLElement>(
  ref: RefObject<T | null>,
  scope: string,
) {
  const state = useMemo(() => controller(ref, scope), [ref, scope]);
  useLayoutEffect(() => state.mount(), [state]);
  return state.viewport;
}
