import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useSyncExternalStore,
} from "react";
import "./theme-preference.js";
import type { Theme } from "./theme-preference.js";

interface ThemeContextValue {
  theme: Theme;
  setTheme: (theme: Theme) => void;
  setPlatformDefault: (theme: Theme | null) => void;
}

const ThemeContext = createContext<ThemeContextValue | null>(null);

export interface ThemeProviderProps {
  children: React.ReactNode;
  /** Controlled previews do not read, persist or subscribe to platform preferences. */
  theme?: Theme;
  onThemeChange?: (theme: Theme) => void;
}

export function ThemeProvider({
  children,
  theme: controlledTheme,
  onThemeChange,
}: ThemeProviderProps) {
  const setPlatformDefault = useCallback((value: Theme | null) => {
    window.PdlcThemePreference.setPlatformDefault?.(value);
  }, []);
  const controlled = controlledTheme !== undefined;
  const subscribe = useCallback(
    (notify: () => void) =>
      controlled ? () => {} : window.PdlcThemePreference.subscribe(notify),
    [controlled],
  );
  const getSnapshot = useCallback(
    () => controlledTheme ?? window.PdlcThemePreference.read(),
    [controlledTheme],
  );
  const theme = useSyncExternalStore(
    subscribe,
    getSnapshot,
    () => controlledTheme ?? "dark",
  );

  const setTheme = useCallback(
    (value: Theme) => {
      if (controlled) {
        onThemeChange?.(value);
        return;
      }
      window.PdlcThemePreference.set(value);
      onThemeChange?.(value);
    },
    [controlled, onThemeChange],
  );

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
  }, [theme]);

  return (
    <ThemeContext.Provider value={{ theme, setTheme, setPlatformDefault }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error("useTheme must be used within ThemeProvider");
  return ctx;
}

export function useOptionalTheme() {
  return useContext(ThemeContext);
}
