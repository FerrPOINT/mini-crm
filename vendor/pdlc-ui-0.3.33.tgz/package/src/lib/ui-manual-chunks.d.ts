// Generated from checked JavaScript/JSDoc by runtime-declarations.mjs.
/**
 * Resolve context providers from the consuming application, including workspace peers.
 * @returns {string[]}
 */
export function createUiProviderDedupe(): string[];
/**
 * Isolate Vite's prebundle by the installed UI production inputs.
 * File dependencies can keep the same lock entry after their source changes.
 * Reference/docs-only changes retain the warm cache; Vite owns other dependency invalidation.
 * @param {string} [cacheRoot] Consumer-owned cache directory, relative to its Vite root or absolute.
 * @returns {string}
 */
export function createUiDevCacheDir(cacheRoot?: string): string;
/**
 * Keep Vite's disk prebundle and immutable browser dependency URLs on the same UI revision.
 * Vite hashes plugin names; cacheDir alone does not invalidate its browser graph.
 * @param {string} [cacheRoot] Consumer-owned cache directory.
 * @returns {{name: string, apply: 'serve', config: () => {cacheDir: string}}}
 */
export function createUiDevCachePlugin(cacheRoot?: string): {
    name: string;
    apply: "serve";
    config: () => {
        cacheDir: string;
    };
};
/** Resolve UI chunks from actual module IDs, without product-owned Radix copies. */
/** @param {Record<string, readonly string[]>} [groups] @returns {(id: string) => string | undefined} */
export function createUiManualChunks(groups?: Record<string, readonly string[]>): (id: string) => string | undefined;
/** Emit the complete font notices beside bundled assets; CSS preprocessors may remove comments.
 * @returns {{name: string, apply: 'build', generateBundle: (this: {emitFile: (asset: {type: 'asset', fileName: string, source: string}) => unknown}) => void}}
 */
export function createUiFontAssetsPlugin(): {
    name: string;
    apply: "build";
    generateBundle: (this: {
        emitFile: (asset: {
            type: "asset";
            fileName: string;
            source: string;
        }) => unknown;
    }) => void;
};
