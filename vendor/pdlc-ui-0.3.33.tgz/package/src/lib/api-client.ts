// Shared fetch wrapper for Base fleet frontends.
//
// Wraps fetch with the fleet conventions used by every service frontend:
//   - JSON bodies with Content-Type header
//   - credentials: 'include' (HttpOnly refresh cookies)
//   - bearer token from an injectable getter
//   - typed error envelope { error: string } matching the Rust AppError shape
//
// Usage in a service:
//
//   const client = createApiClient({
//     baseUrl: import.meta.env.VITE_API_BASE_URL ?? '',
//     getAccessToken: () => useAuthStore.getState().token,
//     onUnauthorized: () => { useAuthStore.getState().logout(); location.href = '/login' },
//   })
//   const user = await client.get<User>('/api/v1/auth/me')

import { getPlatformProduct } from '../platform/bridge.js'

export interface ApiClientOptions {
  /** Base URL prefix (e.g. '' for same-origin or 'http://127.0.0.1:22801'). */
  baseUrl?: string
  /** Returns the current access token; omit for cookie-only auth. */
  getAccessToken?: () => string | null | undefined
  /** Called once on a 401 after the optional refresh attempt failed. */
  onUnauthorized?: () => void
  /** Hook that attempts a token refresh; return true to retry the request. */
  refresh?: () => Promise<boolean>
}

/** Fleet error envelope: {"error": {"code", "message"}} (Rust AppError). */
interface FleetErrorBody {
  error?: { code?: string; message?: string } | string
}

export class ApiError extends Error {
  readonly code?: string
  readonly body?: unknown
  readonly requestId?: string
  constructor(
    readonly status: number,
    message: string,
    body?: unknown,
    requestId?: string,
  ) {
    super(message)
    this.name = 'ApiError'
    this.body = body
    this.requestId = requestId
    const envelope =
      body && typeof body === 'object' && 'error' in (body as FleetErrorBody)
        ? (body as FleetErrorBody).error
        : undefined
    this.code =
      envelope && typeof envelope === 'object' && typeof envelope.code === 'string'
        ? envelope.code
        : undefined
  }
}

/** A successful JSON endpoint returned an empty or malformed document. */
export class InvalidResponseError extends ApiError {
  constructor(status: number, requestId?: string) {
    super(status, 'invalid JSON response', undefined, requestId)
    this.name = 'InvalidResponseError'
  }
}

interface InternalOptions {
  method?: string
  body?: unknown
  signal?: AbortSignal
  /** Internal: set when retrying after refresh. */
  _retried?: boolean
}

export interface ApiClient {
  /** Native fetch options; streaming bodies cannot be used with automatic refresh. */
  request<T>(path: string, init?: RequestInit): Promise<T>
  get<T>(path: string, signal?: AbortSignal): Promise<T>
  post<T>(path: string, body?: unknown, signal?: AbortSignal): Promise<T>
  put<T>(path: string, body?: unknown, signal?: AbortSignal): Promise<T>
  patch<T>(path: string, body?: unknown, signal?: AbortSignal): Promise<T>
  delete<T>(path: string, signal?: AbortSignal): Promise<T>
  raw(path: string, init?: InternalOptions): Promise<Response>
}

export function createApiClient(options: ApiClientOptions = {}): ApiClient {
  const baseUrl = (options.baseUrl ?? '').replace(/\/+$/, '')

  async function transport(path: string, init: RequestInit = {}, retried = false): Promise<Response> {
    if (options.refresh && typeof ReadableStream !== 'undefined' && init.body instanceof ReadableStream) {
      throw new TypeError('Streaming request bodies cannot be replayed after authentication refresh')
    }
    const headers = new Headers(init.headers)
    const token = options.getAccessToken?.()
    if (token && !headers.has('Authorization')) headers.set('Authorization', `Bearer ${token}`)

    const res = await fetch(`${baseUrl}${path}`, {
      credentials: 'include',
      ...init,
      headers,
    })

    const product = res.status === 401 ? getPlatformProduct() : null
    if (product) { product.recheckAuthorization(); return res }
    if (res.status === 401 && !retried && options.refresh) {
      const refreshed = await options.refresh()
      if (refreshed) return transport(path, init, true)
    }
    if (res.status === 401) options.onUnauthorized?.()
    return res
  }

  async function raw(path: string, init: InternalOptions = {}): Promise<Response> {
    return transport(path, {
      method: init.method ?? 'GET',
      signal: init.signal,
      headers: init.body !== undefined ? { 'Content-Type': 'application/json' } : undefined,
      body: init.body !== undefined ? JSON.stringify(init.body) : undefined,
    }, init._retried)
  }

  async function json<T>(res: Response): Promise<T> {
    if (res.status === 204) return undefined as T
    const text = await res.text()
    const data = text ? safeJson(text) : undefined
    if (!res.ok) {
      const message =
        (data && typeof data === 'object' && 'error' in data
          ? typeof data.error === 'string'
            ? data.error
            : data.error && typeof data.error === 'object' && 'message' in data.error
              ? String((data.error as { message?: string }).message)
              : undefined
          : undefined) ?? `request failed: ${res.status}`
      throw new ApiError(res.status, message, data, res.headers.get('x-request-id') ?? undefined)
    }
    if (!text || data === undefined) {
      throw new InvalidResponseError(res.status, res.headers.get('x-request-id') ?? undefined)
    }
    return data as T
  }

  function safeJson(text: string): unknown {
    try {
      return JSON.parse(text)
    } catch {
      return undefined
    }
  }

  return {
    request: async <T,>(path: string, init?: RequestInit) => {
      const response = await transport(path, init)
      if (init?.method?.toUpperCase() === 'HEAD' && response.ok) return undefined as T
      return json<T>(response)
    },
    get: async <T,>(path: string, signal?: AbortSignal) =>
      json<T>(await raw(path, { signal })),
    post: async <T,>(path: string, body?: unknown, signal?: AbortSignal) =>
      json<T>(await raw(path, { method: 'POST', body, signal })),
    put: async <T,>(path: string, body?: unknown, signal?: AbortSignal) =>
      json<T>(await raw(path, { method: 'PUT', body, signal })),
    patch: async <T,>(path: string, body?: unknown, signal?: AbortSignal) =>
      json<T>(await raw(path, { method: 'PATCH', body, signal })),
    delete: async <T,>(path: string, signal?: AbortSignal) =>
      json<T>(await raw(path, { method: 'DELETE', signal })),
    raw,
  }
}
