import {
  createContext,
  useContext,
  useMemo,
  type CSSProperties,
  type ReactNode,
} from "react";
import { resolveBrandingTokens, type Branding } from "./branding-runtime.js";
import type { Theme } from "./theme-types";

const BrandingStyleContext = createContext<CSSProperties>({});
/** Portals remain in their originating presentation scope rather than inheriting body defaults. */
export function useBrandingStyle() {
  return useContext(BrandingStyleContext);
}
export function BrandingScope({
  value,
  theme,
  children,
  className,
}: {
  value: Branding;
  theme: Theme;
  children: ReactNode;
  className?: string;
}) {
  const style = useMemo(
    () =>
      ({
        ...resolveBrandingTokens(value, theme),
        colorScheme: theme === "light" ? "light" : "dark",
        color: "var(--color-text-primary)",
        fontFamily: "var(--base-font-sans)",
        fontSize: "var(--base-font-body)",
        lineHeight: "var(--base-line-body)",
      }) as CSSProperties,
    [value, theme],
  );
  return (
    <BrandingStyleContext.Provider value={style}>
      <div
        data-theme={theme}
        data-base-branding-scope
        className={className}
        style={style}
      >
        {children}
      </div>
    </BrandingStyleContext.Provider>
  );
}
