// Generated from checked JavaScript/JSDoc by runtime-declarations.mjs.
/** @template T @param { {design:{marks:{common:T,light:T|null,dark:T|null} }} } document @param {string} theme @returns {T} */
export function effectiveMark<T>(document: {
    design: {
        marks: {
            common: T;
            light: T | null;
            dark: T | null;
        };
    };
}, theme: string): T;
/** @param {string} value @returns {string[]} */
export function graphemes(value: string): string[];
/** @param { {letters:string,count:number} } mark @returns {boolean} */
export function validMonogram(mark: {
    letters: string;
    count: number;
}): boolean;
/** @param { {product_short_name:string} } document @param { {kind:string,letters:string,count:number} } mark @returns {string[]} */
export function markLetters(document: {
    product_short_name: string;
}, mark: {
    kind: string;
    letters: string;
    count: number;
}): string[];
/** @param { {count:number} } mark @param {boolean} compact @param {boolean} failed @returns {number} */
export function markCount(mark: {
    count: number;
}, compact: boolean, failed: boolean): number;
/** @param {number} count @param {number} size @returns {number} */
export function markFontSize(count: number, size: number): number;
/** @param {number} index @param {number} size */
export function fourLetterOffset(index: number, size: number): {
    x: number;
    y: number;
};
export function brandingFavicon(brand: any, theme: any): Promise<string>;
/** Render only validated mark fields; SVG nodes come from the pinned icon table. */
export function paintBrandingMark(element: any, branding: any, theme: any): void;
