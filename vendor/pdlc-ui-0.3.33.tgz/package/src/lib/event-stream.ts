// Fleet SSE connection plumbing for React frontends.
//
// The legacy EventSource transport remains for public streams. Authenticated
// streams use fetch so bearer credentials never enter URLs or access logs.
//
// Service-specific concerns (event payloads, cache invalidation) stay with
// the consumer:
//
//   useEffect(() => connectAuthenticatedEventStream({
//     url: '/api/v1/events', token,
//     eventTypes: ['tracker'],
//     onEvent: (type, data) => { ... },
//   }), [token])

export interface EventStreamOptions {
  /** Stream URL; credentials are supplied separately for protected streams. */
  url: string
  /** SSE event names to subscribe to (the server's `event:` fields). */
  eventTypes: string[]
  /** Called for every matching event with its parsed JSON data. */
  onEvent: (eventType: string, data: unknown) => void
  /** Called when the stream (re)opens; optional. */
  onOpen?: () => void
  /** Initial reconnect delay; doubles up to maxDelay. Default 1000ms. */
  initialDelayMs?: number
  /** Backoff ceiling. Default 15000ms. */
  maxDelayMs?: number
}

/**
 * Opens a resilient SSE connection. Returns a disposer that stops all
 * reconnection attempts.
 */
export function connectEventStream({
  url,
  eventTypes,
  onEvent,
  onOpen,
  initialDelayMs = 1000,
  maxDelayMs = 15_000,
}: EventStreamOptions): () => void {
  let es: EventSource | null = null
  let retryDelay = initialDelayMs
  let closed = false
  let timer: ReturnType<typeof setTimeout> | undefined

  const handle = (event: MessageEvent) => {
    // A healthy stream resets the reconnect backoff.
    retryDelay = initialDelayMs
    let data: unknown
    try {
      data = JSON.parse(event.data as string)
    } catch {
      return
    }
    onEvent(event.type, data)
  }

  const connect = () => {
    if (closed) return
    es = new EventSource(url)

    es.onopen = () => {
      retryDelay = initialDelayMs
      onOpen?.()
    }
    for (const type of eventTypes) {
      es.addEventListener(type, handle as EventListener)
    }
    es.onerror = () => {
      // Reconnect manually with exponential backoff: EventSource's built-in
      // retry has no delay and hammers the rate limiter when the stream is
      // refused with 429, starving every other request from the same IP.
      es?.close()
      if (closed) return
      timer = setTimeout(connect, retryDelay)
      retryDelay = Math.min(retryDelay * 2, maxDelayMs)
    }
  }

  connect()

  return () => {
    closed = true
    if (timer) clearTimeout(timer)
    es?.close()
  }
}

export function connectAuthenticatedEventStream({
  url,
  token,
  eventTypes,
  onEvent,
  onOpen,
  initialDelayMs = 1000,
  maxDelayMs = 15_000,
  lastEventId,
  onCursor,
}: EventStreamOptions & { token: string; lastEventId?: string; onCursor?: (id: string) => void }): () => void {
  let closed = false
  let cursor = lastEventId
  let controller: AbortController | undefined
  let timer: ReturnType<typeof setTimeout> | undefined
  let delay = initialDelayMs

  const connect = async () => {
    if (closed) return
    controller = new AbortController()
    try {
      const response = await fetch(url, {
        headers: { Authorization: `Bearer ${token}`, Accept: 'text/event-stream', ...(cursor ? { 'Last-Event-ID': cursor } : {}) },
        signal: controller.signal,
      })
      if (response.status === 401 || response.status === 403) return
      if (!response.ok || !response.body) throw new Error(`SSE HTTP ${response.status}`)
      delay = initialDelayMs
      onOpen?.()
      const reader = response.body.getReader()
      const decoder = new TextDecoder()
      let buffer = ''
      let eventName = 'message'
      let data: string[] = []
      let eventId: string | undefined
      while (!closed) {
        const chunk = await reader.read()
        if (chunk.done) break
        buffer += decoder.decode(chunk.value, { stream: true }).replace(/\r\n/g, '\n')
        let newline: number
        while ((newline = buffer.indexOf('\n')) >= 0) {
          const line = buffer.slice(0, newline).replace(/\r$/, '')
          buffer = buffer.slice(newline + 1)
          if (line === '') {
            if (data.length && eventTypes.includes(eventName)) {
              try {
                onEvent(eventName, JSON.parse(data.join('\n')))
                if (eventId !== undefined) { cursor = eventId; onCursor?.(eventId) }
              } catch { /* Ignore malformed events without advancing the replay cursor. */ }
            }
            eventName = 'message'
            data = []
            eventId = undefined
          } else if (line.startsWith('event:')) {
            eventName = line.slice(6).trimStart()
          } else if (line.startsWith('data:')) {
            data.push(line.slice(5).replace(/^ /, ''))
          } else if (line.startsWith('id:') && !line.includes('\0')) {
            eventId = line.slice(3).replace(/^ /, '')
          }
        }
      }
    } catch (error) {
      if (closed || (error instanceof DOMException && error.name === 'AbortError')) return
    }
    if (!closed) {
      timer = setTimeout(() => void connect(), delay)
      delay = Math.min(delay * 2, maxDelayMs)
    }
  }

  void connect()
  return () => {
    closed = true
    if (timer) clearTimeout(timer)
    controller?.abort()
  }
}
