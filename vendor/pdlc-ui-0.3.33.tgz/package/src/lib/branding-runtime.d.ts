// Generated from checked JavaScript/JSDoc by runtime-declarations.mjs.
/** The same URL boundary is used by wire readers and the interactive editor. */
export function validBrandUrl(value: any): boolean;
/** Reject unsupported design versions instead of silently dropping their settings. */
export function normalizeBranding(payload: any): Branding;
/** Pure presentation compiler shared by React, SSR, static pages and previews. */
export function resolveBrandingTokens(branding: any, theme?: string): {
    [k: string]: any;
};
/**
 * One document-scoped reader. Caches are tied to the explicit URL and origin;
 * disposal invalidates old responses and restores only properties this reader owned.
 * @param { {root: HTMLElement, configUrl: string|null, defaults?: Branding, fetcher?: typeof fetch, storage?: Storage|null, onChange?: (state: {branding: Branding, revision: number|null, source: 'runtime'|'cache'|'defaults'})=>void, intervalMs?: number, getAccessToken?: ()=>string|null|undefined} } options
 */
export function createBrandingRuntime(options: {
    root: HTMLElement;
    configUrl: string | null;
    defaults?: Branding;
    fetcher?: typeof fetch;
    storage?: Storage | null;
    onChange?: (state: {
        branding: Branding;
        revision: number | null;
        source: "runtime" | "cache" | "defaults";
    }) => void;
    intervalMs?: number;
    getAccessToken?: () => string | null | undefined;
}): {
    refresh: () => Promise<void>;
    applyPublished(payload: any, validator: any): boolean;
    dispose(): void;
};
export namespace brandingPresets {
    let version: number[];
    let font_preset: string[];
    let type_scale: string[];
    let density: string[];
    let radius: string[];
}
/** @type {Branding} */
export const defaultBranding: Branding;
/** @type {BrandingDesign} */
export const defaultDesign: BrandingDesign;
export type BrandingDesign = {
    version: 1;
    font_preset: "system" | "inter" | "noto-sans";
    type_scale: "standard" | "large";
    density: "compact" | "standard" | "comfortable";
    radius: "square" | "standard" | "rounded";
    colors?: Record<string, {
        primary: string;
        accent: string;
    }>;
    radii?: Record<"control" | "menu" | "dialog" | "card" | "mark", number>;
    marks?: Record<string, any>;
    favicon?: any;
    documentation_url?: string;
    initial_theme?: "dark" | "gray" | "light";
};
export type Branding = {
    product_name: string;
    product_short_name: string;
    logo_url: string | null;
    favicon_url: string | null;
    support_url: string | null;
    primary_color: string;
    accent_color: string;
    surface_color: string | null;
    design?: BrandingDesign | null;
};
export type BrandingDocument = {
    revision: number;
    updated_at: string;
    branding: Branding;
};
