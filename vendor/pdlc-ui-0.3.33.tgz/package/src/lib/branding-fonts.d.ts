// Generated from checked JavaScript/JSDoc by runtime-declarations.mjs.
/** The document owns the font, including marks rendered outside its token scope.
 * @param {'system'|'inter'|'noto-sans'} [preset]
 * @returns {string}
 */
export function brandingFontFamily(preset?: "system" | "inter" | "noto-sans"): string;
