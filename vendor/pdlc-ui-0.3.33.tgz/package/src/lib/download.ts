/** Initiate a browser download of already prepared data; fetching and naming belong to the caller. */
export function downloadBlob(blob: Blob, filename: string): void {
  const anchor = document.createElement("a");
  const href = URL.createObjectURL(blob);
  const revoke = URL.revokeObjectURL.bind(URL);
  try {
    anchor.href = href;
    anchor.download = filename;
    anchor.hidden = true;
    document.body.append(anchor);
    anchor.click();
  } finally {
    anchor.remove();
    // Let the browser consume the link before releasing its object URL.
    window.setTimeout(() => revoke(href), 0);
  }
}
