import { useCallback, useEffect, useLayoutEffect, useRef, useState, type ReactNode } from 'react'
import { createBrowserRouter, createMemoryRouter, useLocation, useRouteError, type RouteObject } from 'react-router'
import { connectPlatformProduct, getPlatformProduct } from './bridge.js'
export * from './bridge.js'

import { getPlatformQueryClient } from './query-client'
export { setPlatformQueryClient } from './query-client'
export type { PlatformQueryClient } from './query-client'
export { PlatformQuerySession, platformQueryDefaults } from './query-session'
export type { PlatformQueryScope, PlatformQuerySessionProps } from './query-session'

let privateGeneration = 0
/** Retire this product's private query cache and any pending results. */
export function clearPlatformPrivateQueries() { privateGeneration++; getPlatformQueryClient()?.clear?.() }
/** Capture before dispatch; check again after every asynchronous response/body read. */
export function capturePlatformPrivateState(): () => boolean {
  const expected = privateGeneration
  return () => expected === privateGeneration
}
/** Keep streaming/openapi-fetch bodies bound to the request's original private state. */
export function guardPlatformPrivateResponse(response: Response, current: () => boolean): Response {
  const changed = () => Object.assign(new Error('Контекст доступа изменился; данные нужно получить заново'), {status:403,code:'AUTH_CONTEXT_CHANGED'})
  if (!current()) throw changed()
  if (!response.body) return response
  const reader = response.body.getReader()
  const body = new ReadableStream<Uint8Array>({
    async pull(controller) {
      try {
        if (!current()) throw changed()
        const next = await reader.read()
        if (!current()) throw changed()
        if (next.done) controller.close()
        else controller.enqueue(next.value)
      } catch (error) {
        controller.error(error)
        void reader.cancel().catch(() => undefined)
      }
    },
    cancel: reason => reader.cancel(reason),
  })
  return new Response(body, {status:response.status,statusText:response.statusText,headers:response.headers})
}

/** Product-owned initial data outside React Query participates in the same gate. */
export function usePlatformReadiness({ pending, error = null }: { pending: boolean; error?: string | null }) {
  const value = useRef({ ready: !pending, error })
  const unregister = useRef<(() => void) | undefined>(undefined)
  useLayoutEffect(() => { unregister.current = getPlatformProduct()?.addReadinessSource(() => value.current) }, [])
  // Retain the blocker through layout cleanup: newly enabled query observers
  // subscribe during the following passive effects of the same React commit.
  useEffect(() => () => { unregister.current?.(); unregister.current = undefined }, [])
  useLayoutEffect(() => { value.current = { ready: !pending, error }; getPlatformProduct()?.refreshReadiness() }, [pending, error])
}

export function usePlatformLeaveGuard(when: boolean) {
  const [blocked, setBlocked] = useState(false)
  const dirty = useRef(when)
  useLayoutEffect(() => { dirty.current = when }, [when])
  const response = useRef<((allowed: boolean) => void) | null>(null)
  const finish = useCallback((allowed: boolean) => {
    response.current?.(allowed); response.current = null; setBlocked(false)
  }, [])
  useEffect(() => {
    const unregister = getPlatformProduct()?.addLeaveGuard(() => {
      if (!dirty.current) return true
      response.current?.(false)
      return new Promise<boolean>(resolve => { response.current = resolve; setBlocked(true) })
    }, () => finish(false))
    return () => { unregister?.(); response.current?.(false); response.current = null }
  }, [finish])
  useEffect(() => { if (!when && blocked) queueMicrotask(() => finish(true)) }, [when, blocked, finish])
  return { blocked, confirm: () => finish(true), cancel: () => finish(false) }
}

export function createProductRouter(routes: RouteObject[], options: { serviceKey: string; portalOrigin?: string; basename?: string }) {
  const client = connectPlatformProduct(options)
  const routeOptions = routes.map(route => ({ ...route, errorElement: route.errorElement ?? <PlatformRouteError /> }))
  const router = client
    ? createMemoryRouter(routeOptions, { basename: options.basename, initialEntries: [window.location.pathname + window.location.search + window.location.hash] })
    : createBrowserRouter(routes, { basename: options.basename })
  if (client) {
    const technicalPaths = ['/login', '/register', '/logout', '/sso/callback'].map(path => (router.basename ?? '/').replace(/\/+$/, '') + path)
    client.setNavigator((url, navigationOptions) => {
      const parsed = new URL(url, window.location.origin)
      client.requestNavigation(parsed.href, navigationOptions)
    })
    let previous = window.location.pathname + window.location.search + window.location.hash
    router.subscribe(state => {
      const current = state.location.pathname + state.location.search + state.location.hash
      if (state.navigation.state === 'idle' && current !== previous && !technicalPaths.includes(state.location.pathname)) {
        previous = current
        client.reportRoute(current, state.historyAction === 'REPLACE')
      }
    })
  }
  return router
}

function PlatformRouteError() {
  const error = useRouteError()
  useEffect(() => {
    getPlatformProduct()?.readiness({ ready: false, error: 'Не удалось отобразить страницу приложения.' })
  }, [error])
  return <p role="alert">Не удалось отобразить страницу приложения.</p>
}

/** Mounted inside the route's Suspense boundary, after the product auth guard. */
export function PlatformRoute({ children }: { children: ReactNode }) {
  const location = useLocation()
  useEffect(() => {
    const client = getPlatformProduct()
    if (!client) return
    let mounted = true
    const check = () => {
      if (!mounted) return { ready: false, error: null }
      if (['/login', '/register', '/logout', '/sso/callback'].includes(location.pathname)) return { ready: false, error: null }
      const active = getPlatformQueryClient()?.getQueryCache().getAll().filter(query => query.isActive()) ?? []
      if (active.some(query => query.state.status === 'error')) return { ready: false, error: 'Не удалось загрузить данные приложения.' }
      return { ready: !active.some(query => query.state.status === 'pending') && !getPlatformQueryClient()?.isFetching(), error: null }
    }
    const update = () => {
      // Child effects start their queries before this microtask reads the cache.
      queueMicrotask(() => { if (mounted) client.readiness(check(), check) })
    }
    const unsubscribe = getPlatformQueryClient()?.getQueryCache().subscribe(update)
    update()
    return () => { mounted = false; unsubscribe?.(); client.readiness({ ready: false, error: null }) }
  }, [location.key, location.pathname])
  return <>{children}</>
}
