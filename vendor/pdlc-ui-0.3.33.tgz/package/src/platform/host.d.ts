// Generated from checked JavaScript/JSDoc by runtime-declarations.mjs.
/** @param {import("./contracts").PlatformConfig} config */
export function validatePlatformConfig(config: import("./contracts").PlatformConfig): import("./contracts").PlatformConfig;
export class PlatformHost {
    /** @param {{root: HTMLElement, config: import("./contracts").PlatformConfig, window?: Window, onError?: (message: string | null) => void, timeoutMs?: number}} options */
    constructor({ root, config, window: target, onError, timeoutMs }: {
        root: HTMLElement;
        config: import("./contracts").PlatformConfig;
        window?: Window;
        onError?: (message: string | null) => void;
        timeoutMs?: number;
    });
    root: HTMLElement;
    window: Window;
    config: import("./contracts").PlatformConfig;
    onError: (message: string | null) => void;
    timeoutMs: number;
    active: any;
    candidate: any;
    retiring: any;
    index: number;
    popAction: {
        kind: string;
        index: any;
        run: () => void;
    } | {
        kind: string;
        index: number;
        run: () => void;
    };
    receive: (event: any) => void;
    pop: () => void;
    resolve(value: any): {
        service: import("./contracts").PlatformService;
        route: string;
    };
    publicUrl({ service, route }: {
        service: any;
        route: any;
    }): any;
    start(): void;
    navigate(value: any, options?: {}): void;
    prepare(target: any, options: any): void;
    afterRetire: {
        target: any;
        options: any;
    };
    lastTarget: any;
    loginUrl: string;
    cancel(): void;
    send(attempt: any, type: any, payload?: {}): void;
    message(event: any): void;
    retry(): void;
    setBranding(branding: any): void;
    activate(attempt: any): void;
    history(attempt: any, replace: any): void;
    commit(attempt: any): void;
    retire(attempt: any): void;
    finishRetire(attempt: any): void;
    fail(attempt: any, message: any): void;
    popstate(): void;
    dispose(): void;
}
export type { PlatformConfig } from './contracts';
