/** Observe the host's pending target; this indicator never controls readiness. */
/** @param {HTMLElement} root @param {HTMLElement} indicator @param {{delayMs?: number}} [options] */
export function connectLoadingIndicator(root, indicator, { delayMs = 180 } = {}) {
  let timer
  let pending = null
  const update = () => {
    const { platformActive: active, platformPreparingKey: target } = root.dataset
    // SSR routes and session rechecks prepare a new document of the same service.
    // Only a different service gets the switch animation; startup keeps its text.
    const label = active && target && active !== target ? root.dataset.platformPreparing || null : null
    if (label === pending) return
    pending = label
    clearTimeout(timer)
    indicator.hidden = true
    if (!label) return
    indicator.querySelector('[data-loading-label]').textContent = `Открываем ${label}`
    timer = setTimeout(() => { indicator.hidden = false }, delayMs)
  }
  const observer = new MutationObserver(update)
  observer.observe(root, { attributes: true, attributeFilter: ['data-platform-preparing', 'data-platform-preparing-key', 'data-platform-active'] })
  update()
  return () => { observer.disconnect(); clearTimeout(timer); indicator.hidden = true }
}
