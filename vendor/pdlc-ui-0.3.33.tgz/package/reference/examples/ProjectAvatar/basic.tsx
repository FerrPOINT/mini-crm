import * as UI from "@pdlc/ui/ui";
import { type ComponentProps } from "react";

export default function Example() {
  const args = { projectKey: "BASE", size: "md" } satisfies ComponentProps<
    typeof UI.ProjectAvatar
  >;
  const render = (args: ComponentProps<typeof UI.ProjectAvatar>) => (
    <div className="flex flex-wrap gap-2">
      <UI.ProjectAvatar {...args} />
      <span>Платформа · {args.projectKey}</span>
    </div>
  );
  return render(args);
}
