import { useState } from "react";
import { Badge, BadgeInput } from "@pdlc/ui/ui";
export default function Example() {
  const [value, setValue] = useState("Навык");
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: 6,
        flexWrap: "wrap",
      }}
    >
      <Badge tone="info">Метка</Badge>
      <BadgeInput
        aria-label="Название метки"
        tone="info"
        value={value}
        onChange={(event) => setValue(event.target.value)}
      />
    </div>
  );
}
