import { useState } from "react";
import {
  Button,
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
  Select,
  MultiSelect,
} from "@pdlc/ui/ui";
export default function Example() {
  const [open, setOpen] = useState(false);
  const options = [
    { value: "", label: "Все" },
    { value: "review", label: "На проверке" },
    { value: "blocked", label: "Недоступный вариант", disabled: true },
  ];
  return (
    <>
      <Button onClick={() => setOpen(true)}>Открыть форму выбора</Button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogTitle>Выбор внутри диалога</DialogTitle>
          <DialogDescription>
            Escape закрывает сначала список, затем диалог. Tab переходит к
            следующему полю.
          </DialogDescription>
          <form
            className="space-y-4"
            onSubmit={(event) => event.preventDefault()}
          >
            <label htmlFor="dialog-status">Состояние</label>
            <Select
              id="dialog-status"
              options={options}
              name="status"
              defaultValue=""
            />
            <label htmlFor="dialog-tags">Несколько состояний</label>
            <MultiSelect
              id="dialog-tags"
              options={options.filter((option) => option.value)}
              name="tags"
              defaultValue={["review"]}
            />
            <Button type="reset" variant="outline">
              Сбросить форму
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
}
