import * as UI from "@pdlc/ui/ui";
import { type ComponentProps, useEffect, useRef, useState } from "react";

function useExampleValue<T>(value: T) {
  const [current, setCurrent] = useState(value);
  useEffect(() => setCurrent(value), [value]);
  return [current, setCurrent] as const;
}

export function DrawerDemo(args: ComponentProps<typeof UI.NavigationDrawer>) {
  const [open, setOpen] = useExampleValue(args.open);
  const desktopFocusRef = useRef<HTMLButtonElement>(null);
  return (
    <div className="space-y-4">
      <UI.Button
        ref={desktopFocusRef}
        variant="outline"
        className="hidden md:inline-flex"
      >
        Навигация desktop
      </UI.Button>
      <UI.NavigationDrawer
        {...args}
        desktopFocusRef={desktopFocusRef}
        open={open}
        onOpenChange={(next) => {
          setOpen(next);
          args.onOpenChange(next);
        }}
      />
      <p className="text-sm text-text-muted">
        Мобильный drawer виден при ширине меньше 768 px.
      </p>
    </div>
  );
}

export default function Example() {
  const args = {
    title: "Навигация",
    open: false,
    onOpenChange: () => {},
    desktopFocusRef: { current: null },
    children: <UI.SidebarItem>Обзор</UI.SidebarItem>,
  } satisfies ComponentProps<typeof UI.NavigationDrawer>;
  const render = (args: ComponentProps<typeof UI.NavigationDrawer>) => (
    <DrawerDemo {...args} />
  );
  return render(args);
}
