import { BrandingScope, defaultDesign } from "@pdlc/ui/branding";
import { defaultBranding } from "@pdlc/ui/lib";
import { Button, Card, CardContent } from "@pdlc/ui/ui";
export default function Example() {
  return (
    <BrandingScope
      theme="dark"
      value={{
        ...defaultBranding,
        primary_color: "#bb2255",
        design: {
          ...defaultDesign,
          radius: "rounded",
          font_preset: "inter",
          type_scale: "large",
        },
      }}
    >
      <Card>
        <CardContent>
          <p>Изолированный брендинг</p>
          <Button>Настоящий Button</Button>
        </CardContent>
      </Card>
    </BrandingScope>
  );
}
