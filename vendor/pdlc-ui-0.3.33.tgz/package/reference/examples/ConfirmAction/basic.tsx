import { useState } from "react";
import { ConfirmAction, type ConfirmActionProps } from "@pdlc/ui/ui";

export default function Example({
  children = "Применить изменение",
  title = "Применить изменение?",
  description = "Действие выполняется только в памяти этого примера.",
  onConfirm,
  ...props
}: Partial<ConfirmActionProps>) {
  const [calls, setCalls] = useState(0);
  return (
    <div className="min-w-0 space-y-4">
      <ConfirmAction
        {...props}
        title={title}
        description={description}
        onConfirm={() => {
          setCalls((count) => count + 1);
          return onConfirm?.();
        }}
      >
        {children}
      </ConfirmAction>
      <p role="status">Подтверждений в примере: {calls}</p>
    </div>
  );
}
