import { useEffect, useRef, useState } from "react";
import { ConfirmAction } from "@pdlc/ui/ui";

/** Synthetic finite task; reset/unmount cancels the timer without a network request. */
export default function AsyncExample() {
  const task = useRef<{
    timer: ReturnType<typeof setTimeout>;
    settle: () => void;
  } | null>(null);
  const [saved, setSaved] = useState(0);
  useEffect(
    () => () => {
      if (task.current) {
        clearTimeout(task.current.timer);
        task.current.settle();
      }
    },
    [],
  );
  return (
    <div className="min-w-0 space-y-4">
      <ConfirmAction
        title="Сохранить локальный пример?"
        description="После подтверждения выполняется короткая задача в памяти. Пока она не закончилась, повтор и отмена недоступны."
        pendingLabel="Сохраняем…"
        onConfirm={() =>
          new Promise<void>((resolve) => {
            const timer = setTimeout(() => {
              task.current = null;
              setSaved((count) => count + 1);
              resolve();
            }, 2000);
            task.current = { timer, settle: resolve };
          })
        }
      >
        Сохранить пример
      </ConfirmAction>
      <p role="status">Завершено: {saved}</p>
    </div>
  );
}
