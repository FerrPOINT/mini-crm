import { useState } from "react";
import { FileText, Folder } from "lucide-react";
import {
  Notice,
  ProjectNavigationGroup,
  SidebarItem,
  SidebarList,
} from "@pdlc/ui/ui";

export default function SidebarExample({
  long = false,
  compact = false,
  tree = false,
}: {
  long?: boolean;
  compact?: boolean;
  tree?: boolean;
}) {
  const [open, setOpen] = useState(true);
  const [visits, setVisits] = useState(0);
  const name = long ? "Длинное название проекта ".repeat(6) : "Проект";
  const link = (
    <SidebarItem asChild active compact={compact}>
      <a
        href="#document"
        aria-label="Документ"
        onClick={(event) => {
          event.preventDefault();
          setVisits((count) => count + 1);
        }}
      >
        <FileText aria-hidden />
        {!compact && <span>Документ</span>}
      </a>
    </SidebarItem>
  );
  return (
    <>
      <SidebarList asChild separated>
        <nav aria-label="Синтетическая навигация">
          <ProjectNavigationGroup
            name={name}
            projectKey="EXAMPLE"
            open={open}
            compact={compact}
            onToggle={() => setOpen(!open)}
          >
            {tree ? (
              <SidebarList asChild>
                <ul>
                  <SidebarList asChild>
                    <li>
                      <SidebarItem disabled>
                        <Folder aria-hidden />
                        Недоступная папка
                      </SidebarItem>
                      <SidebarList asChild nested>
                        <ul>
                          <li>{link}</li>
                        </ul>
                      </SidebarList>
                    </li>
                  </SidebarList>
                </ul>
              </SidebarList>
            ) : (
              link
            )}
          </ProjectNavigationGroup>
        </nav>
      </SidebarList>
      <Notice appearance="inline" tone="neutral" role="status">
        Локальных переходов: {visits}. Каталог, URL и права задаёт продукт.
      </Notice>
    </>
  );
}
