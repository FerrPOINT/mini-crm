import { useState } from "react";
import { FormField, SearchInput } from "@pdlc/ui/ui";

export default function SearchExample() {
  const [query, setQuery] = useState("");
  return (
    <FormField
      id="resource-query"
      label="Поиск ресурсов"
      hint="Только локальный ввод. Запросы не выполняются."
    >
      {(attrs) => (
        <SearchInput
          {...attrs}
          name="q"
          value={query}
          placeholder="Название или ключ"
          onChange={(event) => setQuery(event.target.value)}
          clear={
            query
              ? { label: "Очистить запрос", onClear: () => setQuery("") }
              : undefined
          }
        />
      )}
    </FormField>
  );
}
