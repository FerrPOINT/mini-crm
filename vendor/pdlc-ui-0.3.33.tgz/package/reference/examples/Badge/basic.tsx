import * as UI from "@pdlc/ui/ui";
import { type ComponentProps } from "react";

export default function Example() {
  const args = {
    children: "Готов",
    tone: "success",
    appearance: "badge",
  } satisfies ComponentProps<typeof UI.Badge>;
  const render = (args: ComponentProps<typeof UI.Badge>) => (
    <UI.Badge {...args} />
  );
  return render(args);
}
