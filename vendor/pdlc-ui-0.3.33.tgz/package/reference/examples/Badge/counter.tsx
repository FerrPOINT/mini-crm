import { Badge } from "@pdlc/ui/ui";

export default function Example() {
  return (
    <div className="flex flex-wrap items-center gap-3">
      {[1, 12, 1200].map((count) => (
        <Badge
          key={count}
          appearance="counter"
          tone="danger"
          aria-label={`Непрочитано: ${count}`}
        >
          {count}
        </Badge>
      ))}
      <span className="inline-flex items-center gap-2">
        Все записи <Badge appearance="counter">0</Badge>
      </span>
    </div>
  );
}
