import { useMemo, useState } from "react";
import { BrandingScope, defaultDesign } from "@pdlc/ui/branding";
import { defaultBranding, useTheme, type PlatformBranding } from "@pdlc/ui/lib";
import { Badge, Button } from "@pdlc/ui/ui";

export default function Example() {
  const [large, setLarge] = useState(false);
  const [actions, setActions] = useState(0);
  const { theme } = useTheme();
  const branding = useMemo<PlatformBranding>(
    () => ({
      ...defaultBranding,
      primary_color: "#bb2255",
      design: {
        ...defaultDesign,
        font_preset: large ? "inter" : "system",
        type_scale: large ? "large" : "standard",
        radius: large ? "rounded" : "square",
        density: large ? "comfortable" : "compact",
      },
    }),
    [large],
  );
  return (
    <div className="space-y-4">
      <Button
        type="button"
        variant="outline"
        aria-pressed={large}
        onClick={() => setLarge((value) => !value)}
      >
        Крупный брендинг
      </Button>
      <BrandingScope theme={theme} value={branding}>
        <div className="flex flex-wrap items-center gap-3">
          <Badge subjectColor="#ef4444">
            Цвет записи сохраняется
            <Button
              type="button"
              variant="subject"
              size="icon"
              aria-label="Действие цветной метки"
              onClick={() => setActions((value) => value + 1)}
            >
              +
            </Button>
          </Badge>
          <Button
            type="button"
            variant="subject"
            subjectColor="#1e293b"
            onClick={() => setActions((value) => value + 1)}
          >
            Предметное действие
          </Button>
          <Button
            type="button"
            onClick={() => setActions((value) => value + 1)}
          >
            Брендовое действие
          </Button>
        </div>
      </BrandingScope>
      <p>
        Меняются шрифт, размер текста, плотность и радиусы. Цвет данных
        сохраняет собственный смысл.
      </p>
      <p role="status">Синтетических действий: {actions}</p>
    </div>
  );
}
