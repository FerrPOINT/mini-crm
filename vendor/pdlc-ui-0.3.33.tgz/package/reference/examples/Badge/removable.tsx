import { useEffect, useRef, useState } from "react";
import { Badge, BadgeButton, Button } from "@pdlc/ui/ui";

export default function Example() {
  const [selected, setSelected] = useState(true);
  const actionRef = useRef<HTMLButtonElement>(null);
  const interacted = useRef(false);
  useEffect(() => {
    // The composition owns the logical focus target after removing its action.
    if (interacted.current) actionRef.current?.focus();
  }, [selected]);
  const change = (value: boolean) => {
    interacted.current = true;
    setSelected(value);
  };
  return selected ? (
    <Badge tone="info">
      Выбранное значение
      <BadgeButton
        appearance="inline"
        tone="info"
        aria-label="Убрать выбранное значение"
        ref={actionRef}
        onClick={() => change(false)}
      >
        ×
      </BadgeButton>
    </Badge>
  ) : (
    <Button
      type="button"
      variant="outline"
      ref={actionRef}
      onClick={() => change(true)}
    >
      Восстановить значение
    </Button>
  );
}
