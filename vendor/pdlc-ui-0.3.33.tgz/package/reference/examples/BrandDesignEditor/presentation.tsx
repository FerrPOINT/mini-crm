import {
  BrandingPresentationProvider,
  createBrandDocument,
} from "@pdlc/ui/branding";
import { PlatformMark } from "@pdlc/ui/ui";

export default function PresentationExample() {
  const document = createBrandDocument();
  return (
    <BrandingPresentationProvider document={document} theme="dark">
      <PlatformMark size="shell" />
    </BrandingPresentationProvider>
  );
}
