import { BrandDesignPreview, createBrandDocument } from "@pdlc/ui/branding";

export default function PreviewExample() {
  const document = createBrandDocument();
  return <BrandDesignPreview document={document} theme="dark" />;
}
