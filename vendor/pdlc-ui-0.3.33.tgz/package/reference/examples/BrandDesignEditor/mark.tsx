import { BrandingMark, createBrandDocument } from "@pdlc/ui/branding";

export default function MarkExample() {
  const document = createBrandDocument();
  return <BrandingMark document={document} theme="dark" size="shell" />;
}
