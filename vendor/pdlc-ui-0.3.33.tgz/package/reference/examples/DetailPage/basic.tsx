import * as UI from "@pdlc/ui/ui";
import { type ComponentProps } from "react";

export default function Example() {
  const args = {
    title: "Проекты",
    context: "Демонстрационный каталог команды",
    actions: <UI.Button>Создать проект</UI.Button>,
    children: (
      <UI.ResourceList>
        <UI.ResourceListRow>Платформа</UI.ResourceListRow>
        <UI.ResourceListRow>Документация</UI.ResourceListRow>
      </UI.ResourceList>
    ),
    aside: (
      <dl>
        <UI.DescriptionItem label="Владелец">
          Команда платформы
        </UI.DescriptionItem>
      </dl>
    ),
  } satisfies ComponentProps<typeof UI.DetailPage>;
  const render = (args: ComponentProps<typeof UI.DetailPage>) => (
    <UI.DetailPage {...args} />
  );
  return render(args);
}
