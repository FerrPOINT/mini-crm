import * as UI from "@pdlc/ui/ui";
import { type ComponentProps, useEffect, useState } from "react";

function useExampleValue<T>(value: T) {
  const [current, setCurrent] = useState(value);
  useEffect(() => setCurrent(value), [value]);
  return [current, setCurrent] as const;
}

export function ControlledProjectGroup(
  args: ComponentProps<typeof UI.ProjectNavigationGroup>,
) {
  const [open, setOpen] = useExampleValue(args.open);
  return (
    <UI.ProjectNavigationGroup
      {...args}
      open={open}
      onToggle={() => {
        setOpen(!open);
        args.onToggle();
      }}
    />
  );
}

export default function Example() {
  const args = {
    name: "Платформа",
    projectKey: "BASE",
    open: true,
    onToggle: () => {},
    children: <UI.SidebarItem active>Задачи</UI.SidebarItem>,
    status: <UI.Badge tone="success">Активен</UI.Badge>,
  } satisfies ComponentProps<typeof UI.ProjectNavigationGroup>;
  const render = (args: ComponentProps<typeof UI.ProjectNavigationGroup>) => (
    <ControlledProjectGroup {...args} />
  );
  return render(args);
}
