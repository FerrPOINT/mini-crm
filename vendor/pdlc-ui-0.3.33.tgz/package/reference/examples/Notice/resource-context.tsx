import { useState } from "react";
import { Folder } from "lucide-react";
import {
  Button,
  IconMark,
  Notice,
  ResourceList,
  ResourceListRow,
} from "@pdlc/ui/ui";

export default function ResourceContextExample() {
  const [unavailable, setUnavailable] = useState(true);
  return (
    <div className="grid gap-4">
      <ResourceList variant="bordered">
        <ResourceListRow className="grid gap-2">
          <div className="flex min-w-0 items-center gap-3">
            <IconMark>
              <Folder aria-hidden="true" />
            </IconMark>
            <span className="min-w-0">
              Ресурс с длинным названием и подтверждённым исходным
              идентификатором · RESOURCE-42
            </span>
          </div>
          {unavailable && (
            <Notice role="alert" tone="danger" appearance="inline">
              Контекст ресурса недоступен. Подтверждённое название сохранено;
              переход станет доступен после проверки контекста.
            </Notice>
          )}
        </ResourceListRow>
      </ResourceList>
      <Button
        type="button"
        variant="outline"
        onClick={() => setUnavailable((value) => !value)}
      >
        {unavailable
          ? "Подтвердить контекст без сети"
          : "Показать синтетическую ошибку"}
      </Button>
    </div>
  );
}
