import type { ComponentProps } from "react";
import { Notice, Prose } from "@pdlc/ui/ui";

/** Static guidance does not announce a write result or perform a request. */
export default function SeparatedNoticeExample({
  separated = true,
}: Pick<ComponentProps<typeof Notice>, "separated"> = {}) {
  return (
    <div className="grid gap-4">
      <Prose>
        <p>Основное содержимое принадлежит приложению.</p>
      </Prose>
      <Notice appearance="inline" separated={separated} title="Следующий шаг">
        Действие станет доступно после подтверждения данных.
      </Notice>
    </div>
  );
}
