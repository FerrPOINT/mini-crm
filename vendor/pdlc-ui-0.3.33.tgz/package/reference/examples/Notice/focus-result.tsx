import { useRef, useState } from "react";
import { Button, Notice } from "@pdlc/ui/ui";

/** The consumer explicitly selects the result as its focus target; Notice never moves it. */
export default function Example() {
  const result = useRef<HTMLDivElement>(null);
  const [confirmed, setConfirmed] = useState(false);
  return (
    <div className="base-page-stack">
      <Button
        onClick={() => {
          setConfirmed(true);
          result.current?.focus();
        }}
      >
        Показать синтетический результат
      </Button>
      <Notice
        ref={result}
        role="status"
        aria-label="Результат проверки"
        tabIndex={-1}
        tone={confirmed ? "success" : "neutral"}
      >
        {confirmed
          ? "Результат подтверждён. Фокус перенёс вызывающий код."
          : "Синтетическое окружение: сеть и запись данных не используются."}
      </Notice>
    </div>
  );
}
