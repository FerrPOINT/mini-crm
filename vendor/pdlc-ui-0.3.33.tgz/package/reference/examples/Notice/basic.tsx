import { useState } from "react";
import { Button, Notice } from "@pdlc/ui/ui";

export default function Basic() {
  const [confirmed, setConfirmed] = useState(false);
  return (
    <div className="grid gap-4">
      <Notice tone="info" title="Область показателей">
        Показаны только подключённые проекты.
      </Notice>
      <Notice
        tone={confirmed ? "success" : "warning"}
        role="status"
        actions={
          !confirmed && (
            <Button variant="outline" onClick={() => setConfirmed(true)}>
              Прочитать результат
            </Button>
          )
        }
      >
        {confirmed
          ? "Синтетическое чтение подтвердило результат."
          : "Результат записи неизвестен. Перед повтором требуется чтение."}
      </Notice>
    </div>
  );
}
