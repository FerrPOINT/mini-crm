import * as UI from "@pdlc/ui/ui";
import { type ComponentProps } from "react";

export default function Example() {
  const args = {
    defaultValue: "overview",
    children: (
      <>
        <UI.TabsList aria-label="Раздел проекта">
          <UI.TabsTrigger value="overview">Обзор</UI.TabsTrigger>
          <UI.TabsTrigger value="members">Участники</UI.TabsTrigger>
          <UI.TabsTrigger value="disabled" disabled>
            Архив
          </UI.TabsTrigger>
        </UI.TabsList>
        <UI.TabsContent value="overview">
          <p>Сводка проекта</p>
        </UI.TabsContent>
        <UI.TabsContent value="members">
          <p>Команда платформы</p>
        </UI.TabsContent>
      </>
    ),
  } satisfies ComponentProps<typeof UI.Tabs>;
  const render = (args: ComponentProps<typeof UI.Tabs>) => (
    <UI.Tabs {...args} />
  );
  return render(args);
}
