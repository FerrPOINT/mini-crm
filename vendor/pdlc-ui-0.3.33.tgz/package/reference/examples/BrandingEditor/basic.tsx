import { useState } from "react";
import type { PlatformBranding } from "@pdlc/ui/lib";
import { createBrandDocument } from "@pdlc/ui/branding";
import { BrandingEditor } from "@pdlc/ui/ui";

export default function BrandingExample({
  initial = createBrandDocument(),
  disabled = false,
}: {
  initial?: PlatformBranding;
  disabled?: boolean;
}) {
  const [value, setValue] = useState(initial);
  return (
    <BrandingEditor value={value} onChange={setValue} disabled={disabled} />
  );
}
