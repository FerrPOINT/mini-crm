import { useState } from "react";
import type { PlatformBranding } from "@pdlc/ui/lib";
import { createBrandDocument } from "@pdlc/ui/branding";
import { Badge, BrandingSettings, Button, PageFrame } from "@pdlc/ui/ui";

export default function SettingsExample({
  disabled = false,
}: {
  disabled?: boolean;
}) {
  const [value, setValue] = useState<PlatformBranding>(createBrandDocument);
  return (
    <PageFrame mode="wide">
      <BrandingSettings
        disabled={disabled}
        value={value}
        onChange={setValue}
        description="Локальный предпросмотр. Изменения не публикуются."
        actions={
          disabled ? (
            <Badge>Только чтение</Badge>
          ) : (
            <Button
              variant="outline"
              onClick={() => setValue(createBrandDocument())}
            >
              Сбросить настройки
            </Button>
          )
        }
      />
    </PageFrame>
  );
}
