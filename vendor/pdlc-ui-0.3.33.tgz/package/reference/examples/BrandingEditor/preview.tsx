import { createBrandDocument } from "@pdlc/ui/branding";
import { BrandingPreview } from "@pdlc/ui/ui";

export default function PreviewExample() {
  return <BrandingPreview value={createBrandDocument()} theme="dark" />;
}
