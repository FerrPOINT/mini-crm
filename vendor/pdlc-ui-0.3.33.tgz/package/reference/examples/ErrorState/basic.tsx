import * as UI from "@pdlc/ui/ui";
import { useState } from "react";

export default function Example() {
  const [retryDisabled, setRetryDisabled] = useState(false);
  const [attempts, setAttempts] = useState(0);
  return (
    <div className="grid gap-4">
      <UI.ErrorState
        message="Не удалось загрузить проекты"
        onRetry={() => setAttempts((value) => value + 1)}
        retryDisabled={retryDisabled}
      />
      <UI.Checkbox
        checked={retryDisabled}
        onCheckedChange={(checked) => setRetryDisabled(checked === true)}
        label="Запретить повтор"
      />
      <p role="status">
        Явных попыток: {attempts}. Это синтетический пример без сети.
      </p>
    </div>
  );
}
