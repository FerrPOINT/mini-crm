import { ErrorState } from "@pdlc/ui/ui";
import { useState, type ComponentProps } from "react";

export default function Example(
  props: Partial<ComponentProps<typeof ErrorState>>,
) {
  const [attempts, setAttempts] = useState(0);
  return (
    <section aria-label="Ошибка необязательного чтения">
      <p>Основное содержимое остаётся доступным.</p>
      <ErrorState
        {...props}
        scope={props.scope ?? "local"}
        message={props.message ?? "Метаданные временно недоступны"}
        onRetry={() => setAttempts(attempts + 1)}
      />
      <output>Явных попыток: {attempts}. Сеть не используется.</output>
    </section>
  );
}
