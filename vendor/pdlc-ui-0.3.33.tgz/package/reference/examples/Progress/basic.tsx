import * as UI from "@pdlc/ui/ui";
import { type ComponentProps } from "react";

export default function Example() {
  const args = {
    value: 62,
    max: 100,
    "aria-label": "Готовность импорта",
  } satisfies ComponentProps<typeof UI.Progress>;
  const render = (args: ComponentProps<typeof UI.Progress>) => (
    <div className="space-y-4">
      <UI.Progress {...args} />
      <p>
        {args.value} из {args.max}
      </p>
    </div>
  );
  return render(args);
}
