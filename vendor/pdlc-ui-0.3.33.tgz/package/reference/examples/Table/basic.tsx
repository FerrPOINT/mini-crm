import * as UI from "@pdlc/ui/ui";
import { type ComponentProps } from "react";

export default function Example() {
  const args = {
    children: (
      <>
        <caption className="sr-only">Проекты команды</caption>
        <UI.TableHeader>
          <UI.TableRow>
            <UI.TableHead>Проект</UI.TableHead>
            <UI.TableHead>Статус</UI.TableHead>
            <UI.TableHead>Задачи</UI.TableHead>
          </UI.TableRow>
        </UI.TableHeader>
        <UI.TableBody>
          {["Платформа", "Документация"].map((name, index) => (
            <UI.TableRow key={name}>
              <UI.TableCell>{name}</UI.TableCell>
              <UI.TableCell>
                <UI.Badge tone="success">Активен</UI.Badge>
              </UI.TableCell>
              <UI.TableCell>{index + 3}</UI.TableCell>
            </UI.TableRow>
          ))}
        </UI.TableBody>
      </>
    ),
  } satisfies ComponentProps<typeof UI.Table>;
  const render = (args: ComponentProps<typeof UI.Table>) => (
    <UI.Table {...args} />
  );
  return render(args);
}
