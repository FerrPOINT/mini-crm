import type { ComponentProps } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
  TextLink,
} from "@pdlc/ui/ui";

export default function TechnicalCellsExample({
  technical = true,
  size = "sm",
}: Pick<ComponentProps<typeof TableCell>, "technical" | "size"> = {}) {
  return (
    <Table aria-label="Технические значения">
      <TableHeader>
        <TableRow>
          <TableHead>Ресурс</TableHead>
          <TableHead>Попытки</TableHead>
          <TableHead>HTTP</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        <TableRow>
          <TableCell technical={technical} size={size}>
            <TextLink href="#technical-cell">resource-73</TextLink>
          </TableCell>
          <TableCell technical={technical} size={size}>
            {0}
          </TableCell>
          <TableCell technical={technical} size={size}>
            —
          </TableCell>
        </TableRow>
        <TableRow>
          <TableCell technical id="technical-cell">
            {"resource_".repeat(18)}
          </TableCell>
          <TableCell>Обычный текст</TableCell>
          <TableCell>Неизвестно</TableCell>
        </TableRow>
      </TableBody>
    </Table>
  );
}
