import { useState } from "react";
import {
  Button,
  ResourceListDescription,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@pdlc/ui/ui";

export default function SelectedExample() {
  const [selected, setSelected] = useState("one");
  const rows = [
    { id: "one", title: "Первая запись", hasNotice: true },
    { id: "two", title: "Вторая запись", hasNotice: false },
  ];
  return (
    <div className="min-w-0 space-y-4">
      <Table aria-label="Записи пространства">
        <TableHeader>
          <TableRow>
            <TableHead>Запись</TableHead>
            <TableHead>Действие</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {rows.map((row) => (
            <TableRow key={row.id} selected={selected === row.id}>
              <TableCell>
                {row.title}
                <ResourceListDescription className="block">
                  Дополнительные сведения
                </ResourceListDescription>
                <span
                  className={row.hasNotice ? "text-danger" : "text-success"}
                >
                  {row.hasNotice ? "Есть замечание" : "Без замечаний"}
                </span>
              </TableCell>
              <TableCell>
                <Button
                  variant="ghost"
                  aria-pressed={selected === row.id}
                  onClick={() => setSelected(row.id)}
                >
                  Выбрать: {row.title}
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      <output aria-live="polite">
        Выбрана: {rows.find((row) => row.id === selected)?.title}
      </output>
    </div>
  );
}
