import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@pdlc/ui/ui";

export default function TableKeyboardFocusExample() {
  return (
    <div className="grid gap-3">
      <p>
        Tab переводит фокус на таблицу. Широкие данные прокручиваются внутри
        неё.
      </p>
      <Table
        tabIndex={0}
        aria-label="Таблица с клавиатурным фокусом"
        className="min-w-[40rem]"
      >
        <TableHeader>
          <TableRow>
            <TableHead>Ресурс</TableHead>
            <TableHead>Значение</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          <TableRow>
            <TableCell>resource/long-reference-00000000000000000001</TableCell>
            <TableCell>Подготовленное значение</TableCell>
          </TableRow>
        </TableBody>
      </Table>
    </div>
  );
}
