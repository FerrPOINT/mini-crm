import { useState } from "react";
import {
  Badge,
  Button,
  ChatComposer,
  ChatComposerActions,
  Dialog,
  DialogBody,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  PageFrame,
  PageHeader,
  PlatformHeader,
  Prose,
  ResourceListDescription,
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
  Textarea,
  Workbench,
  WorkbenchGrid,
  WorkbenchMain,
  WorkbenchAside,
  WorkbenchPanel,
  WorkbenchScroll,
  WorkbenchToolbar,
  WorkbenchAsideAction,
} from "@pdlc/ui/ui";

export default function WorkbenchExample({
  documentFlow = false,
  noAside = false,
  long = false,
  asideWidth = 300,
  mobileFlow,
  disabled = false,
}: {
  documentFlow?: boolean;
  noAside?: boolean;
  long?: boolean;
  asideWidth?: number;
  mobileFlow?: boolean;
  disabled?: boolean;
}) {
  const [tab, setTab] = useState(documentFlow ? "details" : "history");
  const [draft, setDraft] = useState("");
  const [sent, setSent] = useState(0);
  const context = (
    <Prose>
      <h2>Контекст</h2>
      <p>
        {long
          ? "Длинное_содержимое_".repeat(40)
          : "Синтетические сведения владельца экрана."}
      </p>
      <ul>
        {Array.from({ length: 16 }, (_, n) => (
          <li key={n}>Сведение {n + 1}</li>
        ))}
      </ul>
    </Prose>
  );
  return (
    <>
      <PlatformHeader
        currentServiceKey="components-dictionary"
        leading={<Badge>PDLC</Badge>}
        serviceSwitcher={false}
      />
      <PageFrame>
        <Dialog>
          <Workbench
            mobileFlow={mobileFlow ?? tab === "details"}
            aria-label="Рабочая область"
          >
            <PageHeader
              title="Рабочая область"
              context="Локальная композиция без API"
              actions={
                !noAside && (
                  <DialogTrigger asChild>
                    <WorkbenchAsideAction
                      variant="outline"
                      type="button"
                      disabled={disabled}
                    >
                      Контекст
                    </WorkbenchAsideAction>
                  </DialogTrigger>
                )
              }
            />
            <WorkbenchToolbar>
              <Badge tone="info">Синтетический источник</Badge>
              <ResourceListDescription>
                Отправлено локально: {sent}
              </ResourceListDescription>
            </WorkbenchToolbar>
            <WorkbenchGrid asideWidth={asideWidth}>
              <WorkbenchMain aria-label="Основное содержимое">
                <WorkbenchPanel asChild>
                  <Tabs value={tab} onValueChange={setTab}>
                    <TabsList
                      appearance="underline"
                      aria-label="Режим рабочей области"
                    >
                      <TabsTrigger value="history">История</TabsTrigger>
                      <TabsTrigger value="details">Длинная форма</TabsTrigger>
                    </TabsList>
                    <WorkbenchPanel asChild>
                      <TabsContent value="history">
                        <WorkbenchScroll
                          role="log"
                          aria-label="История записей"
                        >
                          <Prose>
                            {Array.from({ length: 24 }, (_, n) => (
                              <p key={n}>
                                Запись {n + 1}.{" "}
                                {long
                                  ? "Длинное_сообщение_".repeat(30)
                                  : "Содержимое передаёт продукт."}
                              </p>
                            ))}
                          </Prose>
                        </WorkbenchScroll>
                        <ChatComposer asChild>
                          <form
                            onSubmit={(event) => {
                              event.preventDefault();
                              setSent((value) => value + 1);
                            }}
                          >
                            <Textarea
                              aria-label="Черновик"
                              value={draft}
                              onChange={(event) => setDraft(event.target.value)}
                              rows={2}
                            />
                            <ChatComposerActions>
                              <Button type="submit" disabled={disabled}>
                                Обработать локально
                              </Button>
                            </ChatComposerActions>
                          </form>
                        </ChatComposer>
                      </TabsContent>
                    </WorkbenchPanel>
                    <WorkbenchPanel asChild>
                      <TabsContent value="details">
                        <WorkbenchScroll aria-label="Длинная форма">
                          <Prose>
                            <h2>Форма владельца экрана</h2>
                            <p>
                              На небольшом экране содержимое использует
                              прокрутку документа.
                            </p>
                            {Array.from({ length: 20 }, (_, n) => (
                              <p key={n}>
                                Раздел {n + 1}. Валидация и сохранение не
                                принадлежат каркасу.
                              </p>
                            ))}
                          </Prose>
                        </WorkbenchScroll>
                      </TabsContent>
                    </WorkbenchPanel>
                  </Tabs>
                </WorkbenchPanel>
              </WorkbenchMain>
              {!noAside && (
                <WorkbenchAside aria-label="Контекст рабочей области">
                  {context}
                </WorkbenchAside>
              )}
            </WorkbenchGrid>
          </Workbench>
          <DialogContent layout="sectioned">
            <DialogHeader>
              <DialogTitle>Контекст рабочей области</DialogTitle>
            </DialogHeader>
            <DialogBody>{context}</DialogBody>
          </DialogContent>
        </Dialog>
      </PageFrame>
    </>
  );
}
