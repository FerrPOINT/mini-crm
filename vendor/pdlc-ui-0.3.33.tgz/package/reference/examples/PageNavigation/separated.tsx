import { useState } from "react";
import { PageNavigation, ResourceList, ResourceListRow } from "@pdlc/ui/ui";

/** The product owns content and page state; the footer divider follows Base density. */
export default function SeparatedExample() {
  const [page, setPage] = useState(1);
  return (
    <section aria-label="Каталог ресурсов" className="min-w-0 space-y-4">
      <ResourceList>
        <ResourceListRow>Ресурс страницы {page}</ResourceListRow>
      </ResourceList>
      <PageNavigation
        label="Страницы каталога"
        page={page}
        pageCount={3}
        separated
        onPageChange={setPage}
      />
    </section>
  );
}
