import { useId, useState } from "react";
import { Button, FormField, Input } from "@pdlc/ui/ui";

/** Native selection only; no file is read, uploaded or executed by this example. */
export default function FilesExample() {
  const id = useId();
  const [names, setNames] = useState<string[]>([]);
  const [formNames, setFormNames] = useState<string[] | null>(null);
  return (
    <form
      className="base-page-stack"
      onSubmit={(event) => {
        event.preventDefault();
        setFormNames(
          new FormData(event.currentTarget)
            .getAll("files")
            .filter(
              (entry): entry is File => entry instanceof File && !!entry.name,
            )
            .map((file) => file.name),
        );
      }}
      onReset={() => {
        setNames([]);
        setFormNames(null);
      }}
    >
      <FormField
        id={id}
        label="Файлы JSON"
        hint="Можно выбрать несколько файлов."
      >
        {(attrs) => (
          <Input
            {...attrs}
            name="files"
            type="file"
            accept="application/json,.json"
            multiple
            onChange={(event) =>
              setNames(
                Array.from(
                  event.currentTarget.files ?? [],
                  (file) => file.name,
                ),
              )
            }
          />
        )}
      </FormField>
      <FormField id={`${id}-disabled`} label="Недоступная загрузка">
        {(attrs) => <Input {...attrs} type="file" disabled />}
      </FormField>
      <output aria-live="polite">
        {names.length ? `Выбрано: ${names.join(", ")}` : "Файлы не выбраны"}
      </output>
      <output aria-live="polite">
        {formNames === null
          ? "Форма не прочитана"
          : formNames.length
            ? `В форме: ${formNames.join(", ")}`
            : "В форме нет файлов"}
      </output>
      <Button type="submit">Прочитать FormData</Button>
      <Button type="reset" variant="outline">
        Сбросить выбор файлов
      </Button>
    </form>
  );
}
