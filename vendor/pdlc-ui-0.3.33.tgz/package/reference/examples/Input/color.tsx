import { useState } from "react";
import { Button, Input, Label } from "@pdlc/ui/ui";

export default function Example() {
  const [submitted, setSubmitted] = useState("");
  return (
    <form
      className="grid gap-3"
      onSubmit={(event) => {
        event.preventDefault();
        const values = new FormData(event.currentTarget);
        setSubmitted(String(values.get("color")));
      }}
      onReset={() => setSubmitted("")}
    >
      <Label htmlFor="color-example">Цвет</Label>
      <Input
        id="color-example"
        type="color"
        name="color"
        defaultValue="#5e6ad2"
      />
      <Label htmlFor="color-disabled-example">Недоступное поле</Label>
      <Input
        id="color-disabled-example"
        type="color"
        defaultValue="#5e6ad2"
        disabled
      />
      <div className="flex gap-2">
        <Button type="submit">Прочитать FormData</Button>
        <Button type="reset" variant="secondary">
          Сбросить
        </Button>
      </div>
      <output aria-live="polite">{submitted}</output>
    </form>
  );
}
