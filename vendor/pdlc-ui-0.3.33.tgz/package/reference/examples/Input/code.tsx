import { FormField, Input } from "@pdlc/ui/ui";

export default function Example() {
  return (
    <div className="grid gap-4">
      <FormField id="code-field" label="Выражение или идентификатор">
        {(field) => (
          <Input
            {...field}
            className="font-mono"
            defaultValue="status = open AND attempts >= 0"
          />
        )}
      </FormField>
      <FormField id="plain-field" label="Обычный текст">
        {(field) => <Input {...field} defaultValue="Название ресурса" />}
      </FormField>
    </div>
  );
}
