import * as UI from "@pdlc/ui/ui";
import { type ComponentProps } from "react";

export default function Example() {
  const args = {
    value: {
      id: "demo-42",
      name: "Платформа",
      enabled: true,
      roles: ["developer", "reviewer"],
    },
    "aria-label": "Пример JSON",
  } satisfies ComponentProps<typeof UI.JsonBlock>;
  const render = (args: ComponentProps<typeof UI.JsonBlock>) => (
    <UI.JsonBlock {...args} />
  );
  return render(args);
}
