import { useState } from "react";
import { Button, RadioGroup } from "@pdlc/ui/ui";

/** Mode state belongs to the caller; Base retains native radio semantics. */
export default function SegmentedExample() {
  const [mode, setMode] = useState("read");
  return (
    <form className="base-page-stack" onReset={() => setMode("read")}>
      <RadioGroup
        appearance="segmented"
        label="Режим документа"
        name="mode"
        value={mode}
        onValueChange={setMode}
        options={[
          { value: "read", label: "Просмотр" },
          { value: "edit", label: "Правка" },
          { value: "locked", label: "Недоступно", disabled: true },
        ]}
      />
      <output aria-label="Выбранный режим">{mode}</output>
      <RadioGroup
        appearance="segmented"
        label="Длинные названия"
        name="long-mode"
        defaultValue="long"
        options={[
          {
            value: "long",
            label: "Длинное название режима без потери читаемости",
          },
          {
            value: "identifier",
            label:
              "очень_длинный_идентификатор_очень_длинный_идентификатор_режима",
          },
        ]}
      />
      <Button type="reset" variant="outline">
        Сбросить выбор
      </Button>
    </form>
  );
}
