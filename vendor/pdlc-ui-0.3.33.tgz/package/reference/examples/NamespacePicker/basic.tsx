import * as UI from "@pdlc/ui/ui";
import { type ComponentProps, useEffect, useState } from "react";

function useExampleValue<T>(value: T) {
  const [current, setCurrent] = useState(value);
  useEffect(() => setCurrent(value), [value]);
  return [current, setCurrent] as const;
}

export function ControlledNamespacePicker(
  args: ComponentProps<typeof UI.NamespacePicker>,
) {
  const [value, setValue] = useExampleValue(args.value);
  return (
    <div className="space-y-4">
      <UI.NamespacePicker
        {...args}
        value={value}
        onChange={(next) => {
          setValue(next);
          args.onChange(next);
        }}
      />
      <output>Выбрано: {value || "обзор"}</output>
    </div>
  );
}

export default function Example() {
  const args = {
    value: "BASE",
    options: [
      { value: "BASE", label: "Платформа", projectKey: "BASE" },
      { value: "DOCS", label: "Документация", projectKey: "DOCS" },
    ],
    onChange: () => {},
    projectIcons: true,
  } satisfies ComponentProps<typeof UI.NamespacePicker>;
  const render = (args: ComponentProps<typeof UI.NamespacePicker>) => (
    <ControlledNamespacePicker {...args} />
  );
  return render(args);
}
