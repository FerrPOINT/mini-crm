import { useState } from "react";
import { Breadcrumbs, BreadcrumbItem, Button } from "@pdlc/ui/ui";

export default function Example() {
  const [current, setCurrent] = useState(2);
  const [actions, setActions] = useState(0);
  const items = [
    { id: "root", label: "Каталог" },
    { id: "forms", label: "Формы" },
    { id: "components", label: "Компоненты" },
  ];
  return (
    <div className="grid gap-3">
      <Breadcrumbs aria-label="Положение в каталоге">
        {items.slice(0, current + 1).map((item, index) => (
          <BreadcrumbItem
            key={item.id}
            current={current === index}
            onClick={() => {
              setCurrent(index);
              setActions((value) => value + 1);
            }}
          >
            {item.label}
          </BreadcrumbItem>
        ))}
      </Breadcrumbs>
      <Button variant="outline" onClick={() => setCurrent(2)}>
        Вернуть полную цепочку
      </Button>
      <p role="status">Подтверждённых переходов: {actions}</p>
    </div>
  );
}
