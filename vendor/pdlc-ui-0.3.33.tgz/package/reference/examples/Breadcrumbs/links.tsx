import { Breadcrumbs, BreadcrumbItem } from "@pdlc/ui/ui";
import { Link, useLocation } from "react-router";

/** Supply the application's Router; native links need no Router provider. */
export default function Example() {
  const location = useLocation();
  const atCatalog = location.pathname === "/catalog";
  return (
    <div className="grid gap-3">
      <Breadcrumbs aria-label="Путь ресурса">
        <BreadcrumbItem asChild current={atCatalog}>
          <Link to="/catalog?group=Forms#controls">Каталог</Link>
        </BreadcrumbItem>
        {!atCatalog && (
          <>
            <BreadcrumbItem asChild>
              <a href="#example">Пример на странице</a>
            </BreadcrumbItem>
            <BreadcrumbItem asChild current>
              <span>Текущий ресурс</span>
            </BreadcrumbItem>
          </>
        )}
      </Breadcrumbs>
      <p id="example">
        Текущий URL Router: {location.pathname}
        {location.search}
        {location.hash}
      </p>
    </div>
  );
}
