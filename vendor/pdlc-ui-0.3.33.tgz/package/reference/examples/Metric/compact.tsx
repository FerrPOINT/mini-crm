import { Metric } from "@pdlc/ui/ui";

export default function Compact() {
  return (
    <div className="grid grid-cols-3 gap-2 text-center">
      <Metric appearance="compact" label="В очереди" value={0} />
      <Metric appearance="compact" label="В работе" value={2} />
      <Metric appearance="compact" label="Готово" value="—" />
    </div>
  );
}
