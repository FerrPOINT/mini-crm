// Example controls require @pdlc/ui/tokens.css; the hook itself has no CSS/provider setup.
import { useCallback, useState } from "react";
import { useMediaQuery } from "@pdlc/ui/lib";
import { FormField, Input, ResourceListDescription, Select } from "@pdlc/ui/ui";

export default function MediaQueryExample() {
  const [query, setQuery] = useState("(min-width: 1024px)");
  const [draft, setDraft] = useState("Черновик владельца");
  const [transitions, setTransitions] = useState(0);
  const changed = useCallback(() => setTransitions((value) => value + 1), []);
  const matches = useMediaQuery(query, changed);
  return (
    <div className="space-y-4">
      <FormField id="media-query" label="Условие браузера">
        {(attrs) => (
          <Select
            {...attrs}
            value={query}
            onValueChange={setQuery}
            options={[
              { value: "(min-width: 1024px)", label: "Ширина от 1024 px" },
              {
                value: "(prefers-reduced-motion: reduce)",
                label: "Уменьшение движения",
              },
            ]}
          />
        )}
      </FormField>
      <FormField id="media-draft" label="Ввод сохраняется при изменении ширины">
        {(attrs) => (
          <Input
            {...attrs}
            value={draft}
            onChange={(event) => setDraft(event.target.value)}
          />
        )}
      </FormField>
      <ResourceListDescription>
        Условие: {matches ? "выполнено" : "не выполнено"}. Изменений браузера:{" "}
        {transitions}. Смена условия не является переходом браузера.
      </ResourceListDescription>
    </div>
  );
}
