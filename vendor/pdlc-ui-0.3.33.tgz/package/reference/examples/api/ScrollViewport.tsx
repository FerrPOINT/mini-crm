// Example controls require @pdlc/ui/tokens.css; the hook needs a mounted native viewport.
import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { useScrollViewport } from "@pdlc/ui/lib";
import {
  ActionGroup,
  Button,
  ResourceList,
  ResourceListDescription,
  ResourceListRow,
  WorkbenchScroll,
} from "@pdlc/ui/ui";

export default function ScrollViewportExample() {
  const ref = useRef<HTMLDivElement>(null);
  const viewport = useScrollViewport(ref, "synthetic-history");
  const following = useRef(true);
  const previous = useRef(-1);
  const next = useRef(20);
  const pending = useRef<ReturnType<typeof viewport.preservePrepend> | null>(
    null,
  );
  const applyPending = useRef(false);
  const [loading, setLoading] = useState(false);
  const [unread, setUnread] = useState(false);
  const [rows, setRows] = useState(() =>
    Array.from({ length: 20 }, (_, id) => ({ id, text: `Запись ${id + 1}` })),
  );

  useLayoutEffect(() => {
    const finish = pending.current;
    if (!finish || !applyPending.current) return;
    applyPending.current = false;
    pending.current = null;
    finish({ defer: false });
  }, [rows]);
  useEffect(() => {
    if (following.current) viewport.scrollToEnd();
  }, [rows, viewport]);

  return (
    <div className="space-y-4">
      <ActionGroup align="start">
        <Button
          onClick={() => {
            following.current = false;
            viewport.restore(120);
          }}
        >
          Читать историю
        </Button>
        <Button
          onClick={() => {
            const id = next.current++;
            if (!following.current) setUnread(true);
            setRows((current) => [
              ...current,
              { id, text: `Запись ${id + 1}` },
            ]);
          }}
        >
          Добавить в конец
        </Button>
        <Button
          disabled={loading}
          onClick={() => {
            following.current = false;
            pending.current = viewport.preservePrepend();
            setLoading(true);
          }}
        >
          Начать загрузку истории
        </Button>
        <Button
          disabled={!loading}
          onClick={() => {
            applyPending.current = true;
            setLoading(false);
            setUnread(true);
            const older = Array.from({ length: 3 }, () => ({
              id: previous.current--,
              text: "Более ранняя запись",
            }));
            const id = next.current++;
            setRows((current) => [
              ...older,
              ...current,
              { id, text: "Новая запись в конце" },
            ]);
          }}
        >
          Применить историю и новую запись
        </Button>
        <Button
          disabled={!loading}
          onClick={() => {
            pending.current?.cancel();
            pending.current = null;
            applyPending.current = false;
            setLoading(false);
          }}
        >
          Отменить историю
        </Button>
        <Button
          onClick={() => {
            following.current = true;
            viewport.scrollToEnd();
            setUnread(false);
          }}
        >
          К последним записям
        </Button>
      </ActionGroup>
      <WorkbenchScroll
        className="h-64"
        ref={ref}
        aria-label="История примера"
        tabIndex={0}
        onScroll={() => {
          const position = viewport.observe(40);
          if (position) {
            following.current = position.atEnd;
            if (position.atEnd) setUnread(false);
          }
        }}
      >
        <ResourceList>
          {rows.map((row) => (
            <ResourceListRow key={row.id} asChild>
              <article data-scroll-anchor="">{row.text}</article>
            </ResourceListRow>
          ))}
        </ResourceList>
      </WorkbenchScroll>
      <ResourceListDescription>
        {loading
          ? "Результат примера применяется отдельной кнопкой; сетевых запросов нет."
          : unread
            ? "Есть новые записи; позиция чтения сохранена."
            : "Можно читать историю или следовать за концом."}
      </ResourceListDescription>
    </div>
  );
}
