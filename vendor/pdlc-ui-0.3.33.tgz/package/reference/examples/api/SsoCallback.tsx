import {
  completeSso,
  applySsoSession,
  relaySsoCallback,
  type SsoConfig,
  type SsoSession,
} from "@pdlc/ui/sso";

/** Run on the callback route only. The test adapter supplies synthetic token/JWKS replies;
 * Base retains state/nonce/issuer/signature verification. No decoded token is trusted here. */
export async function handleCallback(
  config: SsoConfig,
  apply: (session: SsoSession) => void,
) {
  if (relaySsoCallback(config.namespace)) return null;
  const session = await completeSso(config);
  applySsoSession(session, () => apply(session));
  return session.returnTo;
}
