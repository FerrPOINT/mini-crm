import { useEffect, useRef } from "react";
import {
  createBrandingRuntime,
  normalizeBranding,
  resolveBrandingTokens,
} from "@pdlc/ui/lib";
import { defaultBranding } from "@pdlc/ui/lib";
/** A local synthetic document: no credentials, network or platform preference writes. */
export default function Example() {
  const root = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!root.current) return;
    const value = normalizeBranding(defaultBranding);
    if (!value) return;
    root.current.dataset.accent = resolveBrandingTokens(value, "gray")[
      "--color-accent"
    ];
    const runtime = createBrandingRuntime({
      root: root.current,
      configUrl: null,
      defaults: value,
      storage: null,
    });
    return () => runtime.dispose();
  }, []);
  return (
    <div ref={root} data-theme="gray">
      Локальная область оформления
    </div>
  );
}
