import { downloadBlob } from "@pdlc/ui/lib";
import { Button } from "@pdlc/ui/ui";
import "@pdlc/ui/tokens.css";

export default function Example() {
  return (
    <Button
      onClick={() =>
        downloadBlob(
          new Blob(["name,status\nExample,ready\n"], {
            type: "text/csv;charset=utf-8",
          }),
          "example-report.csv",
        )
      }
    >
      Скачать пример отчёта
    </Button>
  );
}
