import { useState } from "react";
import {
  capturePlatformPrivateState,
  clearPlatformPrivateQueries,
  guardPlatformPrivateResponse,
} from "@pdlc/ui/platform";
import { Button } from "@pdlc/ui/ui";

/** Invoke only at the owning product's confirmed authority-change boundary. */
export function retirePrivateProductState() {
  const original = capturePlatformPrivateState();
  clearPlatformPrivateQueries();
  return original(); // false: results started in the previous generation are stale.
}

/** No fetch or cache reset: a synthetic response illustrates body-read fencing. */
export async function readSyntheticResponse() {
  const current = capturePlatformPrivateState();
  const response = guardPlatformPrivateResponse(
    new Response("Синтетический ответ"),
    current,
  );
  const text = await response.text();
  if (!current())
    throw new Error("Поколение изменилось до применения результата");
  return text;
}

export default function Example() {
  const [message, setMessage] = useState(
    "Чтение только по действию пользователя.",
  );
  const read = async () => {
    try {
      setMessage(await readSyntheticResponse());
    } catch {
      setMessage("Доступ изменился; устаревший ответ не применяется.");
    }
  };
  return (
    <>
      <Button type="button" onClick={() => void read()}>
        Прочитать синтетический ответ
      </Button>
      <p role="status">{message}</p>
    </>
  );
}
