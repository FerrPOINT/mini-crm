import { validBrandUrl } from "@pdlc/ui/branding/runtime";
import { useState } from "react";
import {
  BrandDesignEditor,
  type BrandTheme,
  createBrandDocument,
  normalizeBranding,
  validateBrand,
  referencedAssets,
  flattenDocument,
  brandingWireSnapshot,
} from "@pdlc/ui/branding";

export default function Example({ theme = "dark" }: { theme?: BrandTheme }) {
  const [value, setValue] = useState(() =>
    normalizeBranding(createBrandDocument())!,
  );
  const [variant, setVariant] = useState<"common" | "light" | "dark">("common");
  const colorTheme = theme;
  const [uploadError, setUploadError] = useState("");
  const errors = validateBrand(value);
  return (
    <section>
      <BrandDesignEditor
        value={value}
        onChange={setValue}
        variant={variant}
        onVariantChange={setVariant}
        colorTheme={colorTheme}

        onUpload={() =>
          setUploadError(
            "Загрузка изображений требует подключения Admin Panel.",
          )
        }
        uploadError={uploadError}
        uploadDisabledReason="Для загрузки подключите Admin Panel."
      />
      <output aria-label="Проверка документа">
        {JSON.stringify({
          errors,
          supportUrlValid: validBrandUrl(value.support_url ?? ""),
          assets: referencedAssets(value),
          fields: flattenDocument(brandingWireSnapshot(value)),
        })}
      </output>
    </section>
  );
}
