import { usePlatformBranding } from "@pdlc/ui/lib";
import { PlatformMark } from "@pdlc/ui/ui";

/** The application root supplies PlatformProvider and its authoritative URL.
 * This view only reads it: it never publishes a brand or constructs a colour palette. */
export default function Example() {
  const { branding, source } = usePlatformBranding();
  return (
    <section>
      <PlatformMark />
      <p>
        {branding.product_name} · {source}
      </p>
    </section>
  );
}
