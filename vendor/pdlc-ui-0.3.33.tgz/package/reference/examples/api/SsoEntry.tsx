import { useSsoEntry } from "@pdlc/ui/auth";
import { PlatformLogin } from "@pdlc/ui/ui";
import type { SsoConfig } from "@pdlc/ui/sso";

/** Supply an isolated test config/transport when demonstrating this view.
 * No automatic login is started; a product supplies its own confirmed Auth config. */
export default function Example({ config }: { config: SsoConfig }) {
  const entry = useSsoEntry({
    config,
    returnTo: "/issues?project_scope=all",
    autoStart: false,
  });
  return <PlatformLogin {...entry} onSignIn={entry.signIn} />;
}
