import { readableForeground } from "@pdlc/ui/lib";

export default function Example() {
  const samples = ["#ef4444", "#1e293b", "#ffffff"].map((background) => ({
    background,
    foreground: readableForeground(background),
  }));
  return <pre>{JSON.stringify(samples, null, 2)}</pre>;
}
