import { useEffect, useRef } from "react";
import {
  initChoice,
  refreshChoice,
  destroyChoice,
} from "@pdlc/ui/select-runtime";
export default function Example() {
  const container = useRef<HTMLDivElement>(null);
  useEffect(() => {
    // A synthetic native backing control, as emitted by the SSR macro.
    const select = document.createElement("select");
    select.setAttribute("aria-label", "SSR-приоритет");
    select.append(new Option("Все", ""), new Option("Высокий", "high"));
    container.current!.append(select);
    initChoice(select);
    select.value = "high";
    refreshChoice(select);
    return () => {
      destroyChoice(select);
      select.remove();
    };
  }, []);
  return <div ref={container} />;
}
