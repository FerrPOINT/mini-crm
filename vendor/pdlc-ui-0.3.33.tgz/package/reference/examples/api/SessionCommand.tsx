import { useSessionCommand } from "@pdlc/ui/lib";
import { Button } from "@pdlc/ui/ui";

/** Persist no credentials. An unknown write must be read back by its owner before retry. */
export default function Example() {
  const command = useSessionCommand<{ operationId: string; title: string }>(
    "dictionary:synthetic-operation",
  );
  return (
    <>
      <Button
        onClick={() =>
          command.capture({
            operationId: crypto.randomUUID(),
            title: "Локальный пример",
          })
        }
      >
        Зафиксировать отправляемую версию
      </Button>
      <Button disabled={!command.command} onClick={() => command.clear()}>
        Результат подтверждён владельцем
      </Button>
      <output>{command.command?.title ?? "Нет незавершённой команды"}</output>
    </>
  );
}
