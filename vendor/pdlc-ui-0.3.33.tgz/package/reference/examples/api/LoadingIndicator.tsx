import { connectLoadingIndicator } from "@pdlc/ui/platform/loading";

/** The host owns readiness. This observer only displays its pending target.
 * Supply detached fixture elements in tests and always call the returned cleanup. */
export function loadingExample(root: HTMLElement, indicator: HTMLElement) {
  return connectLoadingIndicator(root, indicator, { delayMs: 0 });
}
