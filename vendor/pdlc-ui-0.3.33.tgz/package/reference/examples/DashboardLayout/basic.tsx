import * as UI from "@pdlc/ui/ui";
import { type ComponentProps } from "react";

export default function Example() {
  const args = {
    title: "Проекты",
    context: "Демонстрационный каталог команды",
    actions: <UI.Button>Создать проект</UI.Button>,
    children: (
      <UI.ResourceList>
        <UI.ResourceListRow>Платформа</UI.ResourceListRow>
        <UI.ResourceListRow>Документация</UI.ResourceListRow>
      </UI.ResourceList>
    ),
  } satisfies ComponentProps<typeof UI.DashboardLayout>;
  const render = (args: ComponentProps<typeof UI.DashboardLayout>) => (
    <UI.DashboardLayout {...args} />
  );
  return render(args);
}
