import { LoadingState, Button } from "@pdlc/ui/ui";
import { useState, type ComponentProps } from "react";

export default function Example(props: ComponentProps<typeof LoadingState>) {
  const [pending, setPending] = useState(true);
  return (
    <section aria-label="Необязательные метаданные">
      <p>Основное содержимое остаётся доступным.</p>
      {pending ? (
        <LoadingState
          {...props}
          scope={props.scope ?? "local"}
          message={props.message ?? "Читаем метаданные…"}
        />
      ) : (
        <p>Метаданные подтверждены.</p>
      )}
      <Button type="button" onClick={() => setPending(!pending)}>
        {pending
          ? "Завершить синтетическое чтение"
          : "Повторить показ загрузки"}
      </Button>
    </section>
  );
}
