import { useRef, useState } from "react";
import { Badge, BadgeButton } from "@pdlc/ui/ui";
export default function Example() {
  const [selected, setSelected] = useState(true),
    add = useRef<HTMLButtonElement>(null);
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
      {selected && (
        <Badge tone="info">
          Навык
          <BadgeButton
            tone="info"
            appearance="inline"
            aria-label="Убрать навык"
            onClick={() => {
              setSelected(false);
              add.current?.focus();
            }}
          >
            ×
          </BadgeButton>
        </Badge>
      )}
      <BadgeButton
        ref={add}
        tone="info"
        aria-label="Добавить навык"
        onClick={() => setSelected(true)}
      >
        +
      </BadgeButton>
    </div>
  );
}
