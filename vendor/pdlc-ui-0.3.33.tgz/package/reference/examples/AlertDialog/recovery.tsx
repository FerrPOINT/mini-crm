import { useRef, useState } from "react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  Button,
} from "@pdlc/ui/ui";

export default function AlertRecoveryExample() {
  const [open, setOpen] = useState(false);
  const [available, setAvailable] = useState(true);
  const origin = useRef<HTMLButtonElement>(null);
  const fallback = useRef<HTMLButtonElement>(null);
  return (
    <div className="flex flex-wrap items-center gap-3">
      {available ? (
        <Button
          ref={origin}
          onClick={() => {
            setAvailable(false);
            setOpen(true);
          }}
        >
          Открыть подтверждение
        </Button>
      ) : (
        <p>Исходное действие больше недоступно.</p>
      )}
      <Button
        ref={fallback}
        variant="outline"
        onClick={() => setAvailable(true)}
      >
        Вернуть действие
      </Button>
      <AlertDialog open={open} onOpenChange={setOpen}>
        <AlertDialogContent returnFocusRef={origin} fallbackFocusRef={fallback}>
          <AlertDialogHeader>
            <AlertDialogTitle>Возврат фокуса</AlertDialogTitle>
            <AlertDialogDescription>
              Исходный control удалён из примера. После закрытия Base выбирает
              доступный запасной control. Данные не записываются.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Отмена</AlertDialogCancel>
            <AlertDialogAction>Подтвердить пример</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
