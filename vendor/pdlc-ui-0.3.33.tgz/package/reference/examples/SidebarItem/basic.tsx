import * as UI from "@pdlc/ui/ui";
import { type ComponentProps } from "react";
import { Home } from "lucide-react";

export default function Example() {
  const args = {
    children: (
      <>
        <Home aria-hidden />
        <UI.SidebarItemLabel>Обзор</UI.SidebarItemLabel>
      </>
    ),
    "aria-label": "Обзор",
    title: "Обзор",
    active: true,
    onClick: () => {},
  } satisfies ComponentProps<typeof UI.SidebarItem>;
  const render = (args: ComponentProps<typeof UI.SidebarItem>) => (
    <UI.SidebarItem {...args} />
  );
  return render(args);
}
