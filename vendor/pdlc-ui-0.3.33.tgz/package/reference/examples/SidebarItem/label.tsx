import { useState } from "react";
import { Home, Settings } from "lucide-react";
import * as UI from "@pdlc/ui/ui";

export default function Example() {
  const [compact, setCompact] = useState(false);
  return (
    <div className="space-y-4">
      <UI.Switch
        label="Компактное меню"
        checked={compact}
        onCheckedChange={setCompact}
      />
      <UI.SidebarList asChild>
        <nav aria-label="Навигация примера" className="max-w-60">
          <UI.SidebarItem
            active
            compact={compact}
            aria-label="Обзор"
            title="Обзор"
          >
            <Home aria-hidden />
            <UI.SidebarItemLabel>Обзор</UI.SidebarItemLabel>
          </UI.SidebarItem>
          <UI.SidebarItem
            compact={compact}
            aria-label="Настройки проекта с длинным названием"
            title="Настройки проекта с длинным названием"
          >
            <Settings aria-hidden />
            <UI.SidebarItemLabel>
              Настройки проекта с длинным названием
            </UI.SidebarItemLabel>
          </UI.SidebarItem>
        </nav>
      </UI.SidebarList>
    </div>
  );
}
