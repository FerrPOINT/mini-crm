import { useState } from "react";
import { Button, Checkbox, Fieldset, FormField, Input } from "@pdlc/ui/ui";

export default function SeparatedExample() {
  const [locked, setLocked] = useState(false);
  const [values, setValues] = useState("Форма ещё не прочитана");
  return (
    <form
      className="grid gap-4"
      onSubmit={(event) => {
        event.preventDefault();
        setValues(
          JSON.stringify(Object.fromEntries(new FormData(event.currentTarget))),
        );
      }}
    >
      <Checkbox
        label="Заблокировать группу"
        checked={locked}
        onCheckedChange={(value) => setLocked(value === true)}
      />
      <Fieldset
        separated
        legend="Дополнительные поля"
        disabled={locked}
        className="grid gap-3"
      >
        <FormField id="separated-fieldset-name" label="Название">
          {(props) => <Input {...props} name="name" defaultValue="Запись" />}
        </FormField>
        <Checkbox
          name="notify"
          value="yes"
          label="Уведомлять об изменениях"
          defaultChecked
        />
      </Fieldset>
      <Button type="submit">Прочитать FormData</Button>
      <output aria-live="polite">{values}</output>
    </form>
  );
}
