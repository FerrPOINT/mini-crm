import { useRef, useState } from "react";
import { Button, FormDialog, FormField, Input, Notice } from "@pdlc/ui/ui";

/** In-memory fixture: no write or network request is performed. */
export default function Readback({
  long = false,
  pending = false,
}: {
  long?: boolean;
  pending?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const [value, setValue] = useState("Черновик");
  const [unknown, setUnknown] = useState(true);
  const [checks, setChecks] = useState(0);
  const trigger = useRef<HTMLButtonElement>(null);
  const content = useRef<HTMLDivElement>(null);
  return (
    <>
      <Button ref={trigger} onClick={() => setOpen(true)}>
        Открыть форму со сверкой
      </Button>
      <FormDialog
        open={open}
        onOpenChange={setOpen}
        title={<>Настройки пространства</>}
        description="Изменения и проверка сохранённого результата разделены."
        contentRef={content}
        returnFocusRef={trigger}
        pending={pending}
        fieldsetDisabled={unknown}
        onSubmit={(event) => {
          event.preventDefault();
          setOpen(false);
        }}
        bodyAfter={
          unknown ? (
            <Notice
              tone="warning"
              actions={
                <Button
                  type="button"
                  onClick={() => {
                    setChecks((n) => n + 1);
                    setUnknown(false);
                  }}
                >
                  Проверить результат
                </Button>
              }
            >
              Результат записи неизвестен. Черновик сохранён; повторная запись
              закрыта.
            </Notice>
          ) : (
            <p role="status">Результат проверен · {checks}</p>
          )
        }
        footer={
          <>
            <Button
              type="button"
              variant="outline"
              onClick={() => setOpen(false)}
            >
              Закрыть
            </Button>
            <Button type="submit" disabled={unknown}>
              Сохранить
            </Button>
          </>
        }
      >
        <FormField id="readback-name" label="Название" required>
          {(attrs) => (
            <Input
              {...attrs}
              value={value}
              onChange={(event) => setValue(event.target.value)}
            />
          )}
        </FormField>
        {long &&
          Array.from({ length: 16 }, (_, index) => (
            <FormField
              key={index}
              id={`readback-option-${index}`}
              label={`Настройка ${index + 1}`}
            >
              {(attrs) => (
                <Input {...attrs} defaultValue="Длинное содержимое формы" />
              )}
            </FormField>
          ))}
      </FormDialog>
    </>
  );
}
