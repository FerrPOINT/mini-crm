import * as UI from "@pdlc/ui/ui";
import { type ComponentProps, useState } from "react";

export function LoginDemo(args: ComponentProps<typeof UI.PlatformLogin>) {
  const [clicked, setClicked] = useState(false);
  return (
    <>
      <UI.PlatformLogin
        {...args}
        onSignIn={() => {
          setClicked(true);
          args.onSignIn();
        }}
      />
      {clicked && (
        <p role="status">
          Нажатие отмечено. Реальный SSO в каталоге не запускается.
        </p>
      )}
    </>
  );
}

export default function Example() {
  const args = {
    pending: false,
    error: null,
    onSignIn: () => {},
  } satisfies ComponentProps<typeof UI.PlatformLogin>;
  const render = (args: ComponentProps<typeof UI.PlatformLogin>) => (
    <LoginDemo {...args} />
  );
  return render(args);
}
