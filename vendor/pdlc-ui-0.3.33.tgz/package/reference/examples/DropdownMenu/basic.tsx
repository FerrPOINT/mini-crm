import * as UI from "@pdlc/ui/ui";
import { type ComponentProps, useState } from "react";

export function MenuDemo() {
  const [density, setDensity] = useState("comfortable");
  const [action, setAction] = useState("Действие не выбрано");
  return (
    <div className="space-y-4">
      <UI.DropdownMenu>
        <UI.DropdownMenuTrigger asChild>
          <UI.Button variant="outline">Действия проекта</UI.Button>
        </UI.DropdownMenuTrigger>
        <UI.DropdownMenuContent>
          <UI.DropdownMenuGroup>
            <UI.DropdownMenuLabel>Проект</UI.DropdownMenuLabel>
            <UI.DropdownMenuItem
              onSelect={() => setAction("Открыть настройки")}
            >
              Настройки
            </UI.DropdownMenuItem>
            <UI.DropdownMenuItem disabled>Архивировать</UI.DropdownMenuItem>
            <UI.DropdownMenuItem
              tone="danger"
              onSelect={() => setAction("Синтетическое удаление")}
            >
              Удалить
            </UI.DropdownMenuItem>
          </UI.DropdownMenuGroup>
          <UI.DropdownMenuSeparator />
          <UI.DropdownMenuLabel>Плотность</UI.DropdownMenuLabel>
          <UI.DropdownMenuRadioGroup value={density} onValueChange={setDensity}>
            <UI.DropdownMenuRadioItem value="comfortable">
              Обычная
            </UI.DropdownMenuRadioItem>
            <UI.DropdownMenuRadioItem value="compact">
              Компактная
            </UI.DropdownMenuRadioItem>
          </UI.DropdownMenuRadioGroup>
        </UI.DropdownMenuContent>
      </UI.DropdownMenu>
      <output>
        {action} · {density}
      </output>
    </div>
  );
}

export default function Example() {
  const render = () => <MenuDemo />;
  return render();
}
