import { useState } from "react";
import {
  Button,
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  ResourceListDescription,
} from "@pdlc/ui/ui";

export default function Example() {
  const [actions, setActions] = useState(0);
  return (
    <section aria-label="Составное меню" className="space-y-4">
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button type="button" variant="outline">
            Открыть меню
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent className="w-72">
          <DropdownMenuLabel>
            Имя пользователя с длинной подписью
            <ResourceListDescription className="block">
              user-with-a-long-address@example.test
            </ResourceListDescription>
          </DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuGroup className="flex items-start gap-1">
            <DropdownMenuItem
              className="min-w-0 flex-1 items-start"
              onSelect={() => setActions((value) => value + 1)}
            >
              <span>
                Обновление проекта
                <ResourceListDescription className="block">
                  Подробности действия остаются у приложения.
                </ResourceListDescription>
              </span>
            </DropdownMenuItem>
            <DropdownMenuItem
              asChild
              onSelect={() => setActions((value) => value + 1)}
            >
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="shrink-0"
                aria-label="Отметить прочитанным"
              >
                <span aria-hidden="true">✓</span>
              </Button>
            </DropdownMenuItem>
          </DropdownMenuGroup>
          <DropdownMenuItem disabled>Недоступное действие</DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
      <output role="status">Выполнено действий: {actions}</output>
    </section>
  );
}
