import { Folder, Wrench } from "lucide-react";
import { IconMark } from "@pdlc/ui/ui";

export default function Example() {
  return (
    <div className="flex flex-wrap items-center gap-4">
      <span className="inline-flex min-w-0 items-center gap-2">
        <IconMark color="#2563eb">
          <Folder aria-hidden />
        </IconMark>
        <span>Ресурс с названием</span>
      </span>
      <IconMark color="#ffffff" size="sm" label="Настройка ресурса">
        <Wrench aria-hidden />
      </IconMark>
    </div>
  );
}
