import { CopyButton } from "@pdlc/ui/ui";

/** The browser writes only after the user activates the button. */
export default function CopyReferenceExample() {
  return (
    <CopyButton
      value="demo/namespace-42"
      copiedLabel="Идентификатор скопирован"
    >
      Копировать идентификатор
    </CopyButton>
  );
}
