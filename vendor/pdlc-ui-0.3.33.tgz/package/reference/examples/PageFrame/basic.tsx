import * as UI from "@pdlc/ui/ui";
import { type ComponentProps } from "react";

export default function Example() {
  const args = {
    mode: "reading",
    children: (
      <UI.Card>
        <UI.CardHeader>
          <UI.CardTitle>Содержимое страницы</UI.CardTitle>
        </UI.CardHeader>
        <UI.CardContent>Контент продукта в общей рамке.</UI.CardContent>
      </UI.Card>
    ),
  } satisfies ComponentProps<typeof UI.PageFrame>;
  const render = (args: ComponentProps<typeof UI.PageFrame>) => (
    <UI.PageFrame {...args} />
  );
  return render(args);
}
