import { useState } from "react";
import { ActionGroup, Button, Prose } from "@pdlc/ui/ui";

// Synthetic prepared markup only; product Markdown parsing and sanitization are not part of Base.
const preparedHtml = (revision: number) => `
<h2>Подготовленный документ · ${revision}</h2>
<p>Код и таблица доступны через Tab; стрелки прокручивают широкое содержимое.</p>
<pre aria-label="Подготовленный код"><code>${"example --namespace=local ".repeat(24)}</code></pre>
<table><caption>Синтетическая таблица</caption><thead><tr><th>Ресурс</th><th>Версия</th><th>Пространство</th><th>Состояние</th></tr></thead><tbody><tr><td>Пример</td><td>${revision}</td><td>Локальное</td><td>Доступен</td></tr></tbody></table>`;

export default function PreparedHtmlExample({
  keyboardScroll = true,
  compact = false,
}: {
  keyboardScroll?: boolean;
  compact?: boolean;
}) {
  const [revision, setRevision] = useState(1);
  return (
    <>
      <ActionGroup align="start">
        <Button type="button" onClick={() => setRevision((value) => value + 1)}>
          Обновить содержимое
        </Button>
        <Button type="button" variant="outline" onClick={() => setRevision(1)}>
          Сбросить
        </Button>
      </ActionGroup>
      <Prose
        keyboardScroll={keyboardScroll}
        compact={compact}
        dangerouslySetInnerHTML={{ __html: preparedHtml(revision) }}
      />
    </>
  );
}
