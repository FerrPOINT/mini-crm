import { Prose, type ProseProps } from "@pdlc/ui/ui";

/** The owner retains the text, native attributes and source link. */
export default function Paragraph(
  props: Omit<ProseProps, "children" | "asChild"> = {},
) {
  return (
    <Prose
      {...props}
      asChild
      preserveLineBreaks={props.preserveLineBreaks ?? true}
    >
      <p id="prepared-explanation" role="note">
        {"Изменение создаёт новую ревизию.\n"}
        История и исходный <code>revision_id</code> сохраняются. Ознакомьтесь с{" "}
        <a href="#prepared-explanation">подготовленным пояснением</a>.
      </p>
    </Prose>
  );
}
