import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  TextLink,
} from "@pdlc/ui/ui";

export default function Example() {
  return (
    <div className="grid min-w-0 gap-4 sm:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle aria-describedby="card-description-default">
            Контекст карточки
          </CardTitle>
          <CardDescription id="card-description-default">
            Описание связано с заголовком и использует типографику выбранного
            брендинга.
          </CardDescription>
        </CardHeader>
        <CardContent>Данные, права и действия остаются у продукта.</CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>Второстепенное пояснение</CardTitle>
          <CardDescription tone="muted">
            Длинная строка переносится, включая
            непрерывный_идентификатор_связанного_ресурса_карточки.{" "}
            <TextLink href="#card-description-default">
              Связанный контекст
            </TextLink>
          </CardDescription>
        </CardHeader>
        <CardContent>Одна обычная ссылка с клавиатурным фокусом.</CardContent>
      </Card>
    </div>
  );
}
