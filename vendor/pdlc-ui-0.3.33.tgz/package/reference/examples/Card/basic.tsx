import * as UI from "@pdlc/ui/ui";
import { type ComponentProps } from "react";

export default function Example() {
  const args = {
    children: (
      <>
        <UI.CardHeader>
          <UI.CardTitle>Проект платформы</UI.CardTitle>
        </UI.CardHeader>
        <UI.CardContent>
          <p>Описание и сводные показатели проекта.</p>
          <UI.Badge tone="success">Активен</UI.Badge>
        </UI.CardContent>
      </>
    ),
  } satisfies ComponentProps<typeof UI.Card>;
  const render = (args: ComponentProps<typeof UI.Card>) => (
    <UI.Card {...args} />
  );
  return render(args);
}
