import {
  Card,
  CardHeader,
  CardTitle,
  ResourceList,
  ResourceListRow,
} from "@pdlc/ui/ui";

/** Frames and dividers belong to Base, including a responsive header and independent lists. */
export default function ResourceCardsExample() {
  return (
    <div className="grid gap-4">
      <Card asChild>
        <section aria-label="Карточка с адаптивной шапкой">
          <CardHeader className="hidden md:block">
            <CardTitle>Ресурсы проекта</CardTitle>
          </CardHeader>
          <ResourceList>
            <ResourceListRow>
              Шапка скрывается на узком экране, пустой разделитель не остаётся.
            </ResourceListRow>
            <ResourceListRow>
              Вторая строка сохраняет один разделитель.
            </ResourceListRow>
          </ResourceList>
        </section>
      </Card>
      <Card asChild>
        <section aria-label="Карточка без шапки">
          <ResourceList>
            <ResourceListRow>
              Обычный список использует внешнюю рамку карточки.
            </ResourceListRow>
          </ResourceList>
        </section>
      </Card>
      <Card asChild>
        <section aria-label="Список с собственной рамкой">
          <ResourceList variant="bordered">
            <ResourceListRow>
              Явный bordered сохраняет собственную рамку целиком.
            </ResourceListRow>
          </ResourceList>
        </section>
      </Card>
      <ResourceList aria-label="Список вне карточки">
        <ResourceListRow>
          Вне Card обычный список сохраняет верхний и нижний разделители.
        </ResourceListRow>
      </ResourceList>
    </div>
  );
}
