import * as UI from "@pdlc/ui/ui";
import { type ComponentProps, useEffect, useRef, useState } from "react";

function useExampleValue<T>(value: T) {
  const [current, setCurrent] = useState(value);
  useEffect(() => setCurrent(value), [value]);
  return [current, setCurrent] as const;
}

export function ConfirmDemo(args: ComponentProps<typeof UI.ConfirmDialog>) {
  const [open, setOpen] = useExampleValue(args.open);
  const trigger = useRef<HTMLButtonElement>(null);
  const changeOpen = (next: boolean) => {
    setOpen(next);
    args.onOpenChange(next);
  };
  return (
    <>
      <UI.Button
        ref={trigger}
        variant="destructive"
        onClick={() => changeOpen(true)}
      >
        Открыть подтверждение
      </UI.Button>
      <UI.ConfirmDialog
        {...args}
        open={open}
        onOpenChange={changeOpen}
        returnFocusRef={trigger}
      />
    </>
  );
}

export default function Example() {
  const args = {
    open: false,
    onOpenChange: () => {},
    title: "Удалить черновик?",
    description: "В каталоге это только пример диалога.",
    onConfirm: () => {},
    confirmLabel: "Удалить",
    cancelLabel: "Отмена",
    closeOnConfirm: true,
  } satisfies ComponentProps<typeof UI.ConfirmDialog>;
  const render = (args: ComponentProps<typeof UI.ConfirmDialog>) => (
    <ConfirmDemo {...args} />
  );
  return render(args);
}
