import { useState } from "react";
import { Button, Notice } from "@pdlc/ui/ui";

/** A visual priority only: the caller owns the action and its pending state. */
export default function DashedExample() {
  const [added, setAdded] = useState(0);
  return (
    <div className="base-page-stack">
      <Button
        type="button"
        variant="dashed"
        onClick={() => setAdded((count) => count + 1)}
      >
        Добавить карточку
      </Button>
      <Button type="button" variant="dashed" disabled>
        Добавление недоступно
      </Button>
      <Button type="button" variant="dashed" disabled aria-busy="true">
        Добавляем карточку…
      </Button>
      <Notice appearance="inline" role="status">
        Добавлено в примере: {added}. Запросы не выполняются.
      </Notice>
    </div>
  );
}
