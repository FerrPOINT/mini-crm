import { useState } from "react";
import { Button } from "@pdlc/ui/ui";

export default function Example() {
  const [actions, setActions] = useState(0);
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-3">
        {[
          ["#ef4444", "Добавить красную метку"],
          ["#1e293b", "Добавить тёмную метку"],
          [
            "#eab308",
            "Очень длинное предметное значение без потери читаемости",
          ],
          ["invalid", "Неизвестный цвет"],
        ].map(([color, label]) => (
          <Button
            type="button"
            key={color}
            variant="subject"
            subjectColor={color}
            onClick={() => setActions((value) => value + 1)}
          >
            {label}
          </Button>
        ))}
        <Button
          type="button"
          variant="subject"
          subjectColor="#22c55e"
          disabled
          onClick={() => setActions((value) => value + 1)}
        >
          Метка недоступна
        </Button>
      </div>
      <p role="status">Синтетических действий: {actions}</p>
    </div>
  );
}
