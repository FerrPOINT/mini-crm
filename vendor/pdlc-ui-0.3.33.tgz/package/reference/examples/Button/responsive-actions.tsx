import { useState } from "react";
import { Button } from "@pdlc/ui/ui";

export default function ResponsiveActions() {
  const [calls, setCalls] = useState(0);
  const activate = () => setCalls((value) => value + 1);
  return (
    <section aria-label="Действия и компоновка" className="grid gap-3">
      <Button className="md:hidden" onClick={activate}>
        Мобильное действие
      </Button>
      <Button className="hidden md:inline-flex" onClick={activate}>
        Действие на широком экране
      </Button>
      <Button
        variant="outline"
        className="w-full justify-start gap-4 whitespace-normal text-left"
        onClick={activate}
      >
        <span aria-hidden="true">→</span>
        <span>
          Длинное название действия переносится на узком экране и сохраняет
          выравнивание содержимого
        </span>
      </Button>
      <Button hidden onClick={activate}>
        Скрытое действие
      </Button>
      <p role="status">Выполнено действий: {calls}</p>
    </section>
  );
}
