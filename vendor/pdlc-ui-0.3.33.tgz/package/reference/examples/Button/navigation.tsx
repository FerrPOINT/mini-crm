import { Button } from "@pdlc/ui/ui";

export default function Example() {
  return (
    <div className="base-page-actions" id="navigation-example">
      <Button asChild variant="outline">
        <a href="#navigation-example" aria-current="page">
          Текущая страница
        </a>
      </Button>
    </div>
  );
}
