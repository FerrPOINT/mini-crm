import * as UI from "@pdlc/ui/ui";
import { type ComponentProps } from "react";

export default function Example() {
  const args = {
    name: "Анна Иванова",
    userId: "demo-user",
    size: "md",
  } satisfies ComponentProps<typeof UI.UserAvatar>;
  const render = (args: ComponentProps<typeof UI.UserAvatar>) => (
    <UI.UserAvatar {...args} />
  );
  return render(args);
}
