// Setup: @pdlc/ui/tokens.css
import { useState } from "react";
import {
  ActionGroup,
  Button,
  ErrorState,
  FormField,
  Input,
  RenderBoundary,
  ResourceListDescription,
} from "@pdlc/ui/ui";

function Draft({
  failed,
  value,
  onChange,
}: {
  failed: boolean;
  value: string;
  onChange: (value: string) => void;
}) {
  if (failed) throw new Error("Synthetic descendant render failure");
  return (
    <FormField label="Черновик примера" id="boundary-draft">
      {(attrs) => (
        <Input
          {...attrs}
          value={value}
          onChange={(event) => onChange(event.target.value)}
        />
      )}
    </FormField>
  );
}

export default function RenderBoundaryExample() {
  const [failed, setFailed] = useState(false);
  const [generation, setGeneration] = useState(0);
  const [draft, setDraft] = useState("Сохранено владельцем примера");
  const [reported, setReported] = useState(0);
  return (
    <div className="space-y-4">
      <ActionGroup align="start">
        <Button disabled={failed} onClick={() => setFailed(true)}>
          Показать сбой
        </Button>
        <Button
          onClick={() => {
            setFailed(false);
            setGeneration((value) => value + 1);
          }}
        >
          Пересоздать область
        </Button>
      </ActionGroup>
      <RenderBoundary
        key={generation}
        fallback={
          <ErrorState message="Область не удалось отобразить. Черновик хранится снаружи неё." />
        }
        onError={() => setReported((value) => value + 1)}
      >
        <Draft failed={failed} value={draft} onChange={setDraft} />
      </RenderBoundary>
      <ResourceListDescription>
        Перехвачено ошибок: {reported}
      </ResourceListDescription>
    </div>
  );
}
