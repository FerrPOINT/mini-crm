import { CodeBlock } from "@pdlc/ui/ui";
import type { ComponentProps } from "react";

export default function ScrollingCodeExample({
  children = '  cli --name "<value>" --long-option-with-long-identifier=abcdefghijklmnopqrstuvwxy0123456789\n\tend  ',
  ...props
}: ComponentProps<typeof CodeBlock> = {}) {
  return (
    <CodeBlock
      wrap={false}
      aria-label="Команда с исходными строками"
      {...props}
    >
      {children}
    </CodeBlock>
  );
}
