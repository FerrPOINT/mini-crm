import {
  Badge,
  ResourceListDescription,
  ResourceListTitle,
  TextLink,
} from "@pdlc/ui/ui";

/** A literal identifier keeps its native link or status context; no request is made. */
export default function ContextTextExample() {
  return (
    <div className="grid gap-4">
      <TextLink href="#resource-context">
        <ResourceListDescription technical tone="inherit">
          RUN-73
        </ResourceListDescription>
      </TextLink>
      <ResourceListTitle asChild>
        <p id="resource-context">
          <ResourceListTitle technical tone="accent">
            RUN-73
          </ResourceListTitle>{" "}
          — Название ресурса
        </p>
      </ResourceListTitle>
      <Badge tone="warning">
        <ResourceListDescription technical tone="inherit">
          revision-0
        </ResourceListDescription>
      </Badge>
    </div>
  );
}
