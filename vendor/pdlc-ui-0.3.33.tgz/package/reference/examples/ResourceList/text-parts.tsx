import { useState } from "react";
import {
  Button,
  ResourceList,
  ResourceListButton,
  ResourceListDescription,
  ResourceListRow,
  ResourceListTitle,
} from "@pdlc/ui/ui";

export default function ResourceTextExample() {
  const [actions, setActions] = useState(0);
  return (
    <div className="grid gap-3">
      <ResourceList asChild variant="bordered">
        <ul aria-label="Ресурсы">
          <ResourceListRow asChild>
            <li className="flex min-w-0 flex-wrap items-center gap-3">
              <div className="min-w-0 flex-1">
                <ResourceListTitle
                  asChild
                  className="mt-2 flex items-center gap-2"
                >
                  <h2>Длинное название пространства разработки</h2>
                </ResourceListTitle>
                <ResourceListDescription asChild>
                  <p>
                    resource_0000000000000000000000000000000000000000000000000001
                  </p>
                </ResourceListDescription>
              </div>
              <Button
                variant="outline"
                onClick={() => setActions((count) => count + 1)}
              >
                Открыть пример
              </Button>
            </li>
          </ResourceListRow>
          <li>
            <ResourceListButton
              className="w-full text-left"
              onClick={() => setActions((count) => count + 1)}
            >
              <span className="grid min-w-0">
                <ResourceListTitle>Обычное название</ResourceListTitle>
                <ResourceListDescription>
                  В native button части остаются span.
                </ResourceListDescription>
              </span>
            </ResourceListButton>
          </li>
        </ul>
      </ResourceList>
      <p role="status">
        Локальных действий: {actions}. Продуктовые записи не выполняются.
      </p>
    </div>
  );
}
