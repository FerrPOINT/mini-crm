import { ResourceList, ResourceListHeader, ResourceListRow } from "@pdlc/ui/ui";

/** Data, responsive columns and labels belong to the application. */
export default function Example() {
  const columns = "col-span-full grid grid-cols-subgrid gap-3";
  return (
    <ResourceList variant="bordered" aria-label="Ресурсы" className="grid grid-cols-[minmax(0,1fr)_auto]">
      <ResourceListHeader className={columns}>
        <span>Название ресурса</span>
        <span>Состояние</span>
      </ResourceListHeader>
      <ResourceListRow className={columns}>
        <span>Длинное название пространства разработки</span>
        <span>Доступен</span>
      </ResourceListRow>
    </ResourceList>
  );
}
