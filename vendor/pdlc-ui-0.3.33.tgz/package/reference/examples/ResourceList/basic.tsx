import * as UI from "@pdlc/ui/ui";
import { type ComponentProps } from "react";

export default function Example() {
  const args = {
    variant: "bordered",
    density: "comfortable",
  } satisfies ComponentProps<typeof UI.ResourceList>;
  const render = (args: ComponentProps<typeof UI.ResourceList>) => (
    <UI.ResourceList {...args} asChild>
      <ul aria-label="Проекты">
        {["Платформа", "Документация", "Доставка"].map((name) => (
          <UI.ResourceListRow key={name} asChild>
            <li className="flex flex-wrap gap-2">
              <span>{name}</span>
              <UI.Badge tone="success">Активен</UI.Badge>
            </li>
          </UI.ResourceListRow>
        ))}
      </ul>
    </UI.ResourceList>
  );
  return render(args);
}
