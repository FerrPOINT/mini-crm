// Setup: @pdlc/ui/tokens.css
import { useState } from "react";
import {
  Button,
  ResourceList,
  ResourceListRow,
  ResourceListTitle,
  ResourceListDescription,
} from "@pdlc/ui/ui";

export default function CurrentRecordExample() {
  const [current, setCurrent] = useState("second");
  return (
    <div className="space-y-3">
      <Button
        onClick={() =>
          setCurrent((value) => (value === "first" ? "second" : "first"))
        }
      >
        Переключить контекст примера
      </Button>
      <ResourceList asChild>
        <ul aria-label="Записи">
          {[
            { id: "first", label: "Первая запись" },
            { id: "second", label: "Вторая запись" },
          ].map((item) => (
            <ResourceListRow
              key={item.id}
              asChild
              highlighted={current === item.id}
            >
              <li
                aria-current={current === item.id ? "true" : undefined}
                className="grid gap-1"
              >
                <ResourceListTitle>{item.label}</ResourceListTitle>
                <ResourceListDescription>
                  Статическая строка; не кнопка и не новое выбранное значение
                  формы.
                </ResourceListDescription>
              </li>
            </ResourceListRow>
          ))}
        </ul>
      </ResourceList>
    </div>
  );
}
