import {
  ResourceList,
  ResourceListRow,
  ResourceListTitle,
  ResourceListDescription,
} from "@pdlc/ui/ui";

export default function TechnicalText() {
  return (
    <ResourceList variant="bordered">
      <ResourceListRow>
        <ResourceListTitle asChild technical>
          <p>namespace/revision_42</p>
        </ResourceListTitle>
        <ResourceListDescription asChild technical>
          <p>HTTP 503 · /workspace/very-long-source-path</p>
        </ResourceListDescription>
        <ResourceListDescription asChild>
          <p>
            Последняя подтверждённая ревизия; недоступность не означает пустоту.
          </p>
        </ResourceListDescription>
      </ResourceListRow>
    </ResourceList>
  );
}
