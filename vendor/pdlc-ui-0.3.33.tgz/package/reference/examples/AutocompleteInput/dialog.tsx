import { useState } from "react";
import {
  AutocompleteInput,
  Button,
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
  DialogTrigger,
  FormField,
} from "@pdlc/ui/ui";

export default function InDialogExample() {
  const [value, setValue] = useState("");
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button>Открыть редактор</Button>
      </DialogTrigger>
      <DialogContent>
        <DialogTitle>Выбор Git ref</DialogTitle>
        <DialogDescription>
          Подсказка не ограничивает свободный ввод. Первый Escape закрывает
          только список.
        </DialogDescription>
        <FormField id="dialog-ref" label="Git ref" hint="Допускается свой ref.">
          {(attrs) => (
            <AutocompleteInput
              {...attrs}
              value={value}
              onValueChange={setValue}
              options={[
                { value: "main", label: "Основная ветка" },
                { value: "release/v1.0", label: "Подготовка выпуска" },
              ]}
            />
          )}
        </FormField>
      </DialogContent>
    </Dialog>
  );
}
