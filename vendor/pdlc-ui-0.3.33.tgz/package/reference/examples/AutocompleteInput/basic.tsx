import { useState } from "react";
import { AutocompleteInput, FormField } from "@pdlc/ui/ui";

export default function BasicExample() {
  const [value, setValue] = useState("");
  return (
    <FormField
      id="suggested-ref"
      label="Git ref"
      hint="Выберите подсказку или введите любой ref."
    >
      {(attrs) => (
        <AutocompleteInput
          {...attrs}
          name="ref"
          value={value}
          onValueChange={setValue}
          options={[
            { value: "main", label: "Основная ветка" },
            { value: "feature/branding", label: "Обновление брендинга" },
            { value: "release/v1.0", label: "Подготовка выпуска" },
            {
              value: "archived/old",
              label: "Недоступная ветка",
              disabled: true,
            },
          ]}
        />
      )}
    </FormField>
  );
}
