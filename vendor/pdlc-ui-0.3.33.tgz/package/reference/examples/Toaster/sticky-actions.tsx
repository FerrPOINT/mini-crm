import { useEffect, useId, useState } from "react";
import { BrandingWorkspaceLayout } from "@pdlc/ui/branding";
import {
  ActionGroup,
  Button,
  ConfirmAction,
  Toaster,
  toast,
} from "@pdlc/ui/ui";

/** Synthetic actions: no requests or publication outside this example. */
export default function Example() {
  const host = useId();
  const notification = `${host}-saved`;
  const [docked, setDocked] = useState(true);
  const [expanded, setExpanded] = useState(false);
  const [published, setPublished] = useState(false);
  useEffect(
    () => () => {
      toast.dismiss(notification);
    },
    [notification],
  );

  return (
    <>
      <BrandingWorkspaceLayout
        status={published ? "Пример опубликован" : "Локальный пример"}
        actions={
          docked && (
            <>
              <Button
                onClick={() =>
                  toast.success("Черновик сохранён", {
                    id: notification,
                    toasterId: host,
                    duration: Infinity,
                  })
                }
              >
                Сохранить пример
              </Button>
              <ConfirmAction
                title="Опубликовать пример?"
                description="Действие меняет только состояние этого примера."
                onConfirm={() => setPublished(true)}
              >
                Опубликовать пример
              </ConfirmAction>
              {expanded && (
                <>
                  <Button variant="outline">Дополнительное действие</Button>
                  <Button variant="outline">Ещё одно действие</Button>
                </>
              )}
            </>
          )
        }
      >
        <div>
          <p>
            Уведомление остаётся открытым, пока вы его не закроете. Сохраните
            пример и откройте подтверждение публикации, не закрывая уведомление.
          </p>
          <ActionGroup align="start">
            <Button variant="outline" onClick={() => setDocked(!docked)}>
              {docked ? "Скрыть панель действий" : "Показать панель действий"}
            </Button>
            <Button variant="outline" onClick={() => setExpanded(!expanded)}>
              {expanded ? "Сократить действия" : "Развернуть действия"}
            </Button>
          </ActionGroup>
        </div>
      </BrandingWorkspaceLayout>
      <Toaster id={host} />
    </>
  );
}
