import { OffsetPageNavigation } from "@pdlc/ui/ui";
import { type ComponentProps, useEffect, useState } from "react";

export function ControlledOffsetNavigation(
  args: ComponentProps<typeof OffsetPageNavigation>,
) {
  const [offset, setOffset] = useState(args.offset);
  useEffect(() => setOffset(args.offset), [args.offset]);
  return (
    <OffsetPageNavigation
      {...args}
      offset={offset}
      onOffsetChange={(value) => {
        setOffset(value);
        args.onOffsetChange(value);
      }}
    />
  );
}

export default function Example() {
  const [offset, setOffset] = useState(0);
  return (
    <OffsetPageNavigation
      offset={offset}
      limit={20}
      total={55}
      onOffsetChange={setOffset}
      label="Результаты каталога"
    />
  );
}
