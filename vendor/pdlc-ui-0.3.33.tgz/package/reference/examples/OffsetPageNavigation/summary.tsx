import { useState } from "react";
import { OffsetPageNavigation } from "@pdlc/ui/ui";

export default function SummaryExample() {
  const [offset, setOffset] = useState(0);
  return (
    <OffsetPageNavigation
      offset={offset}
      limit={20}
      total={7}
      singlePage="summary"
      label="Результаты каталога"
      onOffsetChange={setOffset}
    />
  );
}
