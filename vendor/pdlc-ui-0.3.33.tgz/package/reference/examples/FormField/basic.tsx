import * as UI from "@pdlc/ui/ui";
import { type ComponentProps } from "react";

export default function Example() {
  const args = {
    id: "project-name",
    label: "Название проекта",
    required: true,
    hint: "Понятное участникам название",
    children: (attrs) => (
      <UI.Input {...attrs} placeholder="Например, платформа" />
    ),
  } satisfies ComponentProps<typeof UI.FormField>;
  const render = (args: ComponentProps<typeof UI.FormField>) => (
    <UI.FormField {...args} />
  );
  return render(args);
}
