import * as UI from "@pdlc/ui/ui";
import { type ComponentProps } from "react";
import { useLocation } from "react-router";

export function LocationReadout() {
  const location = useLocation();
  return (
    <output>
      Локальный маршрут: {location.pathname}
      {location.search}
    </output>
  );
}

export default function Example() {
  const args = {
    to: "/projects",
    children: "Открыть проекты",
  } satisfies ComponentProps<typeof UI.NamespaceLink>;
  const render = (args: ComponentProps<typeof UI.NamespaceLink>) => (
    <div className="space-y-4">
      <UI.NamespaceLink {...args} />
      <UI.NamespaceNavLink to="/">
        Активная namespace-ссылка
      </UI.NamespaceNavLink>
      <UI.SwitcherLink to="/settings">Обычная router-ссылка</UI.SwitcherLink>
      <LocationReadout />
    </div>
  );
  return render(args);
}
