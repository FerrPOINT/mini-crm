import { QueryState } from "@pdlc/ui/ui";
import type { ComponentProps } from "react";

export default function Example(
  props: Partial<ComponentProps<typeof QueryState>>,
) {
  return (
    <QueryState
      {...props}
      data={undefined}
      isLoading
      error={null}
      scope={props.scope ?? "local"}
    >
      Подтверждённые данные блока
    </QueryState>
  );
}
