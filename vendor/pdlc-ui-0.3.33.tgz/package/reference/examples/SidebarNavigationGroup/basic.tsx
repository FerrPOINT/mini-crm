import * as UI from "@pdlc/ui/ui";
import { type ComponentProps, useEffect, useState } from "react";

function useExampleValue<T>(value: T) {
  const [current, setCurrent] = useState(value);
  useEffect(() => setCurrent(value), [value]);
  return [current, setCurrent] as const;
}

export function ControlledSidebarGroup(
  args: ComponentProps<typeof UI.SidebarNavigationGroup>,
) {
  const [open, setOpen] = useExampleValue(args.open);
  return (
    <UI.SidebarNavigationGroup
      {...args}
      open={open}
      onOpenChange={(value) => {
        setOpen(value);
        args.onOpenChange(value);
      }}
    />
  );
}

export default function Example() {
  const args = {
    label: "Рабочее пространство",
    open: true,
    onOpenChange: () => {},
    children: (
      <>
        <UI.SidebarItem>Обзор</UI.SidebarItem>
        <UI.SidebarItem>Настройки</UI.SidebarItem>
      </>
    ),
  } satisfies ComponentProps<typeof UI.SidebarNavigationGroup>;
  const render = (args: ComponentProps<typeof UI.SidebarNavigationGroup>) => (
    <ControlledSidebarGroup {...args} />
  );
  return render(args);
}
