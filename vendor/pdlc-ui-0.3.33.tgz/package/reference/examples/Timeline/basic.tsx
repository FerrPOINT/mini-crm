import {
  Badge,
  Disclosure,
  TextLink,
  Timeline,
  TimelineContent,
  TimelineItem,
  TimelineMarker,
} from "@pdlc/ui/ui";

export default function TimelineExample() {
  return (
    <Timeline aria-label="История проверок">
      <TimelineItem>
        <TimelineMarker tone="success" />
        <TimelineContent>
          <Badge tone="success">Проверено</Badge>
          <p>Проверка завершена. Её результат задаёт владелец данных.</p>
        </TimelineContent>
      </TimelineItem>
      <TimelineItem>
        <TimelineMarker tone="warning" />
        <TimelineContent asChild>
          <Disclosure appearance="row" summary="Требуется уточнение">
            <p>
              Длинный отчёт с идентификатором {"resource_".repeat(18)} доступен
              без горизонтального прокручивания страницы.
            </p>
            <TextLink href="#timeline-notes">К пояснению</TextLink>
          </Disclosure>
        </TimelineContent>
      </TimelineItem>
      <TimelineItem>
        <TimelineMarker tone="info" current />
        <TimelineContent>
          <Badge tone="info">Текущая проверка</Badge>
          <p id="timeline-notes">
            Текущий этап передан приложением; библиотека не запускает следующую
            проверку.
          </p>
        </TimelineContent>
      </TimelineItem>
    </Timeline>
  );
}
