import {
  Badge,
  Timeline,
  TimelineContent,
  TimelineItem,
  TimelineMarker,
} from "@pdlc/ui/ui";

export default function TimelineStepsExample() {
  return (
    <Timeline appearance="steps" aria-label="История этапов">
      <TimelineItem>
        <TimelineMarker tone="success" />
        <TimelineContent>
          <Badge tone="success">Завершён</Badge>
          <p>Последовательный этап</p>
        </TimelineContent>
      </TimelineItem>
      <TimelineItem>
        <TimelineMarker tone="info" size="large" current />
        <TimelineContent>
          <Badge tone="info">Текущий</Badge>
          <p>Группа из двух параллельных этапов</p>
        </TimelineContent>
      </TimelineItem>
      <TimelineItem>
        <TimelineMarker />
        <TimelineContent>
          <Badge tone="muted">Ожидает</Badge>
          <p>Следующий этап</p>
        </TimelineContent>
      </TimelineItem>
    </Timeline>
  );
}
