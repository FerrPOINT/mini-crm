import * as UI from "@pdlc/ui/ui";
import { Link } from "react-router";
import { type ComponentProps } from "react";

export default function Example() {
  const args = {
    "aria-label": "Разделы",
    children: (
      <>
        <UI.SectionNavigationItem asChild active>
          <Link to="/overview">Обзор</Link>
        </UI.SectionNavigationItem>
        <UI.SectionNavigationItem asChild>
          <Link to="/settings">Настройки</Link>
        </UI.SectionNavigationItem>
      </>
    ),
  } satisfies ComponentProps<typeof UI.SectionNavigation>;
  const render = (args: ComponentProps<typeof UI.SectionNavigation>) => (
    <UI.SectionNavigation {...args} />
  );
  return render(args);
}
