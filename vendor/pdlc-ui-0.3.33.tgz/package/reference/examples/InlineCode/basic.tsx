// Setup: @pdlc/ui/tokens.css
import { InlineCode } from "@pdlc/ui/ui";

export default function BasicExample() {
  return (
    <p>
      Идентификатор <InlineCode>revision_7</InlineCode> и путь{" "}
      <InlineCode>src/platform/host.ts</InlineCode> отображаются как текст.
    </p>
  );
}
