import { ResourceStateView } from "@pdlc/ui/ui";
import type { ComponentProps } from "react";

export default function Example(
  props: Partial<ComponentProps<typeof ResourceStateView>>,
) {
  return (
    <ResourceStateView
      {...props}
      scope={props.scope ?? "local"}
      state={
        props.state ?? { kind: "loading", message: "Читаем метаданные блока…" }
      }
    />
  );
}
