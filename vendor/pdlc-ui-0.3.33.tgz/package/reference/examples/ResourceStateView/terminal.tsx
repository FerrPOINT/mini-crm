import { useState } from "react";
import { FileQuestion, ShieldAlert } from "lucide-react";
import { Button, RadioGroup, ResourceStateView } from "@pdlc/ui/ui";

/** Synthetic presentation only: the product still checks access and owns navigation. */
export default function Example() {
  const [kind, setKind] = useState("permission-denied");
  const [returns, setReturns] = useState(0);
  const missing = kind === "not-found";
  return (
    <div className="base-page-stack">
      <RadioGroup
        label="Состояние ресурса"
        value={kind}
        onValueChange={setKind}
        appearance="segmented"
        options={[
          { value: "permission-denied", label: "Нет доступа" },
          { value: "not-found", label: "Не найден" },
        ]}
      />
      <ResourceStateView
        state={{
          kind: missing ? "not-found" : "permission-denied",
          title: missing ? "Ресурс не найден" : "Доступ запрещён",
          headingLevel: 1,
          icon: missing ? <FileQuestion /> : <ShieldAlert />,
          message: missing
            ? "Проверьте ссылку или вернитесь к доступным ресурсам."
            : "Права на ресурс определяет продукт. Изменение оформления не предоставляет доступ.",
          back: (
            <Button
              variant="outline"
              onClick={() => setReturns((value) => value + 1)}
            >
              К доступным ресурсам
            </Button>
          ),
        }}
      />
      <p role="status">Вызов действия возврата: {returns}</p>
    </div>
  );
}
