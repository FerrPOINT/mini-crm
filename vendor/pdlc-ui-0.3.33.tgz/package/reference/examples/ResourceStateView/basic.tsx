import * as UI from "@pdlc/ui/ui";
import { type ComponentProps } from "react";

export default function Example() {
  const args = {
    state: { kind: "loading", message: "Загружаем ресурс…" },
  } satisfies ComponentProps<typeof UI.ResourceStateView>;
  const render = (args: ComponentProps<typeof UI.ResourceStateView>) => (
    <UI.ResourceStateView {...args} />
  );
  return render(args);
}
