import { useState } from "react";
import {
  Button,
  Card,
  CardContent,
  ResourceStateView,
  resourceErrorState,
  type ResourceState,
} from "@pdlc/ui/ui";
import { ApiError } from "@pdlc/ui/lib";

/** Synthetic read results only: no network, authorization changes or cache writes. */
export default function Example() {
  const [state, setState] = useState<ResourceState>({ kind: "ready" });
  const restore = () => setState({ kind: "ready" });
  const simulate = (status: number) =>
    setState(
      resourceErrorState(
        new ApiError(status, "Synthetic read failure"),
        restore,
        { hasData: true },
      ),
    );
  return (
    <div className="grid gap-4">
      <div className="flex flex-wrap gap-2">
        <Button onClick={restore}>Данные подтверждены</Button>
        <Button variant="outline" onClick={() => simulate(503)}>
          Временный сбой
        </Button>
        <Button variant="outline" onClick={() => simulate(403)}>
          Доступ отозван
        </Button>
      </div>
      <ResourceStateView state={state} scope="local">
        <Card>
          <CardContent>Последние подтверждённые данные</CardContent>
        </Card>
      </ResourceStateView>
    </div>
  );
}
