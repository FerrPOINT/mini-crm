import * as UI from "@pdlc/ui/ui";
export default function Example() {
  const render = () => <UI.ThemeToggle />;
  return render();
}
