import * as UI from "@pdlc/ui/ui";
import { type ComponentProps } from "react";

export default function Example() {
  const args = {
    currentKey: "wiki",
    showCurrentLabel: true,
  } satisfies ComponentProps<typeof UI.ServiceSwitcher>;
  const render = (args: ComponentProps<typeof UI.ServiceSwitcher>) => (
    <UI.ServiceSwitcher {...args} />
  );
  return render(args);
}
