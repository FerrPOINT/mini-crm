// Setup: @pdlc/ui/tokens.css
import { ContentSection, SectionHeader, Prose } from "@pdlc/ui/ui";

export default function BasicExample() {
  return (
    <ContentSection
      aria-labelledby="content-section-heading"
      className="space-y-3"
    >
      <SectionHeader headingId="content-section-heading" title="Сведения" />
      <Prose>
        <p>
          Содержание и состояния передаёт приложение. Разделитель и внутренний
          отступ следуют брендингу Base.
        </p>
      </Prose>
    </ContentSection>
  );
}
