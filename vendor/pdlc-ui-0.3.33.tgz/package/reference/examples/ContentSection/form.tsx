// Setup: @pdlc/ui/tokens.css
import { useState } from "react";
import { Button, ContentSection, FormField, Input, Notice } from "@pdlc/ui/ui";

export default function FormExample() {
  const [query, setQuery] = useState("");
  const [applied, setApplied] = useState<string | null>(null);
  return (
    <>
      <ContentSection asChild dividers="both" className="grid gap-3">
        <form
          aria-label="Фильтры локального примера"
          onSubmit={(event) => {
            event.preventDefault();
            setApplied(query);
          }}
        >
          <FormField id="content-section-query" label="Запрос" required>
            {(props) => (
              <Input
                {...props}
                name="query"
                value={query}
                onChange={(event) => setQuery(event.target.value)}
              />
            )}
          </FormField>
          <div>
            <Button type="submit">Применить</Button>
          </div>
        </form>
      </ContentSection>
      {applied !== null && (
        <Notice appearance="inline" role="status">
          В памяти: {applied}
        </Notice>
      )}
    </>
  );
}
