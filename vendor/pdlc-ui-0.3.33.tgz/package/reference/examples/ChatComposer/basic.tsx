import { useState } from "react";
import { ShieldCheck } from "lucide-react";
import {
  Button,
  ChatComposer,
  ChatComposerActions,
  Label,
  Notice,
  Textarea,
} from "@pdlc/ui/ui";

export default function ComposerExample({
  readOnly = false,
  blocked = false,
  pending = false,
  error = false,
  long = false,
}: {
  readOnly?: boolean;
  blocked?: boolean;
  pending?: boolean;
  error?: boolean;
  long?: boolean;
}) {
  const [draft, setDraft] = useState("");
  const [sent, setSent] = useState(0);
  const [held, setHeld] = useState(blocked);
  if (readOnly)
    return (
      <ChatComposer aria-label="История без отправки">
        <Notice appearance="inline" tone="neutral" role="status">
          История доступна только для чтения.
        </Notice>
        <ChatComposerActions>
          <Button asChild variant="outline">
            <a href="#new-conversation">Перейти к новому разговору</a>
          </Button>
        </ChatComposerActions>
      </ChatComposer>
    );
  return (
    <ChatComposer asChild>
      <form
        aria-label="Локальная форма сообщения"
        aria-busy={pending || undefined}
        onSubmit={(event) => {
          event.preventDefault();
          if (!held && !pending && draft.trim()) {
            setSent((count) => count + 1);
            setDraft("");
          }
        }}
      >
        <Label htmlFor="composer-message">Сообщение</Label>
        <Textarea
          id="composer-message"
          name="body"
          value={draft}
          onChange={(event) => setDraft(event.target.value)}
          disabled={pending}
          rows={2}
        />
        {(held || error) && (
          <Notice appearance="inline" tone="warning" role="alert">
            Исход отправки неизвестен. Сначала выполните сверку; черновик
            сохранён.
          </Notice>
        )}
        <ChatComposerActions
          hint={
            <>
              <ShieldCheck size={14} aria-hidden />
              {long
                ? "Длинное пояснение к доступности отправки ".repeat(8)
                : "Синтетическая форма без API"}
            </>
          }
        >
          <Button type="submit" disabled={held || pending || !draft.trim()}>
            {pending ? "Отправка…" : "Отправить"}
          </Button>
          <Button
            type="button"
            variant="outline"
            onClick={() => setHeld(!held)}
          >
            {held ? "Сверить результат" : "Показать неизвестный исход"}
          </Button>
        </ChatComposerActions>
        <Notice appearance="inline" tone="neutral" role="status">
          Локальных отправок: {sent}. Доставка и сохранение принадлежат
          продукту.
        </Notice>
      </form>
    </ChatComposer>
  );
}
