import { useState } from "react";
import { ThemeProvider, useTheme, type ThemeProviderProps } from "@pdlc/ui/lib";
import { ThemeToggle } from "@pdlc/ui/ui";

type Theme = NonNullable<ThemeProviderProps["theme"]>;

function CurrentTheme() {
  const { theme } = useTheme();
  return <p role="status">Изолированная тема: {theme}</p>;
}

export default function BasicExample({
  initialTheme = "light",
}: {
  initialTheme?: Theme;
}) {
  const [theme, setTheme] = useState<Theme>(initialTheme);
  return (
    <ThemeProvider theme={theme} onThemeChange={setTheme}>
      <div className="space-y-4 p-4">
        <CurrentTheme />
        <ThemeToggle />
      </div>
    </ThemeProvider>
  );
}
