import { useId, useState } from "react";
import { Button, Checkbox, Fieldset, Radio } from "@pdlc/ui/ui";

/** Synthetic choices only: the consumer owns values and any eventual save. */
export default function ChoiceCardsExample() {
  const groupName = useId();
  const [enabled, setEnabled] = useState(false);
  const [mode, setMode] = useState("one");
  return (
    <form
      className="base-page-stack"
      onSubmit={(event) => event.preventDefault()}
      onReset={() => {
        setEnabled(false);
        setMode("one");
      }}
    >
      <Fieldset legend="Несколько независимых вариантов" className="grid gap-2">
        <Checkbox
          appearance="card"
          name="option"
          value="enabled"
          checked={enabled}
          onCheckedChange={(value) => setEnabled(value === true)}
        >
          <strong className="block">Дополнительный вариант</strong>
          <span className="block">
            Описание входит в доступное имя и область выбора.
          </span>
        </Checkbox>
        <Checkbox appearance="card" label="Недоступный вариант" disabled />
      </Fieldset>
      <Fieldset legend="Один вариант" className="grid gap-2 sm:grid-cols-2">
        {[
          {
            value: "one",
            label: "Основной",
            description: "Выбран по умолчанию.",
          },
          {
            value: "two",
            label: "Другой",
            description: "Выбор не отправляет форму.",
          },
        ].map((option) => (
          <Radio
            key={option.value}
            appearance="card"
            name={groupName}
            value={option.value}
            checked={mode === option.value}
            required
            onCheckedChange={() => setMode(option.value)}
          >
            <strong className="block">{option.label}</strong>
            <span className="block">{option.description}</span>
          </Radio>
        ))}
      </Fieldset>
      <output aria-live="polite">
        Выбрано: {mode}; дополнительный вариант: {enabled ? "да" : "нет"}.
      </output>
      <Button type="reset" variant="outline">
        Сбросить выбор
      </Button>
    </form>
  );
}
