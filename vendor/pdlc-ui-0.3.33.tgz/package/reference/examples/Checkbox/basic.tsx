import { useState } from "react";
import { Checkbox, Radio, RadioGroup, Switch } from "@pdlc/ui/ui";
export default function Example() {
  const [checked, setChecked] = useState<boolean | "indeterminate">(
    "indeterminate",
  );
  const [enabled, setEnabled] = useState(false);
  return (
    <form className="base-page-stack">
      <Checkbox
        label="Выбрать строку"
        name="selected"
        checked={checked}
        onCheckedChange={setChecked}
      />
      <Switch
        label="Включить уведомления"
        name="notifications"
        checked={enabled}
        onCheckedChange={setEnabled}
      />
      <RadioGroup
        label="Приоритет"
        name="priority"
        defaultValue="normal"
        options={[
          { value: "normal", label: "Обычный" },
          { value: "high", label: "Высокий" },
          { value: "blocked", label: "Недоступно", disabled: true },
        ]}
      />
      <Radio name="rich" value="one">
        Вариант с дополнительным содержимым
      </Radio>
    </form>
  );
}
