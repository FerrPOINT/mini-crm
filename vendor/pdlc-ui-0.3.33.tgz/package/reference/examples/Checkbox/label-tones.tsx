import { Checkbox, Fieldset, Radio, Switch } from "@pdlc/ui/ui";

export default function Example() {
  return (
    <form className="base-page-stack">
      <Fieldset legend="Контекст подписи" className="grid gap-3">
        <Checkbox name="normal" label="Обычный выбор" />
        <Checkbox
          name="secondary"
          labelTone="secondary"
          label="Второстепенный фильтр"
        />
        <Checkbox name="saved" defaultChecked labelTone="danger">
          Сохранённый вариант сейчас недоступен; выбор можно снять.
        </Checkbox>
        <Switch
          name="switch"
          labelTone="secondary"
          label="Дополнительная настройка"
        />
        <Radio name="radio" value="saved" appearance="card" labelTone="danger">
          Контекст варианта не меняет смысл radio и не делает поле invalid.
        </Radio>
      </Fieldset>
      <Fieldset legend="Недоступные действия" disabled>
        <Checkbox
          labelTone="danger"
          defaultChecked
          label="Недоступный сохранённый выбор"
        />
      </Fieldset>
    </form>
  );
}
