import { Button, PageHeader } from "@pdlc/ui/ui";

/** Context belongs to the product; wrapping and action layout belong to Base. */
export default function LongContextExample() {
  return (
    <PageHeader
      title="Подключённый проект"
      context={
        "https://example.test/projects/" +
        "long-project-identifier-without-spaces-".repeat(5)
      }
      actions={<Button variant="outline">Настройки</Button>}
    />
  );
}
