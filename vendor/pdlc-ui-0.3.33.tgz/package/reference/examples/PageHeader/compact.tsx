import { Badge, PageHeader } from "@pdlc/ui/ui";

export default function CompactExample() {
  return (
    <div className="max-w-sm">
      <PageHeader
        title="Обсуждение внутренней страницы состояния сервиса и ручной проверки доступности"
        titleAppearance="compact"
        leading={<Badge>PM</Badge>}
      />
    </div>
  );
}
