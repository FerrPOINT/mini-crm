import { useRef } from "react";
import { Button, PageHeader } from "@pdlc/ui/ui";

/** Synthetic recovery action; the caller chooses when to restore focus. */
export default function FocusExample() {
  const heading = useRef<HTMLHeadingElement>(null);
  return (
    <PageHeader
      title="Документ после завершения действия"
      headingRef={heading}
      headingTabIndex={-1}
      context="Заголовок получает фокус только по явному действию."
      actions={
        <Button onClick={() => heading.current?.focus()}>
          Вернуть фокус на заголовок
        </Button>
      }
    />
  );
}
