import { useState } from "react";
import {
  Badge,
  Button,
  ChatMessage,
  Notice,
  Prose,
  ResourceListDescription,
  ResourceListTitle,
  UserAvatar,
} from "@pdlc/ui/ui";

export default function MessageExample({
  long = false,
  error = false,
  noAvatar = false,
}: {
  long?: boolean;
  error?: boolean;
  noAvatar?: boolean;
}) {
  const [fragments, setFragments] = useState(0);
  return (
    <ChatMessage
      aria-label="Синтетическое сообщение"
      avatar={
        noAvatar ? undefined : (
          <UserAvatar name="Автор" userId="example-author" />
        )
      }
      header={
        <>
          <ResourceListTitle asChild>
            <strong>{long ? "Длинное имя автора ".repeat(8) : "Автор"}</strong>
          </ResourceListTitle>
          <ResourceListDescription asChild>
            <time dateTime="2026-10-26T10:00:00Z">10:00</time>
          </ResourceListDescription>
          <Badge appearance="inline" tone={error ? "danger" : "success"}>
            {error ? "Ошибка доставки" : "Подтверждено"}
          </Badge>
        </>
      }
    >
      <Prose>
        <p>
          {long
            ? "message_".repeat(60)
            : "Содержимое сообщения и обработчики предоставляет приложение."}
        </p>
        <p aria-live="polite">Добавлено фрагментов: {fragments}</p>
      </Prose>
      {error && (
        <Notice appearance="inline" tone="danger" role="alert">
          Ошибка передана владельцем; автоматического повтора нет.
        </Notice>
      )}
      <div>
        <Button
          variant="outline"
          onClick={() => setFragments((count) => count + 1)}
        >
          Добавить фрагмент
        </Button>
      </div>
    </ChatMessage>
  );
}
