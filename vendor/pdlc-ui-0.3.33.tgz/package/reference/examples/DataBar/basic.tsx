// Setup: @pdlc/ui/tokens.css
import { DataBar, Prose } from "@pdlc/ui/ui";

export default function BasicExample() {
  return (
    <div className="space-y-3">
      <Prose>
        <p>
          6 успешных, 3 с ошибкой, 1 прочий результат. Это статическая сводка
          данных.
        </p>
      </Prose>
      <DataBar
        max={10}
        label="Распределение: 6 успешных, 3 с ошибкой, 1 прочий"
        segments={[
          { id: "success", value: 6, tone: "success" },
          { id: "failed", value: 3, tone: "danger" },
          { id: "other", value: 1, tone: "muted" },
        ]}
      />
    </div>
  );
}
