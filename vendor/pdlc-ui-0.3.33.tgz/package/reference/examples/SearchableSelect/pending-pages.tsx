import { useEffect, useState } from "react";
import { Checkbox, SearchableSelect } from "@pdlc/ui/ui";

const catalog = Array.from({ length: 6 }, (_, index) => ({
  value: String(index + 1),
  label: `Ресурс ${index + 1}`,
}));

/** A local read adapter demonstrates latency and failure without network requests. */
export default function PendingPagesExample({
  delayMs = 700,
  searchable = true,
}: {
  delayMs?: number;
  searchable?: boolean;
}) {
  const [value, setValue] = useState("5");
  const [search, setSearch] = useState("");
  const [offset, setOffset] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string>();
  const [failNext, setFailNext] = useState(false);
  const [request, setRequest] = useState<{ fail: boolean } | null>(null);
  const [reads, setReads] = useState(0);
  const [changes, setChanges] = useState(0);
  const filtered = catalog.filter((option) =>
    option.label.toLowerCase().includes(search.toLowerCase()),
  );
  useEffect(() => {
    if (!request) return;
    const timer = window.setTimeout(() => {
      setLoading(false);
      setError(request.fail ? "Каталог временно недоступен" : undefined);
      setRequest(null);
    }, delayMs);
    return () => window.clearTimeout(timer);
  }, [request, delayMs]);
  function read(nextOffset: number, query = search) {
    setOffset(nextOffset);
    setSearch(query);
    setLoading(true);
    setError(undefined);
    setRequest({ fail: failNext });
    setFailNext(false);
    setReads((count) => count + 1);
  }
  return (
    <section aria-label="Переходы каталога" className="grid min-w-0 gap-4">
      <Checkbox
        label="Следующее чтение с ошибкой"
        checked={failNext}
        onCheckedChange={(checked) => setFailNext(checked === true)}
      />
      <SearchableSelect
        label="Ресурс"
        placeholder="Все ресурсы"
        value={value}
        selectedLabel={catalog.find((option) => option.value === value)?.label}
        options={loading || error ? [] : filtered.slice(offset, offset + 2)}
        search={search}
        onSearch={searchable ? (query) => read(0, query) : undefined}
        offset={offset}
        pageSize={2}
        total={filtered.length}
        onPage={(nextOffset) => read(nextOffset)}
        onChange={(nextValue) => {
          setValue(nextValue);
          setChanges((count) => count + 1);
        }}
        loading={loading}
        error={error}
        onRetry={() => read(offset)}
      />
      <output aria-live="polite">
        Чтений: {reads}. Изменений выбора: {changes}. Значение:{" "}
        {value || "ничего"}.
      </output>
    </section>
  );
}
