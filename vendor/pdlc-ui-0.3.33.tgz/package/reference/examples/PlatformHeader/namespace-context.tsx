import { useState } from "react";
import { Menu, UserRound } from "lucide-react";
import { BrandingScope, defaultDesign } from "@pdlc/ui/branding";
import { defaultBranding, useTheme } from "@pdlc/ui/lib";
import { Button, NamespacePicker, PlatformHeader } from "@pdlc/ui/ui";

export default function NamespaceContext() {
  const { theme } = useTheme();
  const [namespace, setNamespace] = useState("BASE");
  return (
    <BrandingScope
      theme={theme}
      value={{
        ...defaultBranding,
        design: {
          ...defaultDesign,
          type_scale: "large",
          density: "comfortable",
        },
      }}
    >
      <PlatformHeader
        currentServiceKey="wiki"
        leading={
          <Button variant="ghost" size="icon" aria-label="Навигация">
            <Menu aria-hidden />
          </Button>
        }
        context={
          <NamespacePicker
            value={namespace}
            onChange={setNamespace}
            options={[
              { value: "BASE", label: "Платформа" },
              { value: "DOCS", label: "Документация" },
            ]}
          />
        }
        actions={
          <Button variant="ghost" size="icon" aria-label="Аккаунт">
            <UserRound aria-hidden />
          </Button>
        }
      />
      <output>Выбрано: {namespace}</output>
    </BrandingScope>
  );
}
