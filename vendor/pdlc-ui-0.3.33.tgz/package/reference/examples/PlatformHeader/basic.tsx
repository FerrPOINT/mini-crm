import * as UI from "@pdlc/ui/ui";
import { type ComponentProps } from "react";

export default function Example() {
  const args = {
    currentServiceKey: "wiki",
    leading: <UI.PlatformMark withName size="sm" />,
    context: <span>Пример пространства</span>,
    actions: <UI.ThemeToggle />,
  } satisfies ComponentProps<typeof UI.PlatformHeader>;
  const render = (args: ComponentProps<typeof UI.PlatformHeader>) => (
    <UI.PlatformHeader {...args} />
  );
  return render(args);
}
