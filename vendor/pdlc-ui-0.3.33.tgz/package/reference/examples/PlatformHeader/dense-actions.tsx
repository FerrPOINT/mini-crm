import { useState } from "react";
import { Bell, Menu, Plus, UserRound } from "lucide-react";
import { BrandingScope, defaultDesign } from "@pdlc/ui/branding";
import { defaultBranding, useMediaQuery, useTheme } from "@pdlc/ui/lib";
import { Button, PlatformHeader } from "@pdlc/ui/ui";

export default function DenseActions() {
  const { theme } = useTheme();
  const showCreateLabel = useMediaQuery("(min-width: 1280px)");
  const [actions, setActions] = useState(0);
  const activate = () => setActions((count) => count + 1);
  return (
    <BrandingScope
      theme={theme}
      value={{
        ...defaultBranding,
        design: {
          ...defaultDesign,
          type_scale: "large",
          density: "comfortable",
        },
      }}
    >
      <PlatformHeader
        currentServiceKey="task-tracker"
        leading={
          <Button
            variant="ghost"
            size="icon"
            aria-label="Открыть навигацию"
            onClick={activate}
          >
            <Menu aria-hidden />
          </Button>
        }
        context={<span className="hidden md:block">Контекст проекта</span>}
        actions={
          <>
            <Button
              size={showCreateLabel ? "sm" : "icon"}
              aria-label="Создать"
              onClick={activate}
            >
              <Plus aria-hidden className="h-4 w-4" />
              <span className="hidden xl:inline">Создать</span>
            </Button>
            <Button
              variant="ghost"
              size="icon"
              aria-label="Уведомления"
              onClick={activate}
            >
              <Bell aria-hidden />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              aria-label="Аккаунт"
              onClick={activate}
            >
              <UserRound aria-hidden />
            </Button>
          </>
        }
      />
      <p role="status">Действий в примере: {actions}</p>
    </BrandingScope>
  );
}
