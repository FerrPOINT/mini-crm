import {
  Badge,
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  DescriptionItem,
  DetailPage,
} from "@pdlc/ui/ui";

export default function DetailRecipe() {
  return (
    <DetailPage
      title="Платформа"
      context="Подробности демонстрационного ресурса"
      aside={
        <Card>
          <CardHeader>
            <CardTitle aria-level={2}>Состояние</CardTitle>
          </CardHeader>
          <CardContent>
            <Badge tone="success">Доступен</Badge>
          </CardContent>
        </Card>
      }
    >
      <dl className="space-y-4">
        <DescriptionItem label="Ключ">BASE</DescriptionItem>
        <DescriptionItem label="Описание">
          Общие компоненты платформы
        </DescriptionItem>
      </dl>
    </DetailPage>
  );
}
