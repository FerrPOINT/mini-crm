import { useState } from "react";
import {
  EmptyState,
  FormField,
  Input,
  ListPage,
  ResourceList,
  ResourceListRow,
} from "@pdlc/ui/ui";

const resources = [
  { id: "base", name: "Платформа" },
  { id: "docs", name: "Документация" },
];
export default function ListRecipe() {
  const [search, setSearch] = useState("");
  const items = resources.filter((item) =>
    item.name.toLowerCase().includes(search.toLowerCase()),
  );
  return (
    <ListPage
      title="Ресурсы"
      filters={
        <FormField id="recipe-filter" label="Поиск">
          {(attrs) => (
            <Input
              {...attrs}
              type="search"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
            />
          )}
        </FormField>
      }
    >
      {items.length ? (
        <ResourceList asChild>
          <ul>
            {items.map((item) => (
              <ResourceListRow key={item.id} asChild>
                <li>{item.name}</li>
              </ResourceListRow>
            ))}
          </ul>
        </ResourceList>
      ) : (
        <EmptyState
          message="Ничего не найдено"
          description="Измените поисковый запрос"
        />
      )}
    </ListPage>
  );
}
