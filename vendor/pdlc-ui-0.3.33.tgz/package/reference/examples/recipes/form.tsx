import { useState } from "react";
import { Button, FormField, FormPage, Input } from "@pdlc/ui/ui";

export default function FormRecipe() {
  const [name, setName] = useState("");
  const [error, setError] = useState("");
  const [saved, setSaved] = useState("");
  return (
    <FormPage
      title="Новый ресурс"
      onSubmit={(event) => {
        event.preventDefault();
        if (!name.trim()) {
          setError("Укажите название");
          return;
        }
        setError("");
        setSaved(name.trim());
      }}
      actions={<Button type="submit">Сохранить локально</Button>}
    >
      <FormField id="recipe-name" label="Название" error={error} required>
        {(attrs) => (
          <Input
            {...attrs}
            value={name}
            onChange={(event) => setName(event.target.value)}
          />
        )}
      </FormField>
      {saved && <p role="status">Сохранено в памяти примера: {saved}</p>}
    </FormPage>
  );
}
