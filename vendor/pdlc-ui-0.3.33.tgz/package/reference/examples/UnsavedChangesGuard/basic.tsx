import * as UI from "@pdlc/ui/ui";
import {
  type ComponentProps,
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import { createMemoryRouter, Link, RouterProvider } from "react-router";

const GuardEnabled = createContext(true);
function DraftEditor() {
  const enabled = useContext(GuardEnabled);
  const [text, setText] = useState("Черновик проекта");
  const [saved, setSaved] = useState(text);
  return (
    <div className="space-y-4">
      <UI.UnsavedChangesGuard when={enabled && text !== saved} />
      <UI.FormField id="draft" label="Черновик">
        {(attrs) => (
          <UI.Textarea
            {...attrs}
            value={text}
            onChange={(event) => setText(event.target.value)}
          />
        )}
      </UI.FormField>
      <UI.ActionGroup align="start">
        <UI.Button disabled={text === saved} onClick={() => setSaved(text)}>
          Сохранить локально
        </UI.Button>
        <UI.Button asChild variant="outline">
          <Link to="/next">Перейти дальше</Link>
        </UI.Button>
      </UI.ActionGroup>
      <output>
        {text === saved
          ? "Правки подтверждены локально"
          : "Есть несохранённые правки"}
      </output>
    </div>
  );
}

export function UnsavedDemo({ enabled }: { enabled: boolean }) {
  const router = useMemo(
    () =>
      createMemoryRouter([
        { path: "/", element: <DraftEditor /> },
        {
          path: "/next",
          element: (
            <div className="space-y-4">
              <p>Следующая локальная страница</p>
              <Link to="/">Вернуться к редактору</Link>
            </div>
          ),
        },
      ]),
    [],
  );
  useEffect(() => () => router.dispose(), [router]);
  return (
    <GuardEnabled.Provider value={enabled}>
      <RouterProvider router={router} />
    </GuardEnabled.Provider>
  );
}

export default function Example() {
  const args = { when: true } satisfies ComponentProps<
    typeof UI.UnsavedChangesGuard
  >;
  const render = (args: ComponentProps<typeof UI.UnsavedChangesGuard>) => (
    <UnsavedDemo enabled={args.when} />
  );
  return render(args);
}
