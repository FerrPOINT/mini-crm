import * as UI from "@pdlc/ui/ui";
import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import {
  createMemoryRouter,
  Link,
  RouterProvider,
  useNavigate,
} from "react-router";

const GuardEnabled = createContext(true);
function Draft() {
  const enabled = useContext(GuardEnabled);
  const navigate = useNavigate();
  const [text, setText] = useState("Изменённый черновик");
  const [saved, setSaved] = useState("Подтверждённый черновик");
  const [pending, setPending] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(
    () => () => {
      if (timer.current !== null) clearTimeout(timer.current);
    },
    [],
  );
  function requestLeave() {
    if (timer.current !== null) return;
    const submitted = text;
    setPending(true);
    // Synthetic acknowledgment of one captured version: no API or persistence.
    timer.current = setTimeout(() => {
      timer.current = null;
      setSaved(submitted);
      setPending(false);
    }, 1500);
    void navigate("/next?case=acknowledged#result");
  }
  return (
    <div className="space-y-4">
      <UI.UnsavedChangesGuard when={enabled && text !== saved} />
      <UI.Notice tone="info">
        Локальный таймер подтверждает отправленную версию через 1,5 секунды.
        Сети и записи нет. Отмена ухода не возобновляется поздним ответом; новые
        правки остаются защищены.
      </UI.Notice>
      <UI.FormField id="pending-draft" label="Черновик">
        {(attrs) => (
          <UI.Textarea
            {...attrs}
            value={text}
            onChange={(event) => setText(event.target.value)}
          />
        )}
      </UI.FormField>
      <UI.ActionGroup align="start">
        <UI.Button disabled={pending || text === saved} onClick={requestLeave}>
          Уйти и получить подтверждение
        </UI.Button>
      </UI.ActionGroup>
      <output aria-live="polite">
        {pending
          ? "Ожидается синтетическое подтверждение"
          : text === saved
            ? "Текущая версия подтверждена"
            : "Есть несохранённые правки"}
      </output>
    </div>
  );
}

export function PendingLeaveDemo({ enabled = true }: { enabled?: boolean }) {
  const router = useMemo(
    () =>
      createMemoryRouter([
        { path: "/", element: <Draft /> },
        {
          path: "/next",
          element: (
            <div className="space-y-4">
              <UI.Notice tone="info" title="Исходный переход выполнен">
                Открыта следующая страница синтетического примера. Данные никуда
                не отправлялись.
              </UI.Notice>
              <UI.Button asChild variant="outline">
                <Link to="/">Вернуться к примеру</Link>
              </UI.Button>
            </div>
          ),
        },
      ]),
    [],
  );
  useEffect(() => () => router.dispose(), [router]);
  return (
    <GuardEnabled.Provider value={enabled}>
      <RouterProvider router={router} />
    </GuardEnabled.Provider>
  );
}
export default function Example() {
  return <PendingLeaveDemo />;
}
