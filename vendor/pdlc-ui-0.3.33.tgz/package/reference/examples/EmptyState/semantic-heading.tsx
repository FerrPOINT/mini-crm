import { useState } from "react";
import { Button, EmptyState, Notice } from "@pdlc/ui/ui";

export default function SemanticHeadingExample() {
  const [filtered, setFiltered] = useState(true);
  return filtered ? (
    <EmptyState
      headingLevel={2}
      message="Компоненты не найдены"
      description="Измените запрос или сбросьте фильтр. Действие этого примера работает в памяти."
      action={
        <Button onClick={() => setFiltered(false)}>Сбросить фильтр</Button>
      }
    />
  ) : (
    <Notice tone="success" role="status">
      Фильтр сброшен
    </Notice>
  );
}
