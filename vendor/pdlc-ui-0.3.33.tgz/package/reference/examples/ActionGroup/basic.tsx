import { useState } from "react";
import {
  ActionGroup,
  Button,
  Input,
  Label,
  Notice,
  ResourceListDescription,
} from "@pdlc/ui/ui";

export default function ActionGroupExample({
  long = false,
  disabled = false,
  pending = false,
}: {
  long?: boolean;
  disabled?: boolean;
  pending?: boolean;
}) {
  const [saved, setSaved] = useState(0);
  return (
    <form
      onSubmit={(event) => {
        event.preventDefault();
        setSaved((count) => count + 1);
      }}
    >
      <Label htmlFor="action-example-title">Название</Label>
      <Input
        id="action-example-title"
        name="title"
        defaultValue="Черновик"
        required
      />
      <ActionGroup separated stackOnMobile align="between">
        <ResourceListDescription>
          {long
            ? "Длинное пояснение: ".repeat(8)
            : "Данные только в памяти примера"}
        </ResourceListDescription>
        <ActionGroup stackOnMobile>
          <Button type="reset" variant="outline">
            Сбросить
          </Button>
          <Button
            type="submit"
            disabled={disabled || pending}
            aria-busy={pending || undefined}
          >
            {pending
              ? "Сохранение…"
              : long
                ? "Сохранить длинное название изменения"
                : "Сохранить"}
          </Button>
        </ActionGroup>
      </ActionGroup>
      <Notice role="status" appearance="inline" tone="neutral">
        Локальных отправок: {saved}
      </Notice>
    </form>
  );
}
