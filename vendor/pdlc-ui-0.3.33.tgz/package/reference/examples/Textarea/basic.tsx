import * as UI from "@pdlc/ui/ui";
import { type ComponentProps } from "react";

export default function Example() {
  const args = {
    "aria-label": "Описание",
    placeholder: "Опишите задачу",
    rows: 5,
  } satisfies ComponentProps<typeof UI.Textarea>;
  const render = (args: ComponentProps<typeof UI.Textarea>) => (
    <UI.Textarea {...args} />
  );
  return render(args);
}
