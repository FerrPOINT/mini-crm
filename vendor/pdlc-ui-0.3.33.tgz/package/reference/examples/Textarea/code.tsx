import { FormField, Textarea } from "@pdlc/ui/ui";

export default function Example() {
  return (
    <FormField
      id="code-area"
      label="Структурированные данные"
      hint="Шрифт кода задаёт Base; разбор и сохранение выполняет приложение."
    >
      {(field) => (
        <Textarea
          {...field}
          className="font-mono min-h-32 max-h-80"
          autoSize
          rows={4}
          defaultValue={'{\n  "enabled": true,\n  "attempts": 0\n}'}
        />
      )}
    </FormField>
  );
}
