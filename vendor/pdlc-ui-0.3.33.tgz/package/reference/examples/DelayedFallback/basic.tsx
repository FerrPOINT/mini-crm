import * as UI from "@pdlc/ui/ui";
import { type ComponentProps } from "react";

export default function Example() {
  const args = {
    delayMs: 100,
    children: <UI.LoadingState message="Длительная загрузка…" />,
  } satisfies ComponentProps<typeof UI.DelayedFallback>;
  const render = (args: ComponentProps<typeof UI.DelayedFallback>) => (
    <UI.DelayedFallback {...args} />
  );
  return render(args);
}
