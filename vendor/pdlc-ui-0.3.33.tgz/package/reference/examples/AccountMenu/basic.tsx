import { useState } from "react";
import { AccountMenu, DropdownMenuItem } from "@pdlc/ui/ui";

/** Supply ThemeProvider; callbacks here change only local counters. */
export default function Example() {
  const [action, setAction] = useState("Действий ещё не было");
  return (
    <div className="grid gap-3">
      <AccountMenu
        account={{
          label: "Оператор PDLC",
          secondary: "operator@example.test",
          onLogout: () => setAction("Выход запрошен"),
        }}
        beforeTheme={
          <DropdownMenuItem onSelect={() => setAction("Открыть токены")}>
            API-токены
          </DropdownMenuItem>
        }
      >
        <DropdownMenuItem
          onSelect={() => setAction("Открыть администрирование")}
        >
          Администрирование
        </DropdownMenuItem>
      </AccountMenu>
      <output aria-live="polite">{action}</output>
    </div>
  );
}
