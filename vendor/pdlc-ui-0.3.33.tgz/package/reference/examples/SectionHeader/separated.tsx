import { useId, useState } from "react";
import { Button, SectionHeader } from "@pdlc/ui/ui";

export default function SeparatedExample() {
  const id = useId();
  const [refreshes, setRefreshes] = useState(0);
  return (
    <section aria-labelledby={id} className="min-w-0">
      <SectionHeader
        headingId={id}
        title="Ресурсы пространства"
        context={`Обновлений: ${refreshes}`}
        separated
        className="mb-4"
        actions={
          <Button variant="outline" onClick={() => setRefreshes((n) => n + 1)}>
            Обновить
          </Button>
        }
      />
      <p>
        Продукт задаёт содержание и действие. Base оформляет разделитель из
        tokens плотности.
      </p>
    </section>
  );
}
