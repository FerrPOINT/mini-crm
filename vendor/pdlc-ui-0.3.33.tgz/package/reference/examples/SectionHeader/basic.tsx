import { useState } from "react";
import {
  Badge,
  Button,
  SectionHeader,
  ResourceList,
  ResourceListRow,
} from "@pdlc/ui/ui";

export default function SectionExample() {
  const [refreshes, setRefreshes] = useState(0);
  return (
    <section aria-labelledby="example-records-title">
      <SectionHeader
        headingId="example-records-title"
        title={
          <>
            Ресурсы <Badge tone="muted">0</Badge>
          </>
        }
        context="Подтверждённо пустой синтетический список. Только локальные действия."
        actions={
          <Button variant="outline" onClick={() => setRefreshes((n) => n + 1)}>
            Обновить пример
          </Button>
        }
      />
      <ResourceList>
        <ResourceListRow>Локальных обновлений: {refreshes}</ResourceListRow>
      </ResourceList>
    </section>
  );
}
