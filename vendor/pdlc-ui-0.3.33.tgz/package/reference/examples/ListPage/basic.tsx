import * as UI from "@pdlc/ui/ui";
import { type ComponentProps } from "react";

export default function Example() {
  const args = {
    title: "Проекты",
    context: "Демонстрационный каталог команды",
    actions: <UI.Button>Создать проект</UI.Button>,
    children: (
      <UI.ResourceList>
        <UI.ResourceListRow>Платформа</UI.ResourceListRow>
        <UI.ResourceListRow>Документация</UI.ResourceListRow>
      </UI.ResourceList>
    ),
    filters: <UI.Input aria-label="Поиск проектов" placeholder="Поиск" />,
  } satisfies ComponentProps<typeof UI.ListPage>;
  const render = (args: ComponentProps<typeof UI.ListPage>) => (
    <UI.ListPage {...args} />
  );
  return render(args);
}
