import { useState } from "react";
import { PlatformQuerySession, platformQueryDefaults } from "@pdlc/ui/platform";
import { Button, FormField, Textarea, Notice } from "@pdlc/ui/ui";
function createScenario() {
  let revision = 0;
  const listeners = new Set<() => void>();
  return {
    scope: {
      getSnapshot: () => revision,
      subscribe: (listener: () => void) => {
        listeners.add(listener);
        return () => {
          listeners.delete(listener);
        };
      },
    },
    advance: () => {
      revision++;
      for (const listener of [...listeners]) listener();
    },
    createClient: () => ({
      revision,
      cache: new Map([["value", "Синтетические данные редакции " + revision]]),
      clear() {
        this.cache.clear();
      },
      isFetching: () => 0,
      getQueryCache: () => ({ getAll: () => [], subscribe: () => () => {} }),
    }),
  };
}
type Scenario = ReturnType<typeof createScenario>;
function PrivateForm({
  client,
}: {
  client: ReturnType<Scenario["createClient"]>;
}) {
  const [draft, setDraft] = useState("");
  return (
    <>
      <p role="status">{client.cache.get("value")}</p>
      <FormField id="session-draft" label="Приватный черновик">
        {(attrs) => (
          <Textarea
            {...attrs}
            value={draft}
            onChange={(event) => setDraft(event.target.value)}
          />
        )}
      </FormField>
    </>
  );
}
export default function BasicExample({
  longContent = false,
}: {
  longContent?: boolean;
}) {
  const [scenario] = useState(createScenario);
  return (
    <section className="base-page-stack">
      <Notice title="Синтетическая граница сессии">
        {longContent
          ? "Напишите длинный черновик, затем подтвердите новую версию доступа. Предыдущая форма и данные не возвращаются при смене темы или обновлении родителя."
          : "Введите черновик и смените версию доступа: форма перемонтируется."}{" "}
        Реальных token, SSO и сетевых запросов нет.
      </Notice>
      <Button onClick={scenario.advance}>Новая версия доступа</Button>
      <PlatformQuerySession
        scope={scenario.scope}
        createClient={scenario.createClient}
      >
        {(client) => <PrivateForm client={client} />}
      </PlatformQuerySession>
      <p>Повтор записи: {String(platformQueryDefaults.mutations.retry)}.</p>
    </section>
  );
}
