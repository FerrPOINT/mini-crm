# Prose: состояния

## variants

Подготовленная разметка сохраняет семантику; переносы строк включаются явно для комментариев. Stories: Default, LineBreaks, NativeParagraph, PreservedWhitespace

## sizes

Обычная и компактная типографика используют текущие tokens брендинга. Stories: Default, Compact

## disabled

Оформление текста не является control; доступность переданных ссылок принадлежит продукту.

## pending

Компонент не выполняет записи и не управляет pending.

## loading

Подготовку и чтение текста выполняет продукт; состояние показывается через ResourceStateView.

## empty

Пустое содержание и пояснение отсутствия документа определяет владелец данных.

## error

Парсер, запросы и ошибки не принадлежат компоненту оформления.

## long-content

Длинные идентификаторы переносятся; отдельная строка кода прокручивается внутри CodeBlock. Native paragraph сохраняет max-w-3xl без дополнительного wrapper. Stories: LongContent, NativeParagraph

## selection

Компонент не реализует выбор значения; обычное выделение текста сохраняется.

## keyboard

Ссылка и именованная таблица доступны с клавиатуры, внутренний скролл не требует мыши. Stories: Default, PreparedHtml

## focus

Ссылки имеют общий focus ring; смена compact не перехватывает фокус. Stories: Default, PreparedHtml

## mobile

Проверить узкую ширину и увеличение текста; нет горизонтального overflow всей страницы. Stories: LongContent, Compact
