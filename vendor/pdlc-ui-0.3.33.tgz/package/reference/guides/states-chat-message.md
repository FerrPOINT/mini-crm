# ChatMessage: состояния

## variants

Обычное сообщение и сообщение без аватара сохраняют header/body semantics. Stories: Default, WithoutAvatar

## sizes

Отдельного size нет; типографика и промежутки следуют tokens брендинга.

## disabled

Сообщение не является control. Доступность переданных действий определяет продукт.

## pending

Состояние записи/streaming передаёт продукт, общий контейнер не выполняет операции.

## loading

Чтение истории и admission не принадлежат сообщению; используйте ResourceStateView.

## empty

Пустая история относится к каталогу сообщений и показывается владельцем через EmptyState.

## error

Переданная ошибка доставки остаётся доступной, без автоматического повтора. Stories: Error

## long-content

Длинные авторы и непрерывные строки переносятся без горизонтального overflow. Stories: LongContent

## selection

Сообщение не выбирает значение; обычное выделение текста сохраняется.

## keyboard

Действие получает native keyboard focus и обновляет только локальное содержимое. Stories: Usage

## focus

Обновление фрагмента не перемещает focus и не перемонтирует переданные controls. Stories: Usage

## mobile

При узком viewport содержимое переносится под аватар и шапку на всю ширину. Stories: LongContent
