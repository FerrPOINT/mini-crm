# ChatComposer: состояния

## variants

Форма через asChild и область только для чтения без form. Stories: Default, ReadOnly

## disabled

Владелец блокирует отправку до сверки результата. Stories: Disabled

## pending

Владелец задаёт pending/disabled/aria-busy без неявной блокировки Base. Stories: Pending

## error

Ошибка передаётся Notice; ввод сохраняется, автоматического повтора нет. Stories: Error

## long-content

Длинная подпись и действия переносятся без горизонтального переполнения. Stories: LongContent

## keyboard

Tab/Enter/Space используют нативные поля, submit и действия. Stories: Usage

## focus

Обновление подписи и notices сохраняет поле, ввод и focus. Stories: Usage

## mobile

Строка действий переносится, touch floors Button не уменьшаются. Stories: LongContent

## sizes

Размер поля задаёт Textarea/rows; отступы каркаса и actions следуют density tokens.

## loading

Каркас не читает данные; загрузку истории показывает ResourceStateView владельца.

## empty

Пустой draft валиден для редактирования; допустимость отправки задаёт продукт.

## selection

Каркас не выбирает значения; обычное выделение текста не изменяется.
