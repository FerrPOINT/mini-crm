# OffsetPageNavigation: состояния

## variants

Стандартные controls и summary-only для первой/последней страницы. При устаревшем offset сохранять возврат. Stories: Default, SinglePage, StaleSummary

## sizes

Отдельный size-контракт отсутствует; размер определяется общей компоновкой или содержимым.

## disabled

Самостоятельного disabled-контракта нет; доступность предметных действий задаёт продукт.

## pending

Повторное действие недоступно до завершения операции. Stories: Pending

## loading

Компонент не загружает ресурс; загрузку показывает ResourceStateView или владелец данных.

## empty

Пустота явно объяснена и не подменяется ошибкой. Stories: Empty, EmptySummary, StaleSummary

## error

Компонент не выполняет запросов; ошибки ресурса передаются отдельному ResourceStateView.

## long-content

Длинная подпись и содержимое остаются читаемыми на 320/375 px; элементы управления доступны. Stories: LongContent

## selection

Сохранять явно выбранный ресурс, включая значение вне страницы. Stories: Unaligned

## keyboard

Tab и активация штатной клавишей; для overlay проверить Escape и возврат на trigger. Stories: Default, Usage

## focus

Фокус видим; открытие/закрытие не теряет текущую точку взаимодействия. Stories: Default, Usage

## mobile

Проверить 320/375/1920/2560; внутренний scroll допустим без overflow страницы. Stories: Default
