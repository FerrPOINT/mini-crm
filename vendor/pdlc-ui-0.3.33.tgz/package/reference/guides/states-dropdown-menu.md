# DropdownMenu: состояния

## variants

Обычный, danger и disabled пункты используют общую поверхность меню; действие вызывается только после подтверждённого выбора. Stories: Usage, ItemComposition

## sizes

Обычный пункт и отдельный Button size=icon используют общие tokens и touch floors; product width/flex остаются композицией. Stories: ItemComposition

## disabled

Недоступный пункт составного компонента пропускается при выборе. Stories: Default, ItemComposition

## pending

Компонент не запускает запись; pending принадлежит вызывающему механизму или переданному действию.

## loading

Компонент не загружает ресурс; загрузку показывает ResourceStateView или владелец данных.

## empty

Компонент не определяет пустоту предметного каталога; это контракт владельца данных.

## error

Компонент не выполняет запросов; ошибки ресурса передаются отдельному ResourceStateView.

## long-content

Длинная подпись и содержимое остаются читаемыми на 320/375 px; элементы управления доступны. Stories: LongContent, ItemComposition

## selection

Radio-пункты показывают выбранную плотность; выбор меняет локальное значение без запроса. Stories: Default, Usage

## keyboard

Tab и активация штатной клавишей; для overlay проверить Escape и возврат на trigger. Stories: Default, Usage, ItemComposition

## focus

Фокус видим; открытие/закрытие не теряет текущую точку взаимодействия. Stories: Default, Usage, ItemComposition

## mobile

Проверить 320/375/1920/2560; внутренний scroll допустим без overflow страницы. Stories: Default, ItemComposition
