# CopyButton: состояния

## variants

Текстовая и иконочная кнопка сохраняют семантику и focus Base Button. Stories: Default, Icon, InDialog

## sizes

Используются существующие размеры Button; мобильная область нажатия сохраняется. Stories: Sizes

## disabled

Недоступная кнопка не записывает Clipboard. Stories: Disabled

## pending

Синтетическая запись задержана; повторная активация блокируется до завершения. Stories: Pending

## loading

Компонент не загружает ресурс. Pending относится только к собственной записи в Clipboard.

## empty

Пустая строка копируется явно; внутренние значения не подставляются. Stories: Empty

## error

Явный синтетический transport отклоняет запись; успех не показывается, доступен повтор. Stories: Error

## long-content

Длинная подпись остаётся читаемой без горизонтального overflow. Stories: LongContent

## selection

Компонент не выбирает ресурс и не изменяет value.

## keyboard

Enter/Space вызывают ту же пользовательскую запись, что click. Stories: Default

## focus

Кнопка остаётся обычной focus target внутри Dialog; завершение не переносит focus. Stories: InDialog

## mobile

Проверить 320/375/1920/2560 и общий мобильный минимум Button. Stories: LongContent
