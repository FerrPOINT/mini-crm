# Дизайн-основа Base

Генерируется из @pdlc/ui/tokens.css. Значения в селекторах и media rules относятся к указанному контексту; вычисленное значение показывает браузер.

## --base-badge-color

Цвета

- @layer components · .base-badge: var(--color-text-secondary)
- @layer components · .base-badge[data-tone="muted"]: var(--color-text-muted)
- @layer components · .base-badge[data-tone="info"]: var(--color-highlight)
- @layer components · .base-badge[data-tone="success"]: var(--color-success)
- @layer components · .base-badge[data-tone="warning"]: var(--color-warning)
- @layer components · .base-badge[data-tone="danger"]: var(--color-danger)

## --base-button-foreground

Цвета

- .base-button:hover: var(--color-accent-hover-foreground)

## --base-color-control-size

Компоновка

- .base-input.base-control[type="color"]: var(--shell-control-min)
- @media (max-width: 767px) · .base-input.base-control[type="color"]: var(--shell-control-mobile-min)

## --base-content-section-padding

Компоновка

- .base-content-section: var(--base-panel-padding)
- .base-content-section[data-density="compact"]: var(--base-control-padding-block)

## --base-control-padding-block

Компоновка

- @theme static: 8px
- :root, [data-theme="dark"]: 8px
- [data-theme="gray"]: 8px
- [data-theme="light"]: 8px

## --base-control-padding-inline

Компоновка

- @theme static: 16px
- :root, [data-theme="dark"]: 16px
- [data-theme="gray"]: 16px
- [data-theme="light"]: 16px

## --base-dialog-close-size

Компоновка

- .base-dialog-content: var(--shell-control-min)
- @media (max-width: 767px) · .base-dialog-content: max(44px, var(--shell-control-min))

## --base-file-control-min

Компоновка

- @media (max-width: 767px) · .base-input[type="file"]: var(--shell-control-mobile-min)
- @layer components · .base-input[type="file"]: var(--shell-control-min)

## --base-font-body

Типографика

- @theme static: 0.875rem
- :root, [data-theme="dark"]: 0.875rem
- [data-theme="gray"]: 0.875rem
- [data-theme="light"]: 0.875rem

## --base-font-label

Типографика

- @theme static: 0.75rem
- :root, [data-theme="dark"]: 0.75rem
- [data-theme="gray"]: 0.75rem
- [data-theme="light"]: 0.75rem

## --base-font-mono

Типографика

- :root: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono",
    "Courier New", monospace

## --base-font-page-title

Типографика

- @theme static: 1.5rem
- :root, [data-theme="dark"]: 1.5rem
- [data-theme="gray"]: 1.5rem
- [data-theme="light"]: 1.5rem

## --base-font-sans

Типографика

- @theme static: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif
- :root, [data-theme="dark"]: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif
- [data-theme="gray"]: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif
- [data-theme="light"]: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif

## --base-icon-mark-color

Компоновка

- .base-icon-mark: var(--color-accent)

## --base-icon-mark-glyph-size

Компоновка

- .base-icon-mark: calc(var(--base-font-body) + 5px)
- .base-icon-mark[data-size="sm"]: calc(var(--base-font-body) + 3px)

## --base-icon-mark-size

Компоновка

- .base-icon-mark: calc(var(--base-font-body) + 20px)
- .base-icon-mark[data-size="sm"]: calc(var(--base-font-body) + 14px)

## --base-line-body

Типографика

- @theme static: 1.25rem
- :root, [data-theme="dark"]: 1.25rem
- [data-theme="gray"]: 1.25rem
- [data-theme="light"]: 1.25rem

## --base-panel-padding

Компоновка

- @theme static: 20px
- :root, [data-theme="dark"]: 20px
- [data-theme="gray"]: 20px
- [data-theme="light"]: 20px

## --base-radius

Скругления

- @theme static: 6px
- :root, [data-theme="dark"]: 6px
- [data-theme="gray"]: 6px
- [data-theme="light"]: 6px

## --base-radius-card

Скругления

- @theme static: 8px
- :root, [data-theme="dark"]: 8px
- [data-theme="gray"]: 8px
- [data-theme="light"]: 8px

## --base-radius-dialog

Скругления

- @theme static: 8px
- :root, [data-theme="dark"]: 8px
- [data-theme="gray"]: 8px
- [data-theme="light"]: 8px

## --base-radius-menu

Скругления

- @theme static: 6px
- :root, [data-theme="dark"]: 6px
- [data-theme="gray"]: 6px
- [data-theme="light"]: 6px

## --base-row-height

Компоновка

- @theme static: 48px
- :root, [data-theme="dark"]: 48px
- [data-theme="gray"]: 48px
- [data-theme="light"]: 48px

## --base-section-item-justify

Компоновка

- .base-section-navigation: center
- .base-section-navigation[data-orientation="vertical"]: space-between

## --base-timeline-gap

Компоновка

- @layer components · .base-timeline: calc(var(--base-control-padding-inline) * 0.75)
- @layer components · .base-timeline[data-appearance="steps"]: calc(var(--base-control-padding-inline) * 0.875)
- @layer components · @media (max-width: 480px) · .base-timeline: calc(var(--base-control-padding-block) * 0.875)
- @layer components · @media (max-width: 480px) · .base-timeline[data-appearance="steps"]: var(--base-control-padding-block)

## --base-timeline-rail-width

Компоновка

- @layer components · .base-timeline: 1.875rem
- @layer components · .base-timeline[data-appearance="steps"]: 2.5rem
- @layer components · @media (max-width: 480px) · .base-timeline: 1.25rem
- @layer components · @media (max-width: 480px) · .base-timeline[data-appearance="steps"]: 1.875rem

## --border-radius

Скругления

- .base-toaster,
.base-toaster[data-sonner-toaster][data-sonner-theme]: var(--base-radius-card)

## --color-accent

Цвета

- @theme static: #628ff1
- :root, [data-theme="dark"]: #628ff1
- [data-theme="gray"]: #89abf4
- [data-theme="light"]: #245fe2

## --color-accent-foreground

Цвета

- @theme static: #000000
- :root, [data-theme="dark"]: #000000
- [data-theme="gray"]: #000000
- [data-theme="light"]: #ffffff

## --color-accent-hover

Цвета

- @theme static: #759cf3
- :root, [data-theme="dark"]: #759cf3
- [data-theme="gray"]: #97b5f5
- [data-theme="light"]: #2054c7

## --color-accent-hover-foreground

Цвета

- @theme static: #000000
- :root, [data-theme="dark"]: #000000
- [data-theme="gray"]: #000000
- [data-theme="light"]: #ffffff

## --color-background

Цвета

- @theme static: #09090b
- :root, [data-theme="dark"]: #09090b
- [data-theme="gray"]: #1f1f23
- [data-theme="light"]: #f4f4f5

## --color-border

Цвета

- @theme static: #27272a
- :root, [data-theme="dark"]: #27272a
- [data-theme="gray"]: #3f3f46
- [data-theme="light"]: #e4e4e7

## --color-border-strong

Цвета

- @theme static: #737378
- :root, [data-theme="dark"]: #737378
- [data-theme="gray"]: #89898f
- [data-theme="light"]: #838386

## --color-danger

Цвета

- @theme static: #f87171
- :root, [data-theme="dark"]: #f87171
- [data-theme="gray"]: #fca5a5
- [data-theme="light"]: #b91c1c

## --color-danger-foreground

Цвета

- @theme inline: var(--color-destructive-foreground)

## --color-danger-strong

Цвета

- @theme inline: var(--color-danger)

## --color-destructive

Цвета

- @theme static: #f87171
- :root, [data-theme="dark"]: #f87171
- [data-theme="gray"]: #fca5a5
- [data-theme="light"]: #b91c1c
- @theme inline: var(--color-danger)

## --color-destructive-foreground

Цвета

- @theme static: #18181b
- :root, [data-theme="dark"]: #18181b
- [data-theme="gray"]: #18181b
- [data-theme="light"]: #ffffff

## --color-focus

Цвета

- @theme static: #628ff1
- :root, [data-theme="dark"]: #628ff1
- [data-theme="gray"]: #89abf4
- [data-theme="light"]: #245fe2

## --color-highlight

Цвета

- @theme static: #14b8a6
- :root, [data-theme="dark"]: #14b8a6
- [data-theme="gray"]: #27bead
- [data-theme="light"]: #0d766a

## --color-muted

Цвета

- @theme static: #27272a
- :root, [data-theme="dark"]: #27272a
- [data-theme="gray"]: #3f3f46
- [data-theme="light"]: #f4f4f5
- @theme inline: var(--color-surface-raised)

## --color-muted-foreground

Цвета

- @theme static: #a1a1aa
- :root, [data-theme="dark"]: #a1a1aa
- [data-theme="gray"]: #b4b4bd
- [data-theme="light"]: #52525b
- @theme inline: var(--color-text-muted)

## --color-popover

Цвета

- @theme static: #18181b
- :root, [data-theme="dark"]: #18181b
- [data-theme="gray"]: #2a2a2f
- [data-theme="light"]: #ffffff

## --color-popover-foreground

Цвета

- @theme static: #fafafa
- :root, [data-theme="dark"]: #fafafa
- [data-theme="gray"]: #f4f4f5
- [data-theme="light"]: #18181b

## --color-primary

Цвета

- @theme static: #628ff1
- :root, [data-theme="dark"]: #628ff1
- [data-theme="gray"]: #89abf4
- [data-theme="light"]: #245fe2
- @theme inline: var(--color-accent)

## --color-primary-foreground

Цвета

- @theme static: #000000
- :root, [data-theme="dark"]: #000000
- [data-theme="gray"]: #000000
- [data-theme="light"]: #ffffff
- @theme inline: var(--color-accent-foreground)

## --color-secondary

Цвета

- @theme static: #27272a
- :root, [data-theme="dark"]: #27272a
- [data-theme="gray"]: #3f3f46
- [data-theme="light"]: #f4f4f5
- @theme inline: var(--color-surface-raised)

## --color-secondary-foreground

Цвета

- @theme static: #fafafa
- :root, [data-theme="dark"]: #fafafa
- [data-theme="gray"]: #f4f4f5
- [data-theme="light"]: #18181b
- @theme inline: var(--color-text-primary)

## --color-selection

Цвета

- @theme static: #172e2e
- :root, [data-theme="dark"]: #172e2e
- [data-theme="gray"]: #2a3f41
- [data-theme="light"]: #ddecea

## --color-selection-foreground

Цвета

- @theme static: #fafafa
- :root, [data-theme="dark"]: #fafafa
- [data-theme="gray"]: #f4f4f5
- [data-theme="light"]: #18181b

## --color-success

Цвета

- @theme static: #4ade80
- :root, [data-theme="dark"]: #4ade80
- [data-theme="gray"]: #86efac
- [data-theme="light"]: #166534

## --color-surface

Цвета

- @theme static: #18181b
- :root, [data-theme="dark"]: #18181b
- [data-theme="gray"]: #2a2a2f
- [data-theme="light"]: #ffffff

## --color-surface-raised

Цвета

- @theme static: #27272a
- :root, [data-theme="dark"]: #27272a
- [data-theme="gray"]: #3f3f46
- [data-theme="light"]: #f4f4f5

## --color-text-muted

Цвета

- @theme static: #a1a1aa
- :root, [data-theme="dark"]: #a1a1aa
- [data-theme="gray"]: #b4b4bd
- [data-theme="light"]: #52525b

## --color-text-primary

Цвета

- @theme static: #fafafa
- :root, [data-theme="dark"]: #fafafa
- [data-theme="gray"]: #f4f4f5
- [data-theme="light"]: #18181b

## --color-text-secondary

Цвета

- @theme static: #d4d4d8
- :root, [data-theme="dark"]: #d4d4d8
- [data-theme="gray"]: #e4e4e7
- [data-theme="light"]: #3f3f46

## --color-warning

Цвета

- @theme static: #fbbf24
- :root, [data-theme="dark"]: #fbbf24
- [data-theme="gray"]: #fde047
- [data-theme="light"]: #92400e

## --error-text

Уведомления

- .base-toaster,
.base-toaster[data-sonner-toaster][data-sonner-theme]: var(--color-danger)

## --font-mono

Типографика

- @theme inline: var(--base-font-mono)

## --font-sans

Типографика

- @theme inline: var(--base-font-sans)

## --normal-bg

Уведомления

- .base-toaster,
.base-toaster[data-sonner-toaster][data-sonner-theme]: var(--color-surface)

## --normal-border

Уведомления

- .base-toaster,
.base-toaster[data-sonner-toaster][data-sonner-theme]: var(--color-border-strong)

## --normal-text

Уведомления

- .base-toaster,
.base-toaster[data-sonner-toaster][data-sonner-theme]: var(--color-text-primary)

## --platform-accent

Брендинг

- @theme static: #14b8a6
- :root, [data-theme="dark"]: #14b8a6
- [data-theme="gray"]: #14b8a6
- [data-theme="light"]: #14b8a6

## --platform-primary

Брендинг

- @theme static: #2563eb
- :root, [data-theme="dark"]: #2563eb
- [data-theme="gray"]: #2563eb
- [data-theme="light"]: #2563eb

## --platform-primary-foreground

Брендинг

- @theme static: #ffffff
- :root, [data-theme="dark"]: #ffffff
- [data-theme="gray"]: #ffffff
- [data-theme="light"]: #ffffff

## --platform-surface

Брендинг

- @theme static: #18181b
- :root, [data-theme="dark"]: #18181b
- [data-theme="gray"]: #2a2a2f
- [data-theme="light"]: #ffffff

## --radius-lg

Скругления

- @theme static: 8px
- :root, [data-theme="dark"]: 8px
- [data-theme="gray"]: 8px
- [data-theme="light"]: 8px

## --radius-md

Скругления

- @theme static: 6px
- :root, [data-theme="dark"]: 6px
- [data-theme="gray"]: 6px
- [data-theme="light"]: 6px

## --radius-sm

Скругления

- @theme static: 4px
- :root, [data-theme="dark"]: 4px
- [data-theme="gray"]: 4px
- [data-theme="light"]: 4px

## --radius-xl

Скругления

- @theme static: 10px
- :root, [data-theme="dark"]: 10px
- [data-theme="gray"]: 10px
- [data-theme="light"]: 10px

## --resource-row-min-height

Списки

- .base-resource-list: var(--base-row-height)
- .base-resource-list[data-density="comfortable"]: 56px

## --resource-row-padding-block

Списки

- .base-resource-list: var(--base-control-padding-block)
- .base-resource-list[data-density="comfortable"]: 16px

## --resource-row-padding-inline

Списки

- .base-resource-list: var(--base-control-padding-inline)

## --shell-aside-width

Компоновка

- :root: 320px

## --shell-control-min

Компоновка

- @theme static: 40px
- :root, [data-theme="dark"]: 40px
- [data-theme="gray"]: 40px
- [data-theme="light"]: 40px

## --shell-control-mobile-min

Компоновка

- @theme static: 44px
- :root, [data-theme="dark"]: 44px
- [data-theme="gray"]: 44px
- [data-theme="light"]: 44px

## --shell-header-height

Компоновка

- :root,
[data-base-branding-scope]: max(60px, var(--shell-header-row-height))
- @media (max-width: 767px) · :root:has(.platform-header-context [data-namespace-picker]),
  [data-base-branding-scope]:has(.platform-header-context [data-namespace-picker]): calc(var(--shell-header-row-height) * 2)

## --shell-header-row-height

Компоновка

- :root,
[data-base-branding-scope]: max(
    52px,
    calc(var(--base-line-body) + var(--base-control-padding-block) * 2 + 10px)
  )

## --shell-page-block-gap

Компоновка

- :root: 20px

## --shell-page-gutter

Компоновка

- :root: clamp(16px, 2vw, 32px)

## --shell-platform-mark-size

Компоновка

- :root: 40px

## --shell-readable-width

Компоновка

- :root: 760px

## --shell-sidebar-compact

Компоновка

- :root: 72px

## --shell-sidebar-expanded

Компоновка

- :root: 264px

## --success-text

Уведомления

- .base-toaster,
.base-toaster[data-sonner-toaster][data-sonner-theme]: var(--color-success)

## --text-2xl

Типографика

- @theme inline: var(--base-font-page-title)

## --text-2xl--line-height

Типографика

- @theme inline: calc(var(--base-line-body) + 0.75rem)

## --text-base

Типографика

- @theme inline: calc(var(--base-font-body) + 0.125rem)

## --text-base--line-height

Типографика

- @theme inline: calc(var(--base-line-body) + 0.25rem)

## --text-lg

Типографика

- @theme inline: calc(var(--base-font-body) + 0.25rem)

## --text-lg--line-height

Типографика

- @theme inline: calc(var(--base-line-body) + 0.25rem)

## --text-sm

Типографика

- @theme inline: var(--base-font-body)

## --text-sm--line-height

Типографика

- @theme inline: var(--base-line-body)

## --text-xl

Типографика

- @theme inline: calc(var(--base-font-body) + 0.375rem)

## --text-xl--line-height

Типографика

- @theme inline: calc(var(--base-line-body) + 0.5rem)

## --text-xs

Типографика

- @theme inline: var(--base-font-label)

## --text-xs--line-height

Типографика

- @theme inline: calc(var(--base-line-body) - 0.25rem)

## --warning-text

Уведомления

- .base-toaster,
.base-toaster[data-sonner-toaster][data-sonner-theme]: var(--color-warning)

## Адаптивные условия

- (forced-colors: active)
- (max-width: 1023px)
- (max-width: 480px)
- (max-width: 639px)
- (max-width: 640px)
- (max-width: 767px)
- (min-width: 1200px)
- (min-width: 1280px)
- (min-width: 640px)
- (min-width: 768px)
- (min-width: 768px) and (max-width: 1279px)
- (prefers-reduced-motion: reduce)
