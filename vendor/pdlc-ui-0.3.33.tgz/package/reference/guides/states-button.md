# Button: состояния

## variants

Сравнить поддерживаемые варианты оформления и компоновки. Stories: Variants, Destructive, SubjectColors, Dashed

## sizes

Сравнить доступные размеры и область нажатия. Stories: Sizes, Icon, SubjectColors

## disabled

Недоступный контрол не выполняет действие и не принимает фокус. Stories: Disabled, Destructive, SubjectColors, Dashed

## pending

Компонент не запускает запись; pending принадлежит вызывающему механизму или переданному действию.

## loading

Компонент не загружает ресурс; загрузку показывает ResourceStateView или владелец данных.

## empty

Компонент не определяет пустоту предметного каталога; это контракт владельца данных.

## error

Компонент не выполняет запросов; ошибки ресурса передаются отдельному ResourceStateView.

## long-content

Длинное содержимое остаётся читаемым на узком экране. Stories: LongContent, SubjectColors, ResponsiveActions

## selection

Управляемое aria-pressed меняет общий выбранный вид; действие выполняется только при активации. Stories: Toggle, Navigation

## keyboard

Tab фокусирует native button; Enter/Space вызывают одно действие. Disabled не активируется. Stories: Toggle, SubjectColors, Dashed, ResponsiveActions

## focus

Выбранное состояние не убирает видимый focus ring; обновление props не переносит focus. Stories: Toggle, SubjectColors, Dashed

## mobile

Проверить 320/375/1920/2560; внутренний scroll допустим без overflow страницы. Stories: LongContent, SubjectColors, Dashed, ResponsiveActions
