# BadgeInput: состояния

## variants

Нативное компактное поле: редактирование текста, keyboard/focus/disabled и длинное значение в строке меток. Stories: Usage, Disabled, LongContent

## sizes

Нативное компактное поле: редактирование текста, keyboard/focus/disabled и длинное значение в строке меток. Stories: Usage, Disabled, LongContent

## disabled

Нативное компактное поле: редактирование текста, keyboard/focus/disabled и длинное значение в строке меток. Stories: Usage, Disabled, LongContent

## pending

Данные, запросы, pending и выбранный набор принадлежат вызывающей композиции.

## loading

Данные, запросы, pending и выбранный набор принадлежат вызывающей композиции.

## empty

Данные, запросы, pending и выбранный набор принадлежат вызывающей композиции.

## error

Данные, запросы, pending и выбранный набор принадлежат вызывающей композиции.

## selection

Данные, запросы, pending и выбранный набор принадлежат вызывающей композиции.

## long-content

Нативное компактное поле: редактирование текста, keyboard/focus/disabled и длинное значение в строке меток. Stories: Usage, Disabled, LongContent

## keyboard

Нативное компактное поле: редактирование текста, keyboard/focus/disabled и длинное значение в строке меток. Stories: Usage, Disabled, LongContent

## focus

Нативное компактное поле: редактирование текста, keyboard/focus/disabled и длинное значение в строке меток. Stories: Usage, Disabled, LongContent

## mobile

Нативное компактное поле: редактирование текста, keyboard/focus/disabled и длинное значение в строке меток. Stories: Usage, Disabled, LongContent
