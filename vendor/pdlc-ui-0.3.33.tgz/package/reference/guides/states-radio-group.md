# RadioGroup: состояния

## variants

Один контракт выбора с обычным и сегментированным оформлением. Stories: Default, Segmented

## sizes

Отдельного size API нет; tokens задают шрифт, padding и минимум области нажатия.

## disabled

Недоступная группа и отдельный вариант не выбираются. Stories: Disabled, Segmented

## pending

Группа не выполняет запросы; владелец блокирует её через disabled.

## loading

Полный известный список задаёт продукт; удалённые каталоги используют SearchableSelect.

## empty

Пустой каталог объясняет владелец; выбор не создаётся автоматически.

## error

required и aria-invalid сохраняют нативную форму и общий визуальный сигнал. Stories: Invalid

## long-content

Длинные подписи и непрерывные идентификаторы переносятся без потери доступного имени. Stories: LongContent, Segmented

## selection

Одно выбранное значение; controlled/uncontrolled и reset. Stories: Usage, Segmented

## keyboard

Tab, стрелки, Space; disabled варианты пропускаются браузером. Stories: Usage, Segmented

## focus

Видимый focus на всём сегменте; оформление не заменяет input и не теряет focus. Stories: Segmented

## mobile

Минимум 44 px и перенос сегментов/подписей на узком экране. Stories: LongContent, Segmented
