# SidebarList: состояния

## variants

Обычная коллекция, вложенный native ul/li и компактная группа. Stories: Default, Nested, Compact

## disabled

Дочерний SidebarItem disabled остаётся нативной недоступной кнопкой. Stories: Nested

## long-content

Длинное имя проекта сокращается через ProjectNavigationGroup с сохранением доступного имени. Stories: LongContent

## keyboard

Клавиатурное раскрытие и одна локальная активация ссылки. Stories: Usage

## focus

Изменение оформления не перемонтирует ссылку и не меняет focus. Stories: Usage

## mobile

Список сжимается, строки сохраняют hit targets Base. Stories: LongContent

## sizes

Отдельного size нет; список следует density tokens, элементы — контрактам SidebarItem/ProjectNavigationGroup.

## pending

Список не выполняет записи; pending и callbacks принадлежат продукту.

## loading

Загрузка каталога относится к владельцу и ResourceStateView.

## empty

Пустота каталога и возможность создания ресурса определяются продуктом.

## error

Ошибка каталога и очистка данных при потере доступа принадлежат владельцу.

## selection

Активность маршрута задаёт SidebarItem; список не выбирает значение.
