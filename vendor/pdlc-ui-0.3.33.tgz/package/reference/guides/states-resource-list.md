# ResourceList: состояния

## variants

Сравнить поддерживаемые варианты оформления и компоновки. Stories: Variants, TechnicalText, ContextText, ColumnHeaders

## sizes

Отдельный size-контракт отсутствует; размер определяется общей компоновкой или содержимым.

## disabled

Disabled native button не активируется с мыши или клавиатуры; доступность ресурса и сообщение задаёт владелец данных. Stories: ActionRows, LinkedActions

## pending

Компонент не запускает запись; pending принадлежит вызывающему механизму или переданному действию.

## loading

Компонент не загружает ресурс; загрузку показывает ResourceStateView или владелец данных.

## empty

Компонент не определяет пустоту предметного каталога; это контракт владельца данных.

## error

Компонент не выполняет запросов; ошибки ресурса передаются отдельному ResourceStateView.

## long-content

Длинная подпись и содержимое остаются читаемыми на 320/375 px; элементы управления доступны. Stories: LongContent, LinkedActions, TextParts, TechnicalText, ContextText, ColumnHeaders

## selection

Два одинаковых названия с разными ID сохраняют независимую идентичность. Управляемый aria-pressed/current не подменяет значение формы. Stories: ActionRows, Selected

## keyboard

Tab/Shift+Tab, Enter и Space используют native button. Выбор не требует Ctrl; библиотека не создаёт listbox с собственными стрелками. Stories: ActionRows, LinkedActions, TextParts, ContextText

## focus

Пункт остаётся тем же DOM button при смене текущего ресурса, focus ring и disabled оформляются общей библиотекой. Stories: ActionRows, LinkedActions, TextParts, ContextText

## mobile

Проверить 320/375/1920/2560; внутренний scroll допустим без overflow страницы. Stories: LongContent, ActionRows, LinkedActions, TextParts, ColumnHeaders
