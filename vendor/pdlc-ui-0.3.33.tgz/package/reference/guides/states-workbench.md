# Workbench: состояния

## disabled

WorkbenchAsideAction и переданная форма используют native disabled Button; каркас не вводит отдельное состояние доступа. Stories: Disabled

## pending

Каркас не определяет предметное состояние. Controls, query/admission, disabled и сообщения принадлежат переданному содержимому; используйте готовые состояния Base.

## loading

Каркас не определяет предметное состояние. Controls, query/admission, disabled и сообщения принадлежат переданному содержимому; используйте готовые состояния Base.

## empty

Каркас не определяет предметное состояние. Controls, query/admission, disabled и сообщения принадлежат переданному содержимому; используйте готовые состояния Base.

## error

Каркас не определяет предметное состояние. Controls, query/admission, disabled и сообщения принадлежат переданному содержимому; используйте готовые состояния Base.

## selection

Каркас не определяет предметное состояние. Controls, query/admission, disabled и сообщения принадлежат переданному содержимому; используйте готовые состояния Base.

## variants

Bounded workspace, document flow на мобильном и отсутствие контекста сохраняют назначение панели. Stories: Default, DocumentFlow, NoAside

## sizes

Общая высота учитывает actual PageFrame gutter; asideWidth меняет только предметную ширину контекста. Stories: Default, WideAside

## long-content

Длинное содержимое прокручивается внутри панелей без горизонтального overflow. Stories: LongContent

## keyboard

Tab и native submit работают в прежней форме; Escape существующего Dialog закрывает контекст. Stories: Usage

## focus

Изменение mobileFlow и плотности не перемонтирует draft/ref; Dialog возвращает focus на action. Stories: Usage

## mobile

320/375/1000/1199/1200/1920/2560: sidebar и action меняются на общей границе, mobile flow не создаёт внутреннюю ловушку scroll. Stories: Default, DocumentFlow
