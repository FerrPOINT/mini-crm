# AccountMenu: состояния

## variants

Проверить меню аккаунта, режим без аккаунта и обе focus-модели без вызова callbacks при открытии. Stories: Default, ThemeOnly, NonModal, Usage

## sizes

Отдельного size нет: trigger и popup получают общую геометрию Base.

## disabled

Выход disabled, выбор темы остаётся доступным. Stories: Pending

## pending

Pending приходит от владельца и не запускает повторный logout. Stories: Pending

## loading

Меню не загружает identity; чтение и loading принадлежат продукту.

## empty

Без account показываются только темы, без logout и фиктивного имени. Stories: ThemeOnly

## error

Ошибка logout/readback принадлежит продукту; Base не подавляет и не повторяет операции.

## long-content

Длинные имя и email читаемы при 320/375 без overflow. Stories: LongContent

## selection

Темы используют ThemeProvider; выбор предметного пункта вызывает только его callback. Stories: Default, Usage

## keyboard

Enter/Space/ArrowDown, стрелки по пунктам, Escape и восстановление trigger focus. Stories: Default, Usage, NonModal

## focus

Закрытие не теряет focus, modal=false не превращается в модальное меню. Stories: Default, NonModal

## mobile

40 px desktop/44 px mobile, popup ограничен viewport и прокручивается. Stories: Default, LongContent
