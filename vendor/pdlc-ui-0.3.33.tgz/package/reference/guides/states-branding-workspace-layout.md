# BrandingWorkspaceLayout: состояния

## variants

Навигация без действий и единственный внешний submit с form ID. Stories: Usage, Default

## sizes

Отдельный size-контракт отсутствует; размер определяется общей компоновкой или содержимым.

## disabled

Самостоятельного disabled-контракта нет; доступность предметных действий задаёт продукт.

## pending

Компонент не запускает запись; pending принадлежит вызывающему механизму или переданному действию.

## loading

Компонент не загружает ресурс; загрузку показывает ResourceStateView или владелец данных.

## empty

Компонент не определяет пустоту предметного каталога; это контракт владельца данных.

## error

Компонент не выполняет запросов; ошибки ресурса передаются отдельному ResourceStateView.

## long-content

Длинная форма не скрывает submit, focused input раскрывается над dock. Stories: LongContent

## selection

Выбираемого значения нет; компонент не является selector.

## keyboard

Tab достигает формы и единственной кнопки submit. Stories: Usage

## focus

Focus в форме раскрывается; focus в portaled dialog не прокручивает форму. Stories: Usage

## mobile

Dock учитывает ширину main и visualViewport; проверить 375 px с экранной клавиатурой. Stories: Usage
