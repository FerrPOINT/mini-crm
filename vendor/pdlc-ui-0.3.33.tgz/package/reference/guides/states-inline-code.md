# InlineCode: состояния

## variants

Одно нативное code с теми же правилами оформления, что у подготовленного Prose. Stories: Default

## sizes

Inline code следует размеру окружающего текста и общим typography/radius tokens. Stories: Usage

## long-content

Длинный путь/идентификатор переносится в доступной ширине. Stories: LongContent

## mobile

320/375/1920/2560 в трёх темах без горизонтального переполнения. Stories: LongContent

## disabled

Статический текст не является control; недоступность действия задаётся окружающему Button.

## pending

Компонент не выполняет операции и не имеет pending state.

## loading

Загрузка источника относится к ResourceState владельца.

## empty

Пустую предметную величину и её пояснение определяет владелец.

## error

Ошибка данных или сохранения показывается отдельным Notice/ResourceState.

## selection

Нет значения формы и выбора ресурса; обычное выделение текста выполняет браузер.

## keyboard

Не добавляет tab stop или keyboard handler. Для действия используйте Button/CopyButton.

## focus

Сам компонент не перемещает focus. Нативные авторские атрибуты сохраняются.
