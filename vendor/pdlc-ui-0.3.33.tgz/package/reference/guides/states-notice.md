# Notice: состояния

## variants

Панель и inline, пять semantic tones и композиция с Badge. Stories: Default, Tones, Inline, Error, Composition, ResourceContext, Separated

## sizes

Отдельного size API нет; padding и radius берутся из канонических tokens.

## disabled

Disabled принадлежит переданному Button; Notice не добавляет обработчик. Stories: Disabled

## pending

Не запускает операций. Pending передаётся конкретной кнопке вызывающим кодом.

## loading

Чтение данных принадлежит ResourceStateView; Notice отображает готовое сообщение.

## empty

Пустой каталог задаёт продукт; для него уже существует EmptyState.

## error

Явное role=alert для ошибки; unknown требует readback, без автоматического повтора записи. Stories: Error, Usage

## long-content

Непрерывный длинный идентификатор переносится внутри доступной ширины. Stories: LongContent

## selection

Сообщение не выбирает данные и не меняет фильтры.

## keyboard

Переданная кнопка доступна с клавиатуры и выполняет только явный синтетический callback. Stories: Usage

## focus

Обновление сообщения не перехватывает focus; действия работают внутри Dialog. Владелец явно фокусирует результат через ref/tabIndex=-1; общий focus ring виден и сохраняется при смене оформления. Stories: Usage, InDialog, FocusResult

## mobile

Проверить 320/375/1920/2560 без overflow; один активный пример. Stories: LongContent, Usage, ResourceContext
