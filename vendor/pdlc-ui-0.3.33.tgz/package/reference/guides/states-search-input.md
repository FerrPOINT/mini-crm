# SearchInput: состояния

## variants

Обычный ввод, управляемая очистка и readonly используют один native search input. Stories: Default, Usage, Readonly

## sizes

Отдельный size-контракт отсутствует; размер определяется общей компоновкой или содержимым.

## disabled

Недоступный контрол не выполняет действие и не принимает фокус. Stories: Disabled

## pending

Компонент не запускает запись; pending принадлежит вызывающему механизму или переданному действию.

## loading

Компонент не загружает ресурс; загрузку показывает ResourceStateView или владелец данных.

## empty

Компонент не определяет пустоту предметного каталога; это контракт владельца данных.

## error

Ошибка связана с полем и доступна вспомогательным технологиям. Stories: Invalid

## long-content

Длинное содержимое остаётся читаемым на узком экране. Stories: LongContent

## selection

Поле задаёт текстовый запрос; выбор ресурса выполняет SearchableSelect или продукт.

## keyboard

Tab/Shift+Tab, ввод, очистка Enter/Space и возврат фокуса без submit. Stories: Usage

## focus

Фокус принадлежит input; после подтверждённой очистки возвращается в поле. Stories: Usage

## mobile

Проверить 320/375/1920/2560; внутренний scroll допустим без overflow страницы. Stories: LongContent
