# Timeline: состояния

## variants

Activity и steps, состояния и разные размеры маркеров используют одну composition. Stories: Steps, Usage

## sizes

Small/large markers; размеры не заменяют текстовое объяснение группового этапа. Stories: Steps

## disabled

Самостоятельного disabled-контракта нет; доступность предметных действий задаёт продукт.

## pending

Компонент не запускает запись; pending принадлежит вызывающему механизму или переданному действию.

## loading

Компонент не загружает ресурс; загрузку показывает ResourceStateView или владелец данных.

## empty

Компонент не определяет пустоту предметного каталога; это контракт владельца данных.

## error

Компонент не выполняет запросов; ошибки ресурса передаются отдельному ResourceStateView.

## long-content

Длинный текст и раскрываемый отчёт переносятся на 320/375 без overflow страницы. Stories: LongContent

## selection

Выбираемого значения нет; компонент не является selector.

## keyboard

Tab достигает native summary и ссылки. Enter/Space раскрывают summary, Timeline не перехватывает клавиши. Stories: Usage

## focus

Оформление текущего маркера не переносит focus с раскрываемого отчёта. Stories: Usage

## mobile

Rail и gap адаптируются; содержимое и native controls остаются доступными на 320/375/1920/2560. Stories: LongContent, Steps
