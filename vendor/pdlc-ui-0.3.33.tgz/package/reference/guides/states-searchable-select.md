# SearchableSelect: состояния

## variants

Переходы меняют только страницу; выбранное значение сохраняется до явного выбора. Stories: UncountedPages

## sizes

Отдельный size-контракт отсутствует; размер определяется общей компоновкой или содержимым.

## disabled

Недоступный контрол не выполняет действие и не принимает фокус. Stories: Disabled

## pending

Компонент не запускает запись; pending принадлежит вызывающему механизму или переданному действию.

## loading

Отображается подтверждённое ожидание, без ложной пустоты. Stories: Loading, PendingPages

## empty

Пустота явно объяснена и не подменяется ошибкой. Stories: Empty, UncountedPages

## error

Ошибка видна; повтор выполняется только по действию пользователя. Stories: Error, PendingPages

## long-content

Длинное содержимое доступно на узком экране без overflow страницы. Stories: LongContent

## selection

Изменить значение с клавиатуры и проверить отображаемый выбор. Stories: Default, Usage, UncountedPages

## keyboard

Tab и активация штатной клавишей; для overlay проверить Escape и возврат на trigger. Stories: Default, Usage, UncountedPages

## focus

После пагинации pending удерживает focus в диалоге, success возвращает доступное направление, error — retry. Поиск пользователя и закрытие не перехватываются. Stories: Default, Usage, UncountedPages, PendingPages

## mobile

Проверить 320/375/1920/2560; внутренний scroll допустим без overflow страницы. Stories: LongContent, UncountedPages
