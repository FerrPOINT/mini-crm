# ActionGroup: состояния

## variants

Выравнивание, общий разделитель, строка и вертикальный список. Stories: Default, Start, Between, Separated, Vertical

## disabled

Владелец блокирует конкретную кнопку, остальные действия доступны. Stories: Disabled

## pending

Pending и aria-busy передаются исходной кнопке; группа не выполняет записи. Stories: Pending

## long-content

Длинные подписи и пояснение переносятся без потери доступного имени. Stories: LongContent

## keyboard

Native Tab, Enter и reset работают без собственного контроллера клавиатуры. Stories: Usage

## focus

Изменение параметров группы не перемонтирует поле или кнопку. Stories: Usage

## mobile

Явная мобильная колонка и touch floors Base. Stories: ResponsiveActions

## sizes

Отдельного size нет; промежутки и inset определяются density, дочерние контролы сохраняют свои размеры.

## loading

Группа не загружает данные; loading принадлежит продукту и ResourceStateView.

## empty

Владелец решает, показывать ли действия; группа не подставляет действие при пустом наборе.

## error

Ошибки записи передаёт продукт через Notice; группа не сохраняет и не повторяет запросы.

## selection

Группа не выбирает значения или маршрут.
