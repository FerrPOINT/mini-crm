# ContentSection: состояния

## variants

Прозрачная секция меняет стороны разделителя без создания новой поверхности или DOM wrapper при asChild. Stories: Default, End, Both, Unseparated

## sizes

Обычный и компактный inset используют текущие tokens плотности; ширина и предметная сетка принадлежат приложению. Stories: Default, Compact

## disabled

Секция не блокирует содержимое. Для native disabled группы используйте Fieldset; права остаются у продукта.

## pending

Секция не выполняет операций. Pending задаётся дочерним контролам владельцем.

## loading

ResourceState передаётся содержимым; компонент не скрывает фильтры или последний подтверждённый результат.

## empty

Пустота данных определяется продуктом; EmptyState можно передать содержимым.

## error

Ошибки чтения/сохранения остаются у владельца и передаются через ErrorState/Notice.

## long-content

Длинный заголовок и непрерывная строка читаемы без min-content overflow. Stories: LongContent

## selection

Секция не имеет выбранного значения, не создаёт onChange и не подставляет ресурс.

## keyboard

Нативная форма сохраняет required, Enter/submit и порядок Tab; изменение оформления не вызывает submit. Stories: Form

## focus

При смене density/dividers сохраняются DOM поля, введённый draft и фокус. Stories: Form

## mobile

320/375/1920/2560, три темы и плотности: shared рамка не уменьшает mobile hit target дочерних контролов. Stories: LongContent, Form
