# Card: состояния

## variants

Выбранный уровень заголовка сохраняет семантику и оформление Base. Stories: SemanticHeading, Linked, Resources, Frames, Descriptions

## sizes

Default/compact используют общие panel/control density tokens; вложенные действия сохраняют мобильную область нажатия. Stories: Frames

## disabled

Недоступный fieldset сохраняет native disabled: описание не переключает значение и не вызывает обработчик. Stories: SelectionControls

## pending

Компонент не запускает запись; pending принадлежит вызывающему механизму или переданному действию.

## loading

Компонент не загружает ресурс; загрузку показывает ResourceStateView или владелец данных.

## empty

Компонент не определяет пустоту предметного каталога; это контракт владельца данных.

## error

Компонент не выполняет запросов; ошибки ресурса передаются отдельному ResourceStateView.

## long-content

Длинное содержимое остаётся читаемым на узком экране. Stories: LongContent, Descriptions

## selection

Две нативные карточки выбираются по ID; общий вид отражает aria-pressed без отдельной продуктовой геометрии. Stories: Selection, SelectionControls

## keyboard

Нативная ссылка: Tab/Shift+Tab и Enter; Base не добавляет второй обработчик активации. Stories: Linked, SelectionControls, Descriptions

## focus

Фокус принадлежит самой ссылке; outline берётся из токена focus без продуктовой копии CSS. Stories: Linked, SelectionControls, Descriptions

## mobile

Проверить 320/375/1920/2560; внутренний scroll допустим без overflow страницы. Stories: LongContent, SelectionControls, Frames, Descriptions
