# Dialog: состояния

## variants

Padded и sectioned используют одни tokens; в sectioned продукт не задаёт вложенные padding/рамки. Stories: Default, Sectioned

## sizes

Отдельный size-контракт отсутствует; размер определяется общей компоновкой или содержимым.

## disabled

Недоступный trigger или действие составного компонента не активируется, безопасный выход доступен. Stories: Disabled

## pending

Компонент не запускает запись; pending принадлежит вызывающему механизму или переданному действию.

## loading

Компонент не загружает ресурс; загрузку показывает ResourceStateView или владелец данных.

## empty

Компонент не определяет пустоту предметного каталога; это контракт владельца данных.

## error

Компонент не выполняет запросов; ошибки ресурса передаются отдельному ResourceStateView.

## long-content

Длинная подпись и содержимое остаются читаемыми на 320/375 px; элементы управления доступны. Stories: LongContent, Sectioned

## selection

Выбираемого значения нет; компонент не является selector.

## keyboard

Tab и активация штатной клавишей; для overlay проверить Escape и возврат на trigger. Stories: Default, Usage, Controlled, Sectioned

## focus

Фокус видим; открытие/закрытие не теряет текущую точку взаимодействия. Stories: Default, Usage, Controlled, Sectioned

## mobile

Проверить 320/375/1920/2560; внутренний scroll допустим без overflow страницы. Stories: Default, Sectioned
