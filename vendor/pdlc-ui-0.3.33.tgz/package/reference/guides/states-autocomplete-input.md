# AutocompleteInput: состояния

## variants

Обычный ввод, управляемое значение и readonly сохраняют один native input. Stories: Default, Readonly, Usage

## sizes

Высота задаётся общими tokens 40/44 px; отдельного size-контракта нет.

## disabled

Недоступное поле не раскрывает список и не изменяет значение. Stories: Disabled

## pending

Компонент не выполняет запись; pending и запрет редактирования принадлежат владельцу.

## loading

Локальные подсказки не загружают данные; состояние удалённого чтения показывает продукт.

## empty

Пустые подсказки не запрещают ввод нового значения и не подменяют его другим. Stories: Empty

## error

Native required и aria-invalid сохраняют валидацию и оформление ошибки. Stories: Invalid

## long-content

Длинные label/value переносятся внутри ограниченного прокручиваемого popup. Stories: LongContent

## selection

Подсветка не меняет значение; подтверждение передаёт точное исходное value один раз. Stories: Usage

## keyboard

Стрелки, Enter, Escape, Tab, Home/End и IME сохраняют фокус и native редактирование. Stories: Usage, InDialog

## focus

Первый Escape закрывает список, второй — диалог; фокус input не теряется. Stories: InDialog

## mobile

320/375/1920/2560, крупный текст и branding без переполнения popup и страницы. Stories: LongContent, BrandDesign
