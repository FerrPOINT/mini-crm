# SidebarItem: состояния

## variants

Сравнить поддерживаемые варианты оформления и компоновки. Stories: Compact, Inactive, LabelComposition

## sizes

Отдельный size-контракт отсутствует; размер определяется общей компоновкой или содержимым.

## disabled

Недоступный контрол не выполняет действие и не принимает фокус. Stories: Disabled

## pending

Компонент не запускает запись; pending принадлежит вызывающему механизму или переданному действию.

## loading

Компонент не загружает ресурс; загрузку показывает ResourceStateView или владелец данных.

## empty

Компонент не определяет пустоту предметного каталога; это контракт владельца данных.

## error

Компонент не выполняет запросов; ошибки ресурса передаются отдельному ResourceStateView.

## long-content

Длинное содержимое остаётся читаемым на узком экране. Stories: LongContent

## selection

Выбираемого значения нет; компонент не является selector.

## keyboard

Tab и активация штатной клавишей; для overlay проверить Escape и возврат на trigger. Stories: Default, Usage, LabelComposition

## focus

Фокус видим; открытие/закрытие не теряет текущую точку взаимодействия. Stories: Default, Usage, LabelComposition

## mobile

Проверить 320/375/1920/2560; внутренний scroll допустим без overflow страницы. Stories: LongContent, LabelComposition
