# Checkbox: состояния

## variants

Рабочая композиция, клавиатура, перенос содержимого и общие tokens в трёх темах. Stories: Usage, Cards, LabelTones

## sizes

Отдельного size API нет; плотность и мобильный минимум определяются общими tokens.

## disabled

Нативные поля не изменяются и не отправляют callbacks. Stories: Disabled, CardDisabled, LabelTones

## pending

Компонент не выполняет запросов; это состояние задаёт вызывающая композиция.

## loading

Компонент не выполняет запросов; это состояние задаёт вызывающая композиция.

## empty

Компонент не выполняет запросов; это состояние задаёт вызывающая композиция.

## error

aria-invalid, required и сообщения формы сохраняют семантику. Stories: Invalid, CardInvalid

## long-content

Длинная подпись с непрерывным идентификатором переносится на 320/375 px без overflow. Stories: LongContent, CardLongContent

## selection

Boolean, indeterminate и одиночный выбор в одной форме. Stories: Usage, Cards, LabelTones

## keyboard

Рабочая композиция, клавиатура, перенос содержимого и общие tokens в трёх темах. Stories: Usage, Cards, LabelTones

## focus

Рабочая композиция, клавиатура, перенос содержимого и общие tokens в трёх темах. Stories: Usage, Cards, LabelTones

## mobile

Рабочая композиция, клавиатура, перенос содержимого и общие tokens в трёх темах. Stories: Usage, Cards, LabelTones
