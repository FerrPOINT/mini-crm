# ConfirmAction: состояния

## variants

Trigger и подтверждение получают отдельные варианты; default не становится destructive из-за внутренних слоёв. Stories: Default, Destructive

## sizes

Base Button size управляет подписью и иконочным действием, а не продуктовые размеры. Stories: Sizes

## disabled

Нет открытия или callback; изменение disabled блокирует подтверждение уже открытого диалога. Stories: Disabled

## pending

После подтверждения promise удерживает диалог и блокирует повтор/отмену до завершения. Stories: Pending

## loading

Данные не загружаются; ожидание собственной операции представлено pending.

## empty

Компонент не определяет пустоту предметного каталога.

## error

Ошибка передаётся продуктом, readback не заменяется автоматическим повтором. Stories: Error

## long-content

Подпись, заголовок и пояснение доступны на узком экране без горизонтального overflow. Stories: LongContent

## selection

Нет выбора ресурса; выбранная запись остаётся у продукта.

## keyboard

Enter/Space открывают, Escape отменяет до начала записи; отмена не вызывает callback. Stories: Usage

## focus

Отмена возвращает focus на trigger; после его disabled/удаления используется доступный fallbackFocusRef. Stories: Usage, Sizes

## mobile

40 px desktop и минимум 44 px mobile; popup сохраняет брендинг своего контекста. Stories: LongContent, Sizes
