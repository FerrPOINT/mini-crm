# Table: состояния

## variants

Техническая или обычная типографика сохраняет shared selection и native структуру строки. Stories: TechnicalCells, Selected

## sizes

Сравнить default/sm типографику и technical без изменения native строки и доступности действий. Stories: TechnicalCells

## disabled

Самостоятельного disabled-контракта нет; доступность предметных действий задаёт продукт.

## pending

Компонент не запускает запись; pending принадлежит вызывающему механизму или переданному действию.

## loading

Компонент не загружает ресурс; загрузку показывает ResourceStateView или владелец данных.

## empty

Компонент не определяет пустоту предметного каталога; это контракт владельца данных.

## error

Компонент не выполняет запросов; ошибки ресурса передаются отдельному ResourceStateView.

## long-content

Длинное содержимое остаётся читаемым на узком экране. Stories: LongContent, InCard

## selection

Действие владельца меняет выбранный ID; TableRow только оформляет соответствующую строку. Stories: Selected

## keyboard

Явный tabIndex=0 допускает Tab к нативной таблице; собственные обработчики стрелок и роль grid не добавляются. Stories: Focus

## focus

Видимый фокус использует общий token и не обрезается внешним краем scroll-контейнера. Stories: Focus

## mobile

Проверить 320/375/1920/2560; внутренний scroll допустим без overflow страницы. Stories: LongContent, InCard
