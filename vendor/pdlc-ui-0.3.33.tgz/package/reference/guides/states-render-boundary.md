# RenderBoundary: состояния

## variants

Здоровая область и fallback владельца; отчёт вызывается только при реальном render-сбое. Stories: Default, Error, Usage

## sizes

Граница не создаёт геометрию; размер зависит от children и fallback.

## disabled

Граница не блокирует действия и не проверяет права.

## pending

Не выполняет операций; pending принадлежит владельцу.

## loading

Не загружает ресурсы и не заменяет ResourceState.

## empty

Пустой children/fallback является явным содержимым владельца, не пустотой каталога.

## error

Реальная ошибка потомка заменяется fallback. Повторный render без нового key не запускает восстановление или запись. Stories: Error, Usage

## long-content

Длинное пояснение передано настоящему ErrorState Base; граница не дублирует его оформление. Stories: LongContent

## selection

Нет собственного выбранного значения или callbacks выбора.

## keyboard

Внешние кнопки вызывают render-сбой и явное пересоздание с клавиатуры, без продукта/API. Stories: Usage

## focus

Кнопка снаружи области остаётся на месте; ввод хранится у владельца и возвращается после его явного reset. Stories: Usage

## mobile

Настоящие Base actions/input/error в 320/375/1920/2560 и трёх темах; граница не добавляет собственный viewport или overflow. Stories: Usage, LongContent
