# Badge: состояния

## variants

Шесть semantic tones и badge/inline/dot/counter; все используют канонические tokens. Stories: Tones, Inline, Dot, Removable, Counter, SubjectColors, SubjectBranding

## sizes

Компактный counter растёт по содержимому, обычная метка сохраняет высоту и перенос текста. Stories: Counter, SubjectColors, SubjectBranding

## disabled

Disabled принадлежит отдельному действию, а не всей метке; оно не активируется. Stories: SubjectColors

## pending

Компонент не запускает запись; pending принадлежит вызывающему механизму или переданному действию.

## loading

Компонент не загружает ресурс; загрузку показывает ResourceStateView или владелец данных.

## empty

Компонент не определяет пустоту предметного каталога; это контракт владельца данных.

## error

Компонент не выполняет запросов; ошибки ресурса передаются отдельному ResourceStateView.

## long-content

Длинное содержимое остаётся читаемым на узком экране. Stories: LongContent, SubjectColors

## selection

Выбираемого значения нет; компонент не является selector.

## keyboard

Метка статична; Tab/Enter активируют только отдельный Button. После удаления композиция возвращает focus на восстановление. Stories: Removable, SubjectColors, SubjectBranding

## focus

Цвет не скрывает focus вложенного действия; изменение оформления не пересоздаёт Button. Stories: Removable, SubjectColors, SubjectBranding

## mobile

Проверить 320/375/1920/2560; внутренний scroll допустим без overflow страницы. Stories: LongContent, SubjectColors, SubjectBranding
