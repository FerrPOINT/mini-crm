# ResourceStateView: состояния

## variants

Сравнить прежний page и компактный local. Проверка protocol readiness выполняется отдельными unit cases; story не является подключением к настоящему host. Stories: Default, Local, Content

## sizes

Отдельный size-контракт отсутствует; размер определяется общей компоновкой или содержимым.

## disabled

Самостоятельного disabled-контракта нет; доступность предметных действий задаёт продукт.

## pending

Компонент не запускает запись; pending принадлежит вызывающему механизму или переданному действию.

## loading

Default показывает loading; ready/partial/denied/not-found выделены отдельно. Stories: Default

## empty

Пустота явно объяснена и не подменяется ошибкой. Stories: Empty

## error

Ошибка видна; повтор выполняется только по действию пользователя. Stories: Error, Partial, Denied, NotFound, Terminal, Content

## long-content

Длинное содержимое доступно на узком экране без overflow страницы. Stories: LongContent

## selection

Выбираемого значения нет; компонент не является selector.

## keyboard

Общие кнопки повтора доступны Tab/Enter; запрос выполняет callback владельца. SSR retry_url остаётся нативной ссылкой. Stories: Error, Partial, Content

## focus

Повтор не перехватывает focus и не отправляет родительскую форму. Подтверждение данных не сохраняет focus внутри исчезнувшего контрола. Stories: Error, Partial

## mobile

Проверить 320/375/1920/2560; внутренний scroll допустим без overflow страницы. Stories: LongContent
