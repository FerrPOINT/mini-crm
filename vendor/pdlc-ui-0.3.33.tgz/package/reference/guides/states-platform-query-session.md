# PlatformQuerySession: состояния

## sizes

Provider не задаёт размер; геометрию контролов определяют компоненты Base.

## disabled

Это граница сессии, а не disabled control.

## pending

Завершение sign-out и pending принадлежат auth-store продукта.

## loading

Provider не выполняет HTTP-запросы.

## empty

Предметная пустота принадлежит владельцу данных.

## error

Ошибки запросов отображаются внутри product tree, не подменяются здесь.

## selection

Версия доступа не является пользовательским selector.

## variants

Синтетическая смена authVersion очищает данные и черновик; текущие органы управления используют Base. Stories: Default

## keyboard

Синтетическая смена authVersion очищает данные и черновик; текущие органы управления используют Base. Stories: Default

## focus

Синтетическая смена authVersion очищает данные и черновик; текущие органы управления используют Base. Stories: Default

## mobile

Синтетическая смена authVersion очищает данные и черновик; текущие органы управления используют Base. Stories: Default

## long-content

Длинная поясняющая подпись и textarea не создают min-content overflow. Stories: LongContent
