# BadgeButton: состояния

## variants

Нативная компактная кнопка: keyboard/focus/disabled, перенос текста без потери подписи. Stories: Usage, Disabled, LongContent

## sizes

Нативная компактная кнопка: keyboard/focus/disabled, перенос текста без потери подписи. Stories: Usage, Disabled, LongContent

## disabled

Нативная компактная кнопка: keyboard/focus/disabled, перенос текста без потери подписи. Stories: Usage, Disabled, LongContent

## pending

Данные, запросы, pending и выбранный набор принадлежат вызывающей композиции.

## loading

Данные, запросы, pending и выбранный набор принадлежат вызывающей композиции.

## empty

Данные, запросы, pending и выбранный набор принадлежат вызывающей композиции.

## error

Данные, запросы, pending и выбранный набор принадлежат вызывающей композиции.

## selection

Данные, запросы, pending и выбранный набор принадлежат вызывающей композиции.

## long-content

Нативная компактная кнопка: keyboard/focus/disabled, перенос текста без потери подписи. Stories: Usage, Disabled, LongContent

## keyboard

Нативная компактная кнопка: keyboard/focus/disabled, перенос текста без потери подписи. Stories: Usage, Disabled, LongContent

## focus

Нативная компактная кнопка: keyboard/focus/disabled, перенос текста без потери подписи. Stories: Usage, Disabled, LongContent

## mobile

Нативная компактная кнопка: keyboard/focus/disabled, перенос текста без потери подписи. Stories: Usage, Disabled, LongContent
