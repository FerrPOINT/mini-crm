# React и SSR

Для короткого контекста ресурса используйте `resource_list_description`:
по умолчанию native span; `tag='p'` сохраняет абзац, `tag='div'` — блочную
сводку. Другие теги нормализуются в span. `id`, `hidden` и `class_name`
сохраняют адрес, нативную видимость и внешнюю компоновку. Текст передаётся
через label либо caller; обычные динамические значения остаются escaped.
Шрифты/цвета не копируются в продукт. Полный документ, абзацы и нумерованные
критерии используют `prose` / `prose(compact=true)`; это отдельный контракт.

```jinja
{% import 'base/macros.html' as ui %}
{{ ui.resource_list_description('Показано 8 из ' ~ total, tag='div') }}
{{ ui.resource_list_description('Удаление недоступно.', id='delete-hint', tag='p', hidden=true) }}
```

Канонические SSR macros находятся в `base-modules/ui/ssr/macros.html` Base.
Штатный экспорт из checkout Base: `pnpm --dir base-modules/ui ssr:export --out ./exported-base-ui`.
`--out` обязателен; вместо демонстрационного каталога укажите папку шаблонов потребителя.
В установленном UI-пакете доступен тот же exporter: `node node_modules/@pdlc/ui/scripts/export-ssr.mjs --out ./templates/base`.
Полученные файлы и fingerprints
проверяются существующим UI contract gate, а не копируются вручную из каталога.

SSR contract gate требует Python с Jinja2 из окружения SSR-потребителя;
версии tooling закреплены в `base-modules/ui/scripts/requirements-ssr.txt`.
Авторские script tests устанавливают тот же файл, а не случайную версию. Gate
разбирает shell через Jinja AST без render/import продуктового runtime и
проверяет literal import канонического `macros.html` из `ssrAssets` относительно
каталога shell. Alias, кавычки и `from ... import` допустимы; комментарий или
строка с текстом import не являются подключением. Dynamic import не доказывает
статического владельца. Fingerprint/export drift проверяется независимо и не
отключается успешным import. React-only gate не требует Jinja2.

Карточка `show Component --section setup` содержит имя macro, если есть прямой
аналог. Отсутствие аналога обозначается явно. Macro и React-компонент могут иметь
разные аргументы: читайте сигнатуру macro, не переносите React props в шаблон.
Runtime JS, стили и механизм подтверждения ухода берите из штатной SSR-поставки.

`app_shell(title, navigation, leading, services, context, actions, layout)`
владеет header/sidebar/main, единственным PageFrame и modal drawer. Product slots
передаются подготовленной Jinja-разметкой; `caller` содержит PageHeader и контент.
Тот же DOM navigation и context переносится в drawer на узкой ширине, без клона
selector или потери выбранного значения. Не добавляйте рядом собственные main,
sidebar, frame или JS управления focus trap. Размеры приходят из Base tokens.

```jinja
{% import 'base/macros.html' as ui %}
{% set navigation %}<nav class="sidebar-nav"><a class="sidebar-link" href="/tasks">Задачи</a></nav>{% endset %}
{% call ui.app_shell(title='Workflow', navigation=navigation, layout='wide') %}
  {{ ui.page_header(title='Задачи') }}
  <div>{{ page_content }}</div>
{% endcall %}
```

Shell использует native dialog и shared JS для Escape/Tab/scroll lock/возврата
фокуса и resize. Перед Base confirmation drawer закрывается; при удалённом
инициаторе safe fallback — focusable main. Legacy `.btn` variants в SSR являются
Base adapters тех же button tokens, не вторым продуктовым набором стилей.

`detail_page(title, context, actions, heading, aside, aside_label)` использует
тот же PageHeader и `page-split`, не создаёт второй frame. Product slot `aside`
содержит metadata/context; `caller` — основное содержание. При отсутствии aside
вторая колонка не резервируется. Состояния ресурса передаются через `state` macro
и продуктовый read result, не через универсальное описание бизнес-страницы.

Для оболочки используйте класс `base-ssr-shell`. Контролы формы получают
`box-sizing: border-box` из SSR-адаптера Base: их ширина не зависит от reset
продукта или Tailwind Preflight. На мобильном однострочные Input/Button
сохраняют минимум 44 px; высотой Textarea управляют `rows` и стили владельца.

React stories не являются SSR-приёмкой. Существующие SSR QA fixtures сохраняются.

`--require-installed` проверяет фактический способ поставки продукта. Для
SSR-only manifest (`ssrAssets`, без React `routeSource`/`shellSource`) это
`.base-ui-revision`, чистый точный Base checkout либо immutable runner export
через штатный source verifier и побайтовый `export-ssr --check`. Product React
`node_modules` в этом случае не требуются. SDK pin не подменяет UI pin.
Изменённый/неполный export, fingerprint или source mismatch отклоняется.
Для смешанного Jinja/React продукта обязательны обе проверки: SSR export и
установленный React UI package. При добавлении React routes/shell их source
объявляется в manifest, а не скрывается за SSR-only поставкой.
При наличии `routeSource` и `serverRouteSources` AST inventory объединяет оба
набора; серверный список не заменяет React routes. Manifest покрывает их union.
Этот source gate не заменяет actual-image fingerprints, SSO, роли и состояния.

## Граница соответствия

React props и SSR macro parameters не взаимозаменяемы. Карточка указывает SSR только для существующего macro; генератор проверяет его наличие в каноническом шаблоне. Продукт получает templates/JS/CSS штатным exporter и проверяет fingerprints. Отсутствие SSR-ссылки означает отсутствие заявленного аналога, а не возможность копировать React реализацию.

`page_header(title=..., heading=..., context=..., actions=..., leading=...)` не создаёт header
без содержимого. `title` экранируется как текст; подготовленная HTML-разметка
передаётся через `heading`. Контекст и действия допустимы без title: пустой
heading не превращается в заголовок None.

Необязательный `leading` помещается рядом с заголовком, вне h1. Без него прежняя
разметка сохраняется. `section_header(title, heading_id=..., level=2, context=...,
actions=...)` задаёт h2 либо h3 вложенного раздела; продукт сохраняет section и
его aria-labelledby. Нулевой счётчик не пропадает. Вложенная HTML-композиция
допустима только как доверенная разметка шаблона; полученный извне текст
экранируется.

`code_block(value, id=..., label='Код', labelled_by=..., described_by=...,
wrap=true, class_name='')` показывает буквальный текст в именованной focusable
области. `labelled_by` заменяет label. При `wrap=false` длинная строка
прокручивается внутри блока. Шрифт, отступы и цвета общие с React CodeBlock;
переданный текст не выполняется. Macro не форматирует JSON/diff и не копирует
значение автоматически. Для копирования используется отдельный copy_button.

## Переключатель сервисов

`service_switcher(label, id=..., source=...)` принимает ссылки через caller,
а `service_switcher_item(key, label, href=none, current=false, health='unknown')`
оформляет один элемент. Продукт разрешает доверенный href до вызова macro;
отсутствующий адрес остаётся недоступным. Health — пояснение состояния, он не
превращает подтверждённый адрес в недоверенный или наоборот.

```jinja
{% call base_ui.service_switcher('Продукт', source='runtime') %}
  {{ base_ui.service_switcher_item('current', 'Продукт', href='/current/', current=true) }}
  {{ base_ui.service_switcher_item('unavailable', 'Другой продукт') }}
{% endcall %}
```

Это disclosure с обычными ссылками: Tab/Shift+Tab, Escape с возвратом focus,
закрытие вне области. Он использует общий SSR runtime Base, включая обработку
pointer/focus. Roving focus React Menu не заявляется. Source, catalog fetching,
configured origins, deep links и ACL остаются у владельца интеграции.

## Копирование значения

`copy_button(target_id, id=none, label='Копировать', accessible_label=none,
disabled=false, class_name='')` создаёт кнопку и доступные состояния результата.
`target_id` указывает на элемент с уже разрешённым продуктом текстом. Macro не
загружает данные и не принимает решения о доступе. Продукт оставляет исходник
доступным для ручного копирования при отказе Clipboard API.

```jinja
{{ base_ui.code_block(command.usage, id='commandValue', label='Команда', wrap=false) }}
{{ base_ui.copy_button('commandValue', accessible_label='Копировать команду') }}
<script type="module">
{% include "base/clipboard-runtime.js" %}
document.querySelectorAll('button[data-base-copy-target]').forEach(function(button) {
  initCopyButton(button);
});
</script>
```

Файл получается штатным `ssr:export` вместе с fingerprint. Скрипт подключается
один раз в оболочке; получение command, callbacks записи и ACL остаются у продукта.
React `useClipboard` и SSR используют один transport Base: только Clipboard API,
без автоматического write, повторов и `execCommand`. Копируется точная строка,
включая пустоту, пробелы и переводы строк. Поздний ответ не подтверждает изменённый
или удалённый источник. Focus не перемещается после асинхронного ответа.

После смены ресурса вызовите `refreshCopyButton(button)`; перед удалением или
повторным использованием контрола — `destroyCopyButton(button)`. Повторный init
возвращает существующий controller, не добавляя обработчик. Pending блокирует
повторный write, не изменяя принадлежащий продукту native disabled.

## Поля и таблицы

React Input/Label/Textarea/Table и SSR используют один CSS-контракт Base.
`field` связывает подпись и hint/error; `input_control` сохраняет `name`, native
required, pattern/minlength/maxlength и явный `described_by`. `textarea_control`
принимает `rows` и `class_name` для заданной продуктом высоты. `appearance='inline'`
убирает обычную поверхность, сохраняя доступный focus и invalid state; у Input
`variant='heading'` использует масштаб заголовка из брендинга. Обработчики,
data-атрибуты и dirty tracking принадлежат вызывающей композиции. Автовысота — общий opt-in Base, описанный ниже.

`table` создаёт scroll wrapper и нативную таблицу; внутри caller оставляет
настоящие thead/tbody/tr/th/td. `class_name` и `container_class` предназначены
для предметных колонок и responsive-композиции. Они не создают новую палитру,
типографику или геометрию строк. Заголовки, значения и данные форматирует продукт.

## Карточки

`card` использует тот же CSS, что React Card. `card_header`, `card_title` и
`card_content` задают части композиции; уровень заголовка выбирает вызывающая
страница. Обычная карточка не получает обработчиков и не попадает в Tab-порядок.
При `href` корнем становится одна нативная ссылка с общим hover/focus. Внутри
карточки-ссылки нельзя размещать другие ссылки и действия.

```jinja
{% call base_ui.card() %}
  {% call base_ui.card_header() %}
    {{ base_ui.card_title(project.name, level=2) }}
  {% endcall %}
  {% call base_ui.card_content() %}{{ project.description }}{% endcall %}
{% endcall %}
```

Нативная форма сохраняет свой корень, name/id, data-атрибуты и обработчики:
`<form class="base-card base-card-content">…</form>`. Это композиция публичных
стилей, а не вложенная форма или локальная копия Card. Отступы, поверхность,
границы и скругления берутся из Base; раскладка предметных полей остаётся у продукта.

## Метки и прогресс

`badge(label, tone, appearance)` использует те же стили, что React Badge:
neutral/muted/info/success/warning/danger и badge/inline/dot. Это текстовая метка,
не кнопка. Статусы, перевод и соответствие тону определяет продукт.

`progress(value, max, variant, label, value_text)` использует тот же CSS, что React
Progress, и нормализует значение в 0..max. Base выводит числовые ARIA-атрибуты;
продукт передаёт доступное имя и при необходимости текст с единицами. max=0,
бесконечность и NaN не превращаются в известный нулевой процент. Для неизвестного
ожидания используйте Loader; отсутствие объёма нужно объяснить текстом продукта.

```jinja
{{ base_ui.badge(task.status_label, tone=task.status_tone) }}
{{ base_ui.progress(task.completed, max=task.total, label='Выполнение задачи',
                    value_text=task.progress_text) }}
```

## Меню действий

`action_menu(label, id, class_name, group)` создаёт native details/summary и панель
с общими стилями DropdownMenu Base. Подключается уже существующий `base-ui.js`.
Пункты — обычные button/a с `base-control base-menu-item`; права, обработчики,
URL и disabled сохраняет продукт. Опасный пункт получает `data-tone="danger"`.

```jinja
{% call base_ui.action_menu('Действия записи', id='record-actions', group='records') %}
  <button type="button" class="base-control base-menu-item" data-command="edit">Изменить</button>
  <button type="button" class="base-control base-menu-item" data-tone="danger" data-command="delete">Удалить</button>
{% endcall %}
```

Нативные Tab/Shift+Tab и Enter/Space сохраняются. Base закрывает раскрытое меню
по outside/focus и Escape с возвратом focus; обработанный Escape не закрывает
родительский диалог. group необязателен: открытие закрывает только другие меню
той же группы. Base ограничивает popup viewport, пересчитывая положение при
открытии, resize и scroll; дополнительного polling нет.

Это native disclosure, а не эмуляция Radix menu: role=menu, radio и arrow navigation
не добавляются. Для нового сценария с такими требованиями нужен отдельный явный
контракт. Подтверждение из меню закрывает его и возвращает focus к summary,
не к скрытой кнопке. Продукт не копирует обработчики или CSS общего поведения.

## Строки ресурсов

`resource_list` и `resource_list_row` используют канонические стили ResourceList.
Строка без href статична; с href создаётся одна нативная ссылка с общим focus/hover.
Для ul/li применяются те же классы к собственной нативной разметке. Сама Base
не добавляет role=list к произвольному div и не меняет предметный порядок записей.

Самостоятельная строка наследует row-height и padding из брендинга; внутри
ResourceList может действовать явно заданная density. Это не локальные 48/8/16 px.
Переключая предметное представление между Card и ResourceListRow, продукт меняет
композицию и применяет соответствующие классы; собственная палитра или геометрия
общего элемента не копируется. Место под предметные действия остаётся раскладкой.

`button` сохраняет прежние позиционные аргументы; новые необязательные size,
aria_label, class_name и title добавляются после них. size='icon' использует ту
же геометрию 40/44 px, что React Button. Значения primary/danger остаются aliases
канонических default/destructive. Для иконки нужно доступное имя; pending
сохраняет native disabled и явно сообщает aria-busy. Содержимое macro — текст,
произвольный SVG/React content не интерпретируется как HTML.

## Уведомления

React использует публичные `Toaster`/`toast` поверх существующего Sonner;
SSR использует `toaster` и `PdlcBaseUI.notify` из штатного `base-ui.js`.
Поверхность, границы, шрифт, отступы и скругления — общие tokens Base.
Нативный адаптер не загружает React и не создаёт второй React event store.

Нижний отступ обоих renderer учитывает `--base-fixed-actions-offset`, который
измеряет `BrandingWorkspaceLayout`. При переносе действий уведомление остаётся
выше панели; после её удаления действует обычный gutter. Отдельный observer,
продуктовый `bottom` или повышение `z-index` не нужны. У React явно переданные
`offset` и `mobileOffset` сохраняют приоритет.

```jinja
{{ ui.toaster() }}
<script>{% include 'base/base-ui.js' %}</script>
<script>
// Only after a confirmed product result; no write/retry is performed by Base.
window.PdlcBaseUI.notify('Сохранено', {type: 'success'});
</script>
```

Для SSR доступны `type: normal | success | error | warning`, `duration`
(миллисекунды от 0 до 2147483647 либо `Infinity`) и `hostId`. Macro принимает
`id`, `label`, `close_label`. Ссылки и HTML из сообщения не исполняются.
Возвращаемая функция закрывает только это сообщение; старый handle не закрывает
новое. Отсутствующий host, неизвестный type и неверная duration дают явную ошибку.

Один SSR-host показывает последнее сообщение. Обычное сообщение и успех по
умолчанию закрываются через 4 секунды; ошибка и предупреждение требуют явного
закрытия. Для обязательных долгоживущих ошибок формы используйте `Notice` рядом
с полем, а не только временное уведомление. Hover, focus внутри уведомления и
скрытая вкладка приостанавливают оставшееся время. Рендер не переводит фокус;
при закрытии из кнопки возвращает его инициатору, если он ещё доступен.
Host участвует в существующем inert-контракте Base confirmation; открытый modal
не оставляет кнопку уведомления интерактивной за собой. Pagehide удаляет сообщение
и его таймер/подписки. Для независимых областей
передайте разные `id` и соответствующий `hostId`.

Это не полная копия Sonner API: React сохраняет очередь, actions и promise
контракт Sonner. SSR документирует собственный текстовый адаптер. Доставка,
запросы, unread-состояние и предметные действия остаются у продукта.

## Кнопки, метки и выбор содержания

Действие остаётся native button с общими `base-control base-button` и
`data-variant`. Для secondary/outline/ghost оформление выбранного состояния
берётся из `aria-pressed=true`; ссылка текущего раздела использует
`aria-current=page`. Base не переключает product state и не вызывает callback
при рендере. Toggle-кнопке нужно постоянное доступное имя. Клавиатура native
button — Tab и Enter/Space; это не radio-group со стрелочной навигацией.

`Card asChild interactive` в React сохраняет одну native ссылку либо кнопку.
В SSR та же семантическая разметка использует `base-card base-card-content` и
`data-interactive=true`; выбранное содержание отражается в `aria-pressed` или
`aria-current=page`. Для значения формы применяйте RadioGroup/Select, а не набор
кнопок-карточек. Порядок, ID, URL и выбор остаются у продукта.

Статические режимы, счётчики и признаки используют `badge`. Для отдельного
действия внутри метки macro поддерживает caller без копии badge CSS:

```jinja
{% call ui.badge(tone='info') %}
  <span data-resource-id="{{ resource.id }}">{{ resource.name }}</span>
  <button type="button" class="base-control base-button base-icon-control"
          data-variant="ghost" data-size="icon"
          aria-label="Убрать {{ resource.name }}">×</button>
{% endcall %}
```

Обработчик отдельной кнопки подключает владелец страницы. Идентификатор нужно
читать из данных, а не вырезать иконку или знак удаления из textContent.
Обычный `badge(label, tone, appearance, class_name)` совместим с прежним
контрактом, включая числовой ноль. Содержимое caller экранируется обычной Jinja;
не превращайте весь Badge в псевдокнопку. Группы связанного содержимого используют
Card; предметные стрелки, порядок и подписи диаграммы остаются композицией продукта.

## Автовысота Textarea

React использует `<Textarea autoSize rows={2} style={{ maxHeight: 240 }} />`.
Без autoSize высота и ручной resize работают по прежнему контракту. Rows задаёт
исходную высоту; CSS min/max-height ограничивает рост. При достижении max-height
появляется внутренний scroll. Однострочные Input/Button сохраняют минимум 40/44 px.

SSR macro `textarea_control(..., rows=1, autosize=true)` добавляет
`data-base-autosize`. `textarea-runtime.js` приходит штатным экспортом Base:

```js
import {
  initTextareaAutosize,
  refreshTextareaAutosize,
  destroyTextareaAutosize,
} from "./textarea-runtime.js";
const field = document.querySelector("textarea[data-base-autosize]");
initTextareaAutosize(field);
// After an imperative value or presentation parent change:
field.value = "Confirmed text";
refreshTextareaAutosize(field);
// Before removal:
destroyTextareaAutosize(field);
```

В шаблоне с inline module используется тот же экспортированный файл без копии
алгоритма. Начальную активацию выполняет адаптер страницы после готовности DOM;
новые узлы активируются явно, удаляемые — освобождаются. Повторный init сохраняет
контроллер и обновляет presentation-окружение. React сам освобождает его при
unmount или выключении autoSize. После перемещения native-узла между формами
refresh также обновляет reset-подписку.

Измерение реагирует на ввод, ширину, изменение оформления предков и загрузку
шрифтов; скрытое поле измеряется после появления. Здесь нет polling, подмены DOM
прототипов, изменения value/selection/focus, синтетических input/change или записи
в продукт. В controlled форме reset состояния выполняет владелец формы; Base
только повторно измеряет уже применённый текст.

## Навигация по разделам

`SectionNavigation` и `SectionNavigationItem` задают общий вид ссылок. По
умолчанию orientation=horizontal; vertical размещает пункты колонкой. Передавайте
`aria-current="page"` для страницы или `aria-current="location"` для положения
внутри документа. Прежний React active по умолчанию означает page. Для router
Link нужен Router; обычные native anchors провайдеров не требуют.

SSR использует одноимённые семейные macros, а не shell nav:

```jinja
{% call ui.section_navigation(orientation='vertical', labelled_by='outline-title') %}
{{ ui.section_navigation_item('#overview', label='Основное', active=true, current='location') }}
{% call ui.section_navigation_item('#checks') %}
<span>Проверки</span>{{ ui.badge(3, 'muted', 'inline') }}
{% endcall %}
{% endcall %}
```

href, текущий пункт, hash/history и переход/scrollspy принадлежат вызывающему
продукту. Компонент не делает записи, не создаёт form choice и не заменяет Tabs.
Общее оформление, focus и адаптивные размеры ссылок не копируются в продуктовый CSS.

## Раскрываемые секции

SSR `disclosure` и React `Disclosure` используют нативные details/summary,
одинаковый Chevron, tokens и варианты panel/row. Для row применяется геометрия
ResourceListRow; продукт не рисует собственную стрелку или focus ring.

```jinja
{% set summary %}<strong>Результат проверки</strong>{{ ui.badge('Принято', 'success') }}{% endset %}
{% call ui.disclosure(summary, id='review-details', open=false, appearance='row') %}
<p>Содержание и состояние проверки передаёт владелец.</p>
{% endcall %}
```

При обычной строке summary сохраняется autoescape; подготовленная композиция
собирается шаблоном через set. class_name задаёт внешнее размещение секции.
Нативные Space/Enter раскрывают её без JavaScript, запроса или записи. SSR
не переносит React onToggle автоматически. Скрытое содержимое остаётся в DOM;
проверка прав выполняется продуктом до рендеринга, а не раскрытием секции.

## Страница ошибки и обратная ссылка

Заголовок страницы и действие возврата можно скомпоновать из существующих
page_header, badge, button и state. Ссылка «Назад» не является retry запроса:

```jinja
{% set back %}{{ ui.button('Назад', href=back_url, variant='secondary') }}{% endset %}
{{ ui.page_header(title, context=ui.badge('HTTP ' ~ status_code, 'muted'), actions=back) }}
{{ ui.state('error', message) }}
```

HTTP-статус, сообщение, URL и право перехода сохраняет приложение. Для настоящего
повтора чтения state принимает retry_url/retry_label; механизм не выполняет
автоматический запрос и не подставляет другую страницу.

## Подготовленный текст и отчёты

SSR `prose` применяет тот же CSS-контракт, что React `Prose`: шрифт, масштаб,
интервал, заголовки, списки, ссылки и код. Продукт передаёт уже подготовленную
семантическую разметку, а не копирует оформление этих элементов.

```jinja
{% call ui.prose(preserve_line_breaks=true) %}
<h3>Инструкции</h3>
<p>{{ instructions }}</p>
<ul>{% for item in checks %}<li>{{ item }}</li>{% endfor %}</ul>
{% endcall %}
```

`compact=true` выбирает общую компактную типографику. `preserve_line_breaks=true`
сохраняет переносы строк в абзацах и пунктах; для отчётов, которым важны также
отступы пробелами, вызывающий код может задать `white-space: pre-wrap` отдельному
содержимому. Парсинг, sanitization и политика URL остаются у продукта. Macro не
исполняет Markdown/HTML из строки и не добавляет `safe`: autoescape сохраняется.

Состояния задачи и результаты проверки передаются в `badge`/`notice` через
предметный адаптер tone. Счётчики и единицы передаются в `metric`/`progress`.
При неизвестном или нулевом объёме progress не объявляет известный процент;
продукт сохраняет исходные счётчики и решает, что означает отсутствие объёма.

## Описания и standalone-вход

`description_item` выводит одну пару dt/dd внутри принадлежащего приложению dl.
SSR и React DescriptionItem используют общие stacked/inline layouts, шрифт,
масштаб, перенос длинных значений и technical. Пустоту и форматирование задаёт
продукт; значение 0 не подменяется библиотекой.

```jinja
<dl>
{{ ui.description_item('Попытки', 0) }}
{% call ui.description_item('Автор', layout='inline') -%}
{{ ui.text_link(author_name, author_url) }}
{%- endcall %}
</dl>
```

`platform_login` — представление одного standalone-экрана, использующее те же
классы и tokens, что React PlatformLogin/SsoCallbackView. Оно не начинает SSO
и не владеет PKCE/state, callback, URL или правами.

```jinja
<body class="base-auth-page">
{{ ui.platform_login(title, message=message, message_kind='error', login_url=login_url) }}
</body>
```

Тему применяет приложение до отображения body. `message_kind=info` не создаёт
live role; error/pending задают alert/status. Отсутствующий login_url скрывает
действие; pending блокирует его без перехода. SSR получает готовую native ссылку,
React — callback. Для отказа доступа владелец передаёт свой заголовок и не передаёт
URL входа. Callback-bridge остаётся у auth-интеграции и не входит в macro.

`fieldset` сохраняет native группу полей, `disabled`, необязательные `legend`,
`name`, `form` и доступное имя. `legend_visually_hidden=true` оставляет legend
доступной вспомогательным технологиям. Disabled наследуется controls по HTML,
включая стандартное исключение первой legend; macro не переписывает их атрибуты.
Как и React Fieldset, macro не выполняет запросов и не заменяет серверные права.
Для одиночного поля используется `field`; для выбора — choice/radio controls.

```jinja
{% call base_ui.fieldset('Настройки доступа', disabled=false, class_name='owner-layout') %}
  {{ base_ui.input_control('name', 'name', value='Команда') }}
{% endcall %}
```

## Текст в контексте и техническая ячейка

resource_list_title/description поддерживают technical и tone=inherit/accent.
Маршруты и данные остаются у продукта. Внутри table можно использовать native
`<td data-technical="true" data-text-size="sm">`: CSS и tokens совпадают с
React TableCell. Это отдельный SSR-контракт, не перенос React props.

У custom choice renderer текст помечается base-choice-label. Общий CSS различает
закрытое значение и option; продукт передаёт данные и иконки. app_shell сам
перемещает context в mobile drawer: header display/flex не переопределяются.

Macro notice принимает separated=true для appearance='inline': разделитель
и внутренний отступ принадлежат общему CSS и текущей плотности. Для panel
флаг ничего не меняет. Native id/role, экранирование message/title и прежние
позиционные аргументы сохраняются. Группа полей использует fieldset separated,
а не сообщение; сохранение и readback остаются у приложения.

## Нативные поля, карточки и пункты действий

В принятом UI input_control/textarea_control допускают отсутствующие id/name:
это поля с aria-label, а не фиктивными keys формы. attributes передаёт native
owner events/data; явные параметры macro имеют приоритет. Boolean ARIA
сериализуются как true/false, native false/none пропускаются; true означает
атрибут присутствия. Checkbox/radio/select
сохраняют свои backing controls и lifecycle; новый обработчик событий не нужен.

```jinja
{{ ui.input_control(aria_label='Навык', attributes={'onchange': 'addSkill(this)'}) }}
{{ ui.textarea_control(value=description, aria_label='Описание', autosize=true,
  rows=1, appearance='inline', attributes={'data-field': 'description', 'onblur': 'saveDraft()'}) }}
{% call ui.card(tag='form', padded=true, id='owner-form',
  attributes={'onsubmit': 'event.preventDefault();saveDraft()'}) %}
  {{ ui.card_title('Настройки', level=2) }}
  {{ ui.input_control('title', 'title', value=title, required=true) }}
{% endcall %}
{% call ui.action_menu('Действия', id='owner-menu') %}
  {{ ui.action_menu_item('Удалить', tone='danger', disabled=not can_delete,
    attributes={'onclick': 'confirmDelete()'}) }}
{% endcall %}
```

Обработчики — доверенный код template продукта; attributes не является
источником непроверенного HTML/JS. Card tag ограничен native div/section/article/
form/button; href сохраняет прежний приоритет. padded/density не требуют
копирования base-card-content и не добавляют wrapper. Для inline title есть
card_title(tag='span'); heading level сохраняет собственный контракт. Это
SSR-композиции, а не новые React props. action_menu_item остаётся native action
в details/summary; Tab/Enter/Space/Escape проверяются отдельно от Radix.

Динамический рендеринг клонирует inert template, уже созданный macro. Данные,
content и handler задаются продуктом после независимого clone. Не пересобирайте
классы, типографику, форму и ARIA примитива строками в JS.

## Native выбор и составные части

`select_control` рендерит backing select и marker `data-base-choice` внутри Base.
Необязательные `id/name`, `form`, `aria_label`, `described_by` и доверенные
`attributes` сохраняют native форму и существующие handlers. Без `name` поле
не входит в FormData. Options, включая `value=''`, disabled/selected и
предметные data-icon/data-color, передаются caller без отдельного DTO:

```jinja
{{ ui.label_control('space', 'Пространство') }}
{% call ui.select_control('space', attributes={'onchange':'selectSpace(this.value)'}) %}
  <option value="" disabled selected>Выберите пространство</option>
  {% for space in spaces %}<option value="{{ space.id }}">{{ space.name }}</option>{% endfor %}
{% endcall %}
```

После штатного `initChoice` выбор посылает одну пару input/change.
`refreshChoice` после программного изменения options/value не делает запись;
`destroyChoice` возвращает native fallback. До успешного init control не скрыт.
Не объявляйте adapter успешным только по наличию скрытого backing select.

`label_control(visually_hidden=true)` сохраняет accessible name;
`card_title(tag='div'|'span')` — stable non-heading DOM с прежним id.
`resource_list(tag='ul'|'ol'|'div')` сохраняет native список; его rows получают
owner attributes, а href/interactive остаются явными параметрами Base.
`section_navigation_item` и `timeline_item` также принимают trusted attributes.
Не переносите в них построение product URL, фильтры, состояния или группировку.
Обычные layout и body/page-title classes — документированная композиция,
не повод создавать компонент для каждого div. React API этих SSR-параметров
не получает; его сигнатуры по-прежнему извлекаются из TypeScript.

Native reset синхронизирует видимый trigger после browser default action.
Смена значения не порождает input/change; defaultPrevented и destroy сохраняют
свою границу. Для теста одного form.reset() в JSDOM недостаточно: отдельно
проверяется реальная кнопка reset в IAB и порядок default action/microtask.

## Частичная навигация серверного приложения

Для замены только рабочей области используйте `app_main(title, layout)` — тот
же macro, который вызывает `app_shell`. Не копируйте main/PageFrame в продукт.
Шапка, меню навигации, branding и admission runtime устанавливаются один раз.
Явный `context=''` сохраняет пустой context slot для будущего каталога;
`context=none` не создаёт его.
Продукт владеет URL, загрузкой своего HTML и жизненным циклом контроллера страницы.

`installServerProduct` возвращает `ServerProductController`: `canLeave()`
подтверждает уход без автоматического удаления черновика. При отмене остаются
исходная форма и URL. После подтверждения владелец фиксирует целевой URL,
выделение раздела и заголовок, очищает прежний контроллер и сразу показывает
`app_main` со `state("loading", ...)`, затем асинхронно читает данные.
`trackForms(root)` удаляет отсоединённые формы и регистрирует новые; `isCurrent()`
проверяет исходное окно допуска; `retire()` закрывает защищённый документ при
смене полномочий. Частичная навигация не обновляет и не продлевает срок допуска.

Перед удалением рабочей области вызывайте `PdlcBaseUI.destroyMenus(root)` и
штатные destroy для choice/autosize/clipboard. После вставки — соответствующие
init и `PdlcBaseUI.initMenus(root)`. Повторный init меню идемпотентен; destroy
снимает document/window listeners и ResizeObserver только выбранного поддерева.
`closeNavigation()` закрывает мобильный drawer перед переходом.
Страничные listeners, таймеры и observers очищает владелец страницы. Не запускайте
повторно полный SDK или global bootstrap при замене main. История имеет одного
владельца; защищённый HTML не сохраняется в browser storage для history cache.

Ошибка чтения отображается через `state("error", ..., retry_url=...)` в целевом
разделе; повтор запускает только чтение. Не откладывайте переход до HTTP-ответа
и не оставляйте прежние данные под новым URL. Ответ отменённого/устаревшего
запроса не заменяет новую рабочую область. Уведомление или spinner поверх старой
страницы не заменяет loading целевого раздела. Фильтр/режим внутри той же страницы
может сохранять подтверждённые данные того же ресурса по явно заданному контракту.
Проверяйте переход с удержанным ответом: URL, меню, заголовок и loading должны
смениться до данных; отмена ухода, ошибка/повтор, история и отзыв допуска — отдельно.

## Компактные действия меток

`badge_button(label, tone, appearance)` — нативная кнопка для плотных рядов меток.
Удаление внутри badge использует appearance=inline, «+» рядом — badge.
Цель минимум24px, рамочная кнопка26px; обычные Button/touch controls не меняются.
Иконке нужен aria_label. Запись, pending/disabled и focus после удаления принадлежат
владельцу композиции. React-контракт — BadgeButton. Не заменять им обычные
кнопки формы/навигации.
